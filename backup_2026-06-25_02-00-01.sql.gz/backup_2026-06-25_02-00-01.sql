-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: usra_backoffice
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Advance`
--

DROP TABLE IF EXISTS `Advance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Advance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `amount` double NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requestDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `approvedById` int DEFAULT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `payrollId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Advance_candidateId_fkey` (`candidateId`),
  KEY `Advance_approvedById_fkey` (`approvedById`),
  KEY `Advance_payrollId_fkey` (`payrollId`),
  CONSTRAINT `Advance_approvedById_fkey` FOREIGN KEY (`approvedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Advance_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Advance_payrollId_fkey` FOREIGN KEY (`payrollId`) REFERENCES `Payroll` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Advance`
--

LOCK TABLES `Advance` WRITE;
/*!40000 ALTER TABLE `Advance` DISABLE KEYS */;
/*!40000 ALTER TABLE `Advance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttendanceRecord`
--

DROP TABLE IF EXISTS `AttendanceRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AttendanceRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `absJustified` int NOT NULL DEFAULT '0',
  `absUnjustified` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `AttendanceRecord_missionId_period_key` (`missionId`,`period`),
  KEY `AttendanceRecord_countryId_fkey` (`countryId`),
  KEY `AttendanceRecord_candidateId_fkey` (`candidateId`),
  KEY `AttendanceRecord_createdById_fkey` (`createdById`),
  CONSTRAINT `AttendanceRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttendanceRecord`
--

LOCK TABLES `AttendanceRecord` WRITE;
/*!40000 ALTER TABLE `AttendanceRecord` DISABLE KEYS */;
INSERT INTO `AttendanceRecord` VALUES (1,2,9,3,'2026-06',30,30,'pending','',8,'2026-06-22 09:41:06.711','2026-06-22 09:41:06.711',0,0);
/*!40000 ALTER TABLE `AttendanceRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` int DEFAULT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_userId_fkey` (`userId`),
  CONSTRAINT `AuditLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES (1,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-10 16:34:18.008'),(2,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-12 11:19:47.519'),(3,1,'Création','Utilisateurs',8,'Leonie Voukeng','2026-06-12 11:21:55.982'),(4,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-12 11:22:02.234'),(5,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:22:21.495'),(6,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:22:55.624'),(7,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:23:33.106'),(8,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:29:04.488'),(9,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-12 17:16:35.449'),(10,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:10.101'),(11,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:14.778'),(12,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:25.215'),(13,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:48:00.716'),(14,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:54:29.580'),(15,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 10:50:27.190'),(16,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-15 10:51:16.757'),(17,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 10:51:27.849'),(18,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 10:52:41.394'),(19,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 11:37:28.937'),(20,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 11:37:46.995'),(21,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-15 11:46:46.277'),(22,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 11:46:58.653'),(23,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 12:13:53.057'),(24,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:26:36.327'),(25,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:39:09.620'),(26,8,'Changement statut','Factures',NULL,'id:10 — mark-sent','2026-06-15 15:39:42.473'),(27,8,'Changement statut','Factures',NULL,'id:10 — mark-paid','2026-06-15 15:39:49.137'),(28,8,'Changement statut','Factures',NULL,'id:2 — mark-sent','2026-06-15 15:44:13.715'),(29,8,'Changement statut','Factures',NULL,'id:2 — mark-paid','2026-06-15 15:44:41.323'),(30,8,'Changement statut','Factures',NULL,'id:6 — mark-sent','2026-06-15 15:44:53.758'),(31,8,'Changement statut','Factures',NULL,'id:6 — mark-paid','2026-06-15 15:44:56.615'),(32,8,'Changement statut','Factures',NULL,'id:3 — mark-sent','2026-06-15 15:45:38.712'),(33,8,'Changement statut','Factures',NULL,'id:3 — mark-paid','2026-06-15 15:45:43.561'),(34,8,'Changement statut','Factures',NULL,'id:4 — mark-sent','2026-06-15 15:45:53.508'),(35,8,'Changement statut','Factures',NULL,'id:4 — mark-paid','2026-06-15 15:45:55.873'),(36,8,'Changement statut','Factures',NULL,'id:8 — mark-sent','2026-06-15 15:46:02.700'),(37,8,'Changement statut','Factures',NULL,'id:8 — mark-paid','2026-06-15 15:46:04.589'),(38,8,'Changement statut','Factures',NULL,'id:7 — mark-sent','2026-06-15 15:46:13.973'),(39,8,'Changement statut','Factures',NULL,'id:7 — mark-paid','2026-06-15 15:46:15.943'),(40,8,'Changement statut','Factures',NULL,'id:9 — mark-sent','2026-06-15 15:46:31.566'),(41,8,'Changement statut','Factures',NULL,'id:9 — mark-paid','2026-06-15 15:46:33.883'),(42,8,'Changement statut','Factures',NULL,'id:5 — mark-sent','2026-06-15 15:46:51.865'),(43,8,'Changement statut','Factures',NULL,'id:5 — mark-paid','2026-06-15 15:46:54.147'),(44,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:52:46.894'),(45,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 15:53:10.098'),(46,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 16:20:10.972'),(47,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 20:07:57.796'),(48,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 20:08:17.485'),(49,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-16 09:05:47.524'),(50,8,'Paiement','Bulletins',NULL,'id:2','2026-06-16 11:49:16.972'),(51,8,'Paiement','Bulletins',NULL,'id:1','2026-06-16 11:49:21.573'),(52,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:58:36.613'),(53,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:58:41.541'),(54,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:59:30.330'),(55,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-19 13:00:12.597'),(56,8,'Changement statut','Factures',NULL,'id:12 — mark-sent','2026-06-19 13:01:19.520'),(57,8,'Changement statut','Factures',NULL,'id:12 — mark-paid','2026-06-19 13:01:24.183'),(58,8,'Changement statut','Factures',NULL,'id:13 — mark-sent','2026-06-19 13:01:35.394'),(59,8,'Changement statut','Factures',NULL,'id:13 — mark-paid','2026-06-19 13:01:36.935'),(60,8,'Changement statut','Factures',NULL,'id:11 — mark-sent','2026-06-19 13:01:46.390'),(61,8,'Changement statut','Factures',NULL,'id:11 — mark-paid','2026-06-19 13:01:48.299'),(62,8,'Paiement','Bulletins',NULL,'id:3','2026-06-19 13:03:18.702'),(63,8,'Paiement','Bulletins',NULL,'id:4','2026-06-19 13:04:31.277'),(64,8,'Paiement','Bulletins',NULL,'id:5','2026-06-19 13:08:58.383'),(65,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:39:51.185'),(66,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:39:54.441'),(67,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:40:06.037'),(68,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-22 13:18:16.332'),(69,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 13:34:01.376'),(70,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 13:41:05.998'),(71,8,'Changement statut','Factures',NULL,'id:14 — mark-sent','2026-06-22 13:41:36.211'),(72,8,'Changement statut','Factures',NULL,'id:1 — mark-sent','2026-06-22 13:42:10.299'),(73,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-23 10:02:22.962'),(74,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-23 10:03:40.673'),(75,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-23 10:04:03.664'),(76,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-23 11:24:58.471'),(77,9,'Modification','Factures',NULL,'id:15','2026-06-24 14:04:51.087'),(78,9,'Changement statut','Factures',NULL,'id:15 — mark-sent','2026-06-24 14:05:18.539'),(79,9,'Changement statut','Factures',NULL,'id:16 — mark-sent','2026-06-24 14:08:38.619'),(80,9,'Changement statut','Factures',NULL,'id:16 — mark-paid','2026-06-24 14:08:41.541'),(81,9,'Changement statut','Factures',NULL,'id:17 — mark-sent','2026-06-24 14:10:45.294'),(82,9,'Changement statut','Factures',NULL,'id:17 — mark-paid','2026-06-24 14:10:48.472'),(83,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-24 14:14:12.098'),(84,9,'Changement statut','Factures',NULL,'id:18 — mark-sent','2026-06-24 14:14:40.170'),(85,9,'Changement statut','Factures',NULL,'id:18 — mark-paid','2026-06-24 14:14:48.267'),(86,9,'LOGOUT','auth',NULL,'Déconnexion — edson.sharonne@usra-care.com','2026-06-24 14:15:02.389'),(87,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-24 14:15:32.001'),(88,9,'Changement statut','Factures',NULL,'id:19 — mark-sent','2026-06-24 14:17:44.277'),(89,9,'Changement statut','Factures',NULL,'id:19 — mark-paid','2026-06-24 14:17:46.842'),(90,9,'Changement statut','Factures',NULL,'id:20 — mark-sent','2026-06-24 14:19:45.338'),(91,9,'Changement statut','Factures',NULL,'id:20 — mark-paid','2026-06-24 14:19:48.190'),(92,9,'Changement statut','Factures',NULL,'id:22 — mark-sent','2026-06-24 14:54:58.400'),(93,9,'Changement statut','Factures',NULL,'id:22 — mark-paid','2026-06-24 14:55:01.485'),(94,9,'Changement statut','Factures',NULL,'id:23 — mark-sent','2026-06-24 15:02:10.885'),(95,9,'Changement statut','Factures',NULL,'id:23 — mark-paid','2026-06-24 15:02:45.217'),(96,9,'Changement statut','Factures',NULL,'id:24 — mark-sent','2026-06-24 15:07:34.701'),(97,9,'Changement statut','Factures',NULL,'id:24 — mark-paid','2026-06-24 15:07:39.910');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Candidate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'M',
  `birthDate` datetime(3) DEFAULT NULL,
  `nationalId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorJob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primarySpecialtyId` int DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'applied',
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'walk_in',
  `paymentMethodPref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mobile_money',
  `mobileMoneyAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recruitedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Candidate_countryId_fkey` (`countryId`),
  KEY `Candidate_officeId_fkey` (`officeId`),
  CONSTRAINT `Candidate_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Candidate_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
INSERT INTO `Candidate` VALUES (1,2,NULL,' NATHALIE','DJOUGUEP','F','1985-04-20 00:00:00.000','KIT 280','693236926','','','BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:04:17.457','2026-06-15 16:33:12.739'),(2,2,NULL,'ELIANE LESLINE','TCHUATCHU','F','1984-03-28 00:00:00.000','AA01984942','670067385','','','BEPANDA','DOUALA',NULL,'DJEUKOU RAIMOND','699113067','MARI','','','','DJEUKOU RAYMOND','699113067',NULL,NULL,NULL,1,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:15:31.141','2026-06-15 16:33:01.572'),(3,2,NULL,'ASTA FANTA','ANTASSAR','F','1988-07-17 00:00:00.000','KIT 159','656200331','','','NOUVELLE ROUTE NGANGUE','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:18:29.027','2026-06-15 16:32:46.204'),(4,2,NULL,'AGNES','SINGUI','F','1988-06-06 00:00:00.000','100410867','695126955','','','SABLE BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:20:03.778','2026-06-15 16:32:33.784'),(5,2,NULL,'SANTANA','YAMENI','F','2002-11-23 00:00:00.000','KIT 123','640025561','','','BONABERI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:26:44.818','2026-06-15 16:31:58.530'),(6,2,NULL,'DOMINIQUE FLORE','ATIOBIGUI','F','1991-05-25 00:00:00.000','000657499','695638240','','','MAKEPE MISSOKE','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:29:53.310','2026-06-15 16:31:40.636'),(7,2,NULL,'ANNE DANIELLE MICHELLE','NGO HAGBE','F','2003-10-11 00:00:00.000','101924727','678665167','','','BEEDI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:32:55.219','2026-06-15 16:32:08.442'),(8,2,3,'AMELINE','GATUE','F','2004-04-19 00:00:00.000','000588102','698812623','','','BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:35:53.918','2026-06-15 16:32:18.715'),(9,1,1,'Ianjasoa Nekena','LAINGO Harimalala ','F','1996-12-05 00:00:00.000','104072006754','0344334879','0342422921','Laingoharimalalaianjasoanekena@gmail.com','AB 55 TER Ankadidravola','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','cash','','','',NULL,'2026-06-24 13:48:25.286','2026-06-24 13:58:09.038'),(10,1,1,'Marthe','RAVAOHARISOA','F','1979-07-05 00:00:00.000','102392001474','0343266389','0348073509','marthe@gmail.com','Mahavoky Sud','Mahajanga',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','referral','mobile_money','0348073509','','',NULL,'2026-06-24 14:31:16.255','2026-06-24 14:33:55.429');
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateSpecialty`
--

DROP TABLE IF EXISTS `CandidateSpecialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateSpecialty` (
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `isPrimary` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`candidateId`,`serviceId`),
  KEY `CandidateSpecialty_serviceId_fkey` (`serviceId`),
  CONSTRAINT `CandidateSpecialty_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateSpecialty_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateSpecialty`
--

LOCK TABLES `CandidateSpecialty` WRITE;
/*!40000 ALTER TABLE `CandidateSpecialty` DISABLE KEYS */;
INSERT INTO `CandidateSpecialty` VALUES (2,1,1);
/*!40000 ALTER TABLE `CandidateSpecialty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CashEntry`
--

DROP TABLE IF EXISTS `CashEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CashEntry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CashEntry_countryId_fkey` (`countryId`),
  CONSTRAINT `CashEntry_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CashEntry`
--

LOCK TABLES `CashEntry` WRITE;
/*!40000 ALTER TABLE `CashEntry` DISABLE KEYS */;
INSERT INTO `CashEntry` VALUES (1,2,'income','encaissement','2026-06-19 00:00:00.000',15000,'marge sur salaire de 3 clients (Mr Kouayep, Mme Youwo et Londo Technology','','2026-06-19 13:13:54.075'),(2,2,'expense','charge','2026-06-19 00:00:00.000',7550,'Transport; Recharge eau; Achat papier hygiénique et Frais de retrait des salaires','','2026-06-19 13:17:13.027');
/*!40000 ALTER TABLE `CashEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'individual',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `nif` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commissionRate` double NOT NULL DEFAULT '12',
  `paymentTermsDays` int NOT NULL DEFAULT '5',
  `overtimeRate` double NOT NULL DEFAULT '0',
  `billingFreq` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `agencyFee` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Client_countryId_fkey` (`countryId`),
  KEY `Client_officeId_fkey` (`officeId`),
  CONSTRAINT `Client_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Client_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` VALUES (1,2,NULL,'individual','MBALIDAM ESTHER','','','679526191','','BONAMOUSSADI','','',0,5,1000,'monthly',1,'','2026-06-15 13:07:57.339','2026-06-15 13:07:57.339'),(2,2,NULL,'individual','NGOLWA JEAN PIERRE','','','672740080','','MAKEPE COURS SUPREME','','',0,5,1000,'monthly',1,'','2026-06-15 13:10:58.109','2026-06-15 13:10:58.109'),(3,2,NULL,'individual','YOUWO PAULE GENIE','','','698716820','','BONABERI','','',0,5,1000,'monthly',1,'','2026-06-15 13:12:59.456','2026-06-15 13:12:59.456'),(4,2,NULL,'individual','NGONGANG WILFRIED','','','655629267','','BONAMOUSSADI','','',0,5,1000,'monthly',1,'','2026-06-15 13:13:57.328','2026-06-15 13:13:57.328'),(5,2,NULL,'individual','KOUAYEP PATERNE','','','655711431','','','','',0,5,1000,'monthly',1,'','2026-06-15 13:14:57.810','2026-06-15 13:14:57.810'),(6,2,NULL,'individual','FOUDA MADELEINE','','','653032588','','','','',0,5,1000,'monthly',1,'','2026-06-15 13:16:46.091','2026-06-15 13:16:46.091'),(7,2,NULL,'company','LONDO TECHNOLOGY','','','233 43 89 60','','','M031812705109H','',0,5,1000,'monthly',1,'','2026-06-15 13:21:52.889','2026-06-15 13:21:52.889'),(8,2,NULL,'individual','FONKOU BIKIM BISSE','','','695025385','','KOTTO BADEN BADEN','','',0,5,1000,'monthly',1,'','2026-06-15 13:24:37.422','2026-06-15 13:24:37.422'),(9,1,1,'individual','Alliance Nouboussi','','','0381032053','alliance@gmail.com','Ambohinjanahary Antehiroka','','',15,5,5000,'monthly',1,'','2026-06-24 13:03:08.587','2026-06-24 13:05:12.263'),(10,1,1,'individual','ANDRIAMANOA Revokiniaina','','','0321347762','revekoniaina@gmail.com','','','',15,5,5000,'monthly',1,'','2026-06-24 14:26:04.582','2026-06-24 14:26:04.582');
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Complaint`
--

DROP TABLE IF EXISTS `Complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Complaint` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `receivedVia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phone',
  `receivedById` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'moderate',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `decision` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decisionDetail` text COLLATE utf8mb4_unicode_ci,
  `resolvedAt` datetime(3) DEFAULT NULL,
  `resolvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Complaint_countryId_fkey` (`countryId`),
  KEY `Complaint_clientId_fkey` (`clientId`),
  KEY `Complaint_receivedById_fkey` (`receivedById`),
  CONSTRAINT `Complaint_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_receivedById_fkey` FOREIGN KEY (`receivedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Complaint`
--

LOCK TABLES `Complaint` WRITE;
/*!40000 ALTER TABLE `Complaint` DISABLE KEYS */;
/*!40000 ALTER TABLE `Complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComplaintCandidate`
--

DROP TABLE IF EXISTS `ComplaintCandidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ComplaintCandidate` (
  `complaintId` int NOT NULL,
  `candidateId` int NOT NULL,
  PRIMARY KEY (`complaintId`,`candidateId`),
  KEY `ComplaintCandidate_candidateId_fkey` (`candidateId`),
  CONSTRAINT `ComplaintCandidate_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ComplaintCandidate_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `Complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComplaintCandidate`
--

LOCK TABLES `ComplaintCandidate` WRITE;
/*!40000 ALTER TABLE `ComplaintCandidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ComplaintCandidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contribution`
--

DROP TABLE IF EXISTS `Contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Contribution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` double NOT NULL,
  `base` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gross',
  `part` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Contribution_countryId_fkey` (`countryId`),
  CONSTRAINT `Contribution_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contribution`
--

LOCK TABLES `Contribution` WRITE;
/*!40000 ALTER TABLE `Contribution` DISABLE KEYS */;
/*!40000 ALTER TABLE `Contribution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currencyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchangeToEur` double NOT NULL DEFAULT '1',
  `phonePrefix` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoicePrefix` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `entityName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legalMention` text COLLATE utf8mb4_unicode_ci,
  `vatRate` double NOT NULL DEFAULT '20',
  `syntheticTaxEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `syntheticTaxRate` double NOT NULL DEFAULT '0',
  `prorataBase` int NOT NULL DEFAULT '30',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `mobileMoneyProviders` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Country_code_key` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'Madagascar','MG','MGA','Ariary','Ar',0.0002,'+261','MG',1,'USRA CARE SARLU','NIF : 5018370696','STAT : 81211 11 2023 0 11485','LOT IIP 154 JC Météo Avaradoha','Antananarivo 101','+261 38 262 02 50','contact@usra-care.com','BNI Madagascar','00001 23456 78901234567 89','SARL unipersonnelle au capital de 1 000 000 Ar',20,1,5,30,'2026-06-05 09:52:57.884','2026-06-05 09:52:57.884','Mvola, Orange Money'),(2,'Cameroun','CM','XAF','Franc CFA','FCFA',0.00152,'+237','CM',1,'USRA CARE Cameroun SARL','NIU : M021912345678X','RCCM : RC/DLA/2024/B/1234','Rue Bonapriso, BP 12345','Douala','','','','10005 00012 12345678901 23','SARL au capital de 1 000 000 FCFA',19.25,0,0,30,'2026-06-05 09:52:57.910','2026-06-06 19:42:10.238','Orange Money, MTN Mobile Money'),(3,'Côte d\'Ivoire','CI','XOF','Franc CFA Ouest','FCFA',0.00152,'+225','CI',1,'USRA CARE Côte d\'Ivoire SARL',NULL,NULL,NULL,'Abidjan',NULL,NULL,NULL,NULL,NULL,18,0,0,30,'2026-06-05 09:52:57.924','2026-06-05 09:52:57.924','Wave, Orange Money');
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EquipmentRecord`
--

DROP TABLE IF EXISTS `EquipmentRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EquipmentRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `countryId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `items` json NOT NULL,
  `totalValue` double NOT NULL DEFAULT '0',
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `returnedAt` datetime(3) DEFAULT NULL,
  `returnedItems` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `EquipmentRecord_candidateId_fkey` (`candidateId`),
  KEY `EquipmentRecord_countryId_fkey` (`countryId`),
  KEY `EquipmentRecord_missionId_fkey` (`missionId`),
  CONSTRAINT `EquipmentRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EquipmentRecord`
--

LOCK TABLES `EquipmentRecord` WRITE;
/*!40000 ALTER TABLE `EquipmentRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `EquipmentRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Evaluation`
--

DROP TABLE IF EXISTS `Evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Evaluation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `clientId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `overallRating` double NOT NULL,
  `punctuality` int NOT NULL DEFAULT '0',
  `quality` int NOT NULL DEFAULT '0',
  `behavior` int NOT NULL DEFAULT '0',
  `appearance` int NOT NULL DEFAULT '0',
  `instructions` int NOT NULL DEFAULT '0',
  `discretion` int NOT NULL DEFAULT '0',
  `honesty` int NOT NULL DEFAULT '0',
  `initiative` int NOT NULL DEFAULT '0',
  `hygiene` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `recommend` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Evaluation_candidateId_fkey` (`candidateId`),
  KEY `Evaluation_clientId_fkey` (`clientId`),
  CONSTRAINT `Evaluation_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Evaluation_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Evaluation`
--

LOCK TABLES `Evaluation` WRITE;
/*!40000 ALTER TABLE `Evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Interview`
--

DROP TABLE IF EXISTS `Interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Interview` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answers` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Interview_candidateId_key` (`candidateId`),
  CONSTRAINT `Interview_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Interview`
--

LOCK TABLES `Interview` WRITE;
/*!40000 ALTER TABLE `Interview` DISABLE KEYS */;
INSERT INTO `Interview` VALUES (1,2,'menage','{\"0_0\": 5, \"0_1\": \"MAISON\", \"1_0\": true, \"1_1\": true, \"1_2\": true, \"2_0\": 4, \"2_1\": 4, \"2_2\": 3, \"2_3\": 75000}','2026-06-15 14:15:31.141','2026-06-15 16:33:01.583');
/*!40000 ALTER TABLE `Interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InterviewTemplate`
--

DROP TABLE IF EXISTS `InterviewTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InterviewTemplate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sections` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InterviewTemplate_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InterviewTemplate`
--

LOCK TABLES `InterviewTemplate` WRITE;
/*!40000 ALTER TABLE `InterviewTemplate` DISABLE KEYS */;
INSERT INTO `InterviewTemplate` VALUES (1,'menage','Ménage / Entretien','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de logements\"}, {\"type\": \"multiselect\", \"label\": \"Produits maîtrisés\"}, {\"type\": \"textarea\", \"label\": \"Références clients\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Repassage\"}, {\"type\": \"boolean\", \"label\": \"Cuisine simple\"}, {\"type\": \"boolean\", \"label\": \"Garde enfants\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Test dépoussiérage\"}, {\"type\": \"rating5\", \"label\": \"Test vitres\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(2,'cuisine','Cuisine / Chef','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types d\'établissements\"}, {\"type\": \"multiselect\", \"label\": \"Spécialités culinaires\"}, {\"type\": \"textarea\", \"label\": \"Plats phares\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Sait planifier des menus\"}, {\"type\": \"boolean\", \"label\": \"Gestion budget courses\"}, {\"type\": \"boolean\", \"label\": \"Formation hygiène (HACCP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test cuisine\"}, {\"type\": \"text\", \"label\": \"Plat préparé\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(3,'securite','Agent de sécurité','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Secteurs gardés\"}, {\"type\": \"textarea\", \"label\": \"Diplômes / certifications\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Permis de conduire\"}, {\"type\": \"boolean\", \"label\": \"Maîtrise outil radio\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours (SSIAP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Aptitude physique\"}, {\"type\": \"rating5\", \"label\": \"Gestion stress\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:09:52.906'),(4,'chauffeur','Chauffeur','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de véhicules\"}, {\"type\": \"multiselect\", \"label\": \"Catégorie de permis\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Connaissance de la ville\"}, {\"type\": \"boolean\", \"label\": \"Mécanique de base\"}, {\"type\": \"boolean\", \"label\": \"Conduite défensive\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test de conduite\"}, {\"type\": \"rating20\", \"label\": \"Code de la route\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(5,'garde_enfants','Garde d\'enfants','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Tranches d\'âge\"}, {\"type\": \"multiselect\", \"label\": \"Activités proposées\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Formation petite enfance\"}, {\"type\": \"boolean\", \"label\": \"Aide aux devoirs\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours nourrissons\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Interaction enfant\"}, {\"type\": \"rating5\", \"label\": \"Patience / empathie\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(6,'general','Questionnaire général','[{\"title\": \"Profil\", \"questions\": [{\"type\": \"text\", \"label\": \"Niveau d\'études\"}, {\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Compétences clés\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Aptitudes\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Ponctualité\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156');
/*!40000 ALTER TABLE `InterviewTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `subtotalHT` double NOT NULL DEFAULT '0',
  `vatRate` double NOT NULL DEFAULT '20',
  `vatAmount` double NOT NULL DEFAULT '0',
  `syntheticTax` double NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `period` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Invoice_reference_key` (`reference`),
  KEY `Invoice_countryId_fkey` (`countryId`),
  KEY `Invoice_clientId_fkey` (`clientId`),
  CONSTRAINT `Invoice_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Invoice_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
INSERT INTO `Invoice` VALUES (1,2,2,'CM-2026-0001','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','sent',65000,0,0,0,65000,NULL,NULL,0,'2026-04','2026-06-15 15:02:17.490','2026-06-22 13:42:10.284'),(2,2,1,'CM-2026-0002','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-04','2026-06-15 15:05:14.997','2026-06-15 15:44:41.308'),(3,2,7,'CM-2026-0003','placement','2026-05-08 00:00:00.000','2026-05-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-04','2026-06-15 15:06:56.619','2026-06-15 15:45:43.545'),(4,2,3,'CM-2026-0004','placement','2026-05-13 00:00:00.000','2026-05-18 00:00:00.000','paid',55000,0,0,0,55000,NULL,NULL,0,'2026-04','2026-06-15 15:08:12.033','2026-06-15 15:45:55.861'),(5,2,1,'CM-2026-0005','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-05','2026-06-15 15:09:58.761','2026-06-15 15:46:54.134'),(6,2,2,'CM-2026-0006','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-04','2026-06-15 15:17:16.939','2026-06-15 15:44:56.600'),(7,2,4,'CM-2026-0007','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',60000,0,0,0,60000,NULL,NULL,0,'2026-05','2026-06-15 15:21:15.057','2026-06-15 15:46:15.931'),(8,2,6,'CM-2026-0008','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-05','2026-06-15 15:22:48.599','2026-06-15 15:46:04.579'),(9,2,8,'CM-2026-0009','placement','2026-06-01 00:00:00.000','2026-06-06 00:00:00.000','paid',85000,0,0,0,85000,NULL,NULL,0,'2026-05','2026-06-15 15:25:13.141','2026-06-15 15:46:33.872'),(10,2,2,'CM-2026-0010','placement','2026-06-01 00:00:00.000','2026-06-06 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-05','2026-06-15 15:27:14.668','2026-06-15 15:39:49.123'),(11,2,7,'CM-2026-0011','placement','2026-06-08 00:00:00.000','2026-06-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-05','2026-06-15 15:29:36.434','2026-06-19 13:01:48.287'),(12,2,5,'CM-2026-0012','placement','2026-06-15 00:00:00.000','2026-06-21 00:00:00.000','paid',25000,0,0,0,25000,NULL,NULL,0,'2026-06','2026-06-15 15:32:19.509','2026-06-19 13:01:24.168'),(13,2,3,'CM-2026-0013','placement','2026-06-15 00:00:00.000','2026-06-20 00:00:00.000','paid',55000,0,0,0,55000,NULL,NULL,0,'2026-06','2026-06-15 15:34:04.581','2026-06-19 13:01:36.924'),(14,2,6,'CM-2026-0014','placement','2026-06-22 00:00:00.000','2026-06-27 00:00:00.000','sent',65000,0,0,0,65000,NULL,NULL,0,'2026-06','2026-06-22 09:44:50.468','2026-06-22 13:41:36.192'),(15,1,9,'MG-2026-0001','placement','2026-06-24 00:00:00.000','2026-06-29 00:00:00.000','sent',300000,0,0,0,300000,NULL,NULL,0,'2026-06','2026-06-24 14:04:22.694','2026-06-24 14:05:18.525'),(16,1,9,'MG-2026-0002','placement','2026-01-22 00:00:00.000','2026-01-27 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-01','2026-06-24 14:08:32.916','2026-06-24 14:08:41.529'),(17,1,9,'MG-2026-0003','placement','2026-02-19 00:00:00.000','2026-02-24 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-02','2026-06-24 14:10:23.946','2026-06-24 14:10:48.459'),(18,1,9,'MG-2026-0004','placement','2026-03-30 00:00:00.000','2026-04-04 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-03','2026-06-24 14:14:32.423','2026-06-24 14:14:48.255'),(19,1,9,'MG-2026-0005','placement','2026-04-28 00:00:00.000','2026-05-03 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-04','2026-06-24 14:17:18.067','2026-06-24 14:17:46.829'),(20,1,9,'MG-2026-0006','placement','2026-05-28 00:00:00.000','2026-06-02 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-05','2026-06-24 14:19:11.326','2026-06-24 14:19:48.178'),(21,1,10,'MG-2026-0007','placement','2026-06-24 00:00:00.000','2026-06-29 00:00:00.000','draft',250000,0,0,0,250000,NULL,NULL,0,'2026-06','2026-06-24 14:47:26.738','2026-06-24 14:47:26.738'),(22,1,10,'MG-2026-0008','placement','2026-05-28 00:00:00.000','2026-06-02 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-05','2026-06-24 14:50:41.975','2026-06-24 14:55:01.474'),(23,1,10,'MG-2026-0009','placement','2026-04-29 00:00:00.000','2026-05-04 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-04','2026-06-24 14:59:54.741','2026-06-24 15:02:45.199'),(24,1,10,'MG-2026-0010','placement','2026-03-30 00:00:00.000','2026-04-04 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-03','2026-06-24 15:07:20.500','2026-06-24 15:07:39.896');
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvoiceLine`
--

DROP TABLE IF EXISTS `InvoiceLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoiceLine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `candidateId` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `unitPrice` double NOT NULL,
  `totalHT` double NOT NULL,
  `daysWorked` int DEFAULT NULL,
  `prorataCoef` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InvoiceLine_invoiceId_fkey` (`invoiceId`),
  KEY `InvoiceLine_missionId_fkey` (`missionId`),
  CONSTRAINT `InvoiceLine_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InvoiceLine_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceLine`
--

LOCK TABLES `InvoiceLine` WRITE;
/*!40000 ALTER TABLE `InvoiceLine` DISABLE KEYS */;
INSERT INTO `InvoiceLine` VALUES (1,1,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(2,2,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,80000,80000,NULL,NULL),(3,3,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,66000,66000,NULL,NULL),(4,4,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,55000,55000,NULL,NULL),(5,5,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,80000,80000,NULL,NULL),(6,6,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(7,7,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,60000,60000,NULL,NULL),(8,8,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(9,9,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,85000,85000,NULL,NULL),(10,10,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(11,11,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,66000,66000,NULL,NULL),(12,12,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,25000,25000,NULL,NULL),(13,13,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,55000,55000,NULL,NULL),(14,14,NULL,NULL,'Salaire mensuel du personnel plus marge sur salaire',1,65000,65000,NULL,NULL),(16,15,NULL,NULL,'Placement de prestation ménagère',1,300000,300000,NULL,NULL),(17,16,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(18,17,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(19,18,NULL,NULL,'Placement de prestation de ménagère ',1,300000,300000,NULL,NULL),(20,19,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(21,20,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(22,21,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(23,22,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(24,23,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(25,24,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL);
/*!40000 ALTER TABLE `InvoiceLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IrsaBracket`
--

DROP TABLE IF EXISTS `IrsaBracket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IrsaBracket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `fromAmount` double NOT NULL,
  `toAmount` double DEFAULT NULL,
  `rate` double NOT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IrsaBracket_countryId_fkey` (`countryId`),
  CONSTRAINT `IrsaBracket_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IrsaBracket`
--

LOCK TABLES `IrsaBracket` WRITE;
/*!40000 ALTER TABLE `IrsaBracket` DISABLE KEYS */;
INSERT INTO `IrsaBracket` VALUES (1,1,0,350000,0,1),(2,1,350000,400000,5,2),(3,1,400000,500000,10,3),(4,1,500000,600000,15,4),(5,1,600000,NULL,20,5),(9,3,0,75000,0,1),(10,3,75000,240000,16,2),(11,3,240000,NULL,21,3),(27,2,0,62000,0,1),(28,2,62000,310000,10,2),(29,2,310000,NULL,15,3);
/*!40000 ALTER TABLE `IrsaBracket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mission`
--

DROP TABLE IF EXISTS `Mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Mission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `clientRate` double NOT NULL DEFAULT '0',
  `employeeRate` double NOT NULL DEFAULT '0',
  `agencyFee` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL DEFAULT '0',
  `commissionRate` double NOT NULL DEFAULT '12',
  `prorataBase` int NOT NULL DEFAULT '30',
  `trialPeriodEnd` datetime(3) DEFAULT NULL,
  `trialConfirmed` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdById` int DEFAULT NULL,
  `approvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Mission_countryId_fkey` (`countryId`),
  KEY `Mission_clientId_fkey` (`clientId`),
  KEY `Mission_candidateId_fkey` (`candidateId`),
  KEY `Mission_serviceId_fkey` (`serviceId`),
  CONSTRAINT `Mission_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mission`
--

LOCK TABLES `Mission` WRITE;
/*!40000 ALTER TABLE `Mission` DISABLE KEYS */;
INSERT INTO `Mission` VALUES (1,2,8,2,1,'placement','2026-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',90000,85000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 09:08:57.987','2026-06-16 09:08:57.987'),(2,2,2,7,1,'placement','2026-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:46:20.816','2026-06-16 11:46:20.816'),(3,2,6,6,1,'placement','2026-06-21 00:00:00.000','2026-12-21 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-21 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:53:38.153','2026-06-16 11:53:38.153'),(4,2,5,8,2,'placement','2024-06-07 00:00:00.000','2026-12-07 00:00:00.000','active',25000,20000,5000,0,12,30,'2026-12-07 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:59:56.359','2026-06-16 11:59:56.359'),(5,2,4,4,2,'placement','2024-04-30 00:00:00.000','2026-12-30 00:00:00.000','active',60000,55000,5000,0,12,30,'2026-12-30 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:02:40.038','2026-06-16 12:02:40.038'),(6,2,3,5,3,'placement','2025-04-18 00:00:00.000','2025-12-18 00:00:00.000','active',55000,50000,5000,0,12,30,'2026-12-18 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:04:11.364','2026-06-16 12:04:11.364'),(7,2,2,7,1,'placement','2025-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:05:33.183','2026-06-16 12:05:33.183'),(8,2,1,1,1,'placement','2026-01-30 00:00:00.000','2026-12-30 00:00:00.000','active',80000,75000,5000,0,12,30,'2026-07-16 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:07:13.160','2026-06-16 12:07:13.160'),(9,2,7,3,7,'placement','2024-04-13 00:00:00.000','2026-12-13 00:00:00.000','active',66000,61000,5000,0,12,30,'2026-12-13 00:00:00.000',0,NULL,8,NULL,'2026-06-19 13:08:14.461','2026-06-19 13:08:14.461'),(10,1,9,9,1,'placement','2025-12-23 00:00:00.000',NULL,'active',300000,250000,50000,0,12,30,'2025-12-30 00:00:00.000',0,NULL,9,NULL,'2026-06-24 14:00:36.112','2026-06-24 14:00:36.112'),(11,1,10,10,1,'placement','2025-11-05 00:00:00.000',NULL,'active',0,0,0,0,12,30,'2025-11-12 00:00:00.000',0,NULL,9,NULL,'2026-06-24 14:44:42.662','2026-06-24 14:44:42.662');
/*!40000 ALTER TABLE `Mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotifSetting`
--

DROP TABLE IF EXISTS `NotifSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NotifSetting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `threshold` int NOT NULL DEFAULT '7',
  PRIMARY KEY (`id`),
  UNIQUE KEY `NotifSetting_type_key` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotifSetting`
--

LOCK TABLES `NotifSetting` WRITE;
/*!40000 ALTER TABLE `NotifSetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotifSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Office`
--

DROP TABLE IF EXISTS `Office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Office` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Office_countryId_fkey` (`countryId`),
  CONSTRAINT `Office_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Office`
--

LOCK TABLES `Office` WRITE;
/*!40000 ALTER TABLE `Office` DISABLE KEYS */;
INSERT INTO `Office` VALUES (1,1,'Siège Antananarivo','LOT IIP 154 JC Météo Avaradoha','Antananarivo','+261 38 262 02 50','tana@usra-care.com',1,'2026-06-05 09:52:57.938'),(2,1,'Agence Antsirabe',NULL,'Antsirabe',NULL,'antsirabe@usra-care.com',1,'2026-06-05 09:52:57.951'),(3,2,'Bureau Douala',NULL,'Douala',NULL,'douala@usra-care.com',1,'2026-06-05 09:52:57.965'),(4,3,'Bureau Abidjan',NULL,'Abidjan',NULL,'abidjan@usra-care.com',1,'2026-06-05 09:52:57.977');
/*!40000 ALTER TABLE `Office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OvertimeRecord`
--

DROP TABLE IF EXISTS `OvertimeRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OvertimeRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `hours` double NOT NULL,
  `hourlyRate` double NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdById` int DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `OvertimeRecord_countryId_fkey` (`countryId`),
  KEY `OvertimeRecord_missionId_fkey` (`missionId`),
  KEY `OvertimeRecord_candidateId_fkey` (`candidateId`),
  KEY `OvertimeRecord_createdById_fkey` (`createdById`),
  KEY `OvertimeRecord_validatedById_fkey` (`validatedById`),
  CONSTRAINT `OvertimeRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OvertimeRecord`
--

LOCK TABLES `OvertimeRecord` WRITE;
/*!40000 ALTER TABLE `OvertimeRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `OvertimeRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Payment_invoiceId_fkey` (`invoiceId`),
  CONSTRAINT `Payment_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payment`
--

LOCK TABLES `Payment` WRITE;
/*!40000 ALTER TABLE `Payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payroll`
--

DROP TABLE IF EXISTS `Payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payroll` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `candidateId` int NOT NULL,
  `missionId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `prorataCoef` double NOT NULL DEFAULT '1',
  `netTarget` double NOT NULL,
  `gross` double NOT NULL,
  `totalEmpCotis` double NOT NULL DEFAULT '0',
  `totalEmprCotis` double NOT NULL DEFAULT '0',
  `irsa` double NOT NULL DEFAULT '0',
  `netBase` double NOT NULL,
  `overtimeAmount` double NOT NULL DEFAULT '0',
  `bonuses` double NOT NULL DEFAULT '0',
  `deductions` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL,
  `massSalariale` double NOT NULL DEFAULT '0',
  `cotisationsJson` json DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_validation',
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentRef` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentDate` datetime(3) DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Payroll_countryId_fkey` (`countryId`),
  KEY `Payroll_candidateId_fkey` (`candidateId`),
  KEY `Payroll_missionId_fkey` (`missionId`),
  KEY `Payroll_validatedById_fkey` (`validatedById`),
  CONSTRAINT `Payroll_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payroll`
--

LOCK TABLES `Payroll` WRITE;
/*!40000 ALTER TABLE `Payroll` DISABLE KEYS */;
INSERT INTO `Payroll` VALUES (1,2,2,1,'2026-06','placement',30,30,1,85000,87556,0,0,2556,85000,0,0,0,85000,87556,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-16 11:49:21.557',8,'2026-06-16 11:49:21.557','2026-06-16 10:11:02.424','2026-06-16 11:49:21.558'),(2,2,7,2,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-16 11:49:16.948',8,'2026-06-16 11:49:16.948','2026-06-16 11:46:51.774','2026-06-16 11:49:16.950'),(3,2,8,4,'2026-06','placement',30,30,1,20000,20001,0,0,0,20001,0,0,0,20001,20001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:03:18.686',8,'2026-06-19 13:03:18.686','2026-06-19 13:03:13.922','2026-06-19 13:03:18.687'),(4,2,5,6,'2026-06','placement',30,30,1,50000,50001,0,0,0,50001,0,0,0,50001,50001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:04:31.256',8,'2026-06-19 13:04:31.256','2026-06-19 13:04:28.392','2026-06-19 13:04:31.258'),(5,2,3,9,'2026-06','placement',30,30,1,61000,61001,0,0,0,61001,0,0,0,61001,61001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:08:58.355',8,'2026-06-19 13:08:58.355','2026-06-19 13:08:55.523','2026-06-19 13:08:58.357');
/*!40000 ALTER TABLE `Payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Service`
--

DROP TABLE IF EXISTS `Service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interviewTemplate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service`
--

LOCK TABLES `Service` WRITE;
/*!40000 ALTER TABLE `Service` DISABLE KEYS */;
INSERT INTO `Service` VALUES (1,'Ménage','long_term','🏠','menage',1,'2026-06-05 09:52:58.728',NULL,NULL),(2,'Cuisine','long_term','🍳','cuisine',1,'2026-06-05 09:52:58.743',NULL,NULL),(3,'Garde d\'enfants','long_term','👶','nounou',1,'2026-06-05 09:52:58.752',NULL,NULL),(4,'Chauffeur','long_term','🚗','chauffeur',1,'2026-06-05 09:52:58.762',NULL,NULL),(5,'Gardiennage','long_term','🛡️','gardien',1,'2026-06-05 09:52:58.774',NULL,NULL),(6,'Jardinage','long_term','🌿','jardinier',1,'2026-06-05 09:52:58.788',NULL,NULL),(7,'Nettoyage entreprise','long_term','🏢','menage',1,'2026-06-05 09:52:58.797',NULL,NULL),(8,'Agent de sécurité','long_term','lock','securite',1,'2026-06-05 09:52:58.806','personnel_maison',NULL),(9,'Aide personne âgée','long_term','🤝','aide_senior',1,'2026-06-05 09:52:58.816',NULL,NULL),(10,'Plomberie','short_term','🔧','technique',1,'2026-06-05 09:52:58.825',NULL,NULL),(11,'Électricité','short_term','⚡','technique',1,'2026-06-05 09:52:58.836',NULL,NULL),(12,'Peinture','short_term','🎨','technique',1,'2026-06-05 09:52:58.847',NULL,NULL),(13,'Ingénieur Logiciel','long_term','💻','qualifie',1,'2026-06-05 09:52:58.861',NULL,NULL),(14,'Comptable','long_term','📊','qualifie',1,'2026-06-05 09:52:58.874',NULL,NULL),(15,'Réceptionniste','long_term','briefcase','reception',1,'2026-06-05 09:52:58.886','personnel_maison',NULL);
/*!40000 ALTER TABLE `Service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceRate`
--

DROP TABLE IF EXISTS `ServiceRate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceRate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serviceId` int NOT NULL,
  `countryId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minRate` double NOT NULL,
  `maxRate` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ServiceRate_serviceId_fkey` (`serviceId`),
  CONSTRAINT `ServiceRate_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceRate`
--

LOCK TABLES `ServiceRate` WRITE;
/*!40000 ALTER TABLE `ServiceRate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceRate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Target`
--

DROP TABLE IF EXISTS `Target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Target` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetValue` double NOT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Target_userId_fkey` (`userId`),
  KEY `Target_countryId_fkey` (`countryId`),
  CONSTRAINT `Target_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Target_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Target`
--

LOCK TABLES `Target` WRITE;
/*!40000 ALTER TABLE `Target` DISABLE KEYS */;
/*!40000 ALTER TABLE `Target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countryId` int DEFAULT NULL,
  `officeId` int DEFAULT NULL,
  `avatar` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  KEY `User_countryId_fkey` (`countryId`),
  KEY `User_officeId_fkey` (`officeId`),
  CONSTRAINT `User_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'Admin','Global','admin@usra-care.com','','admin',NULL,NULL,'AG',1,'$2b$10$xtETxUkEjmFi.DuYO6lkmePtiKpIpHnwXw9XuafCf5cJAvNNt5B5G','2026-06-05 09:52:58.156','2026-06-05 21:49:58.291'),(8,'Leonie','Voukeng','leonie.voukeng@carebusinessconsulting.com','','operator',2,3,'LV',1,'$2b$10$Qis5Yu80D1sSoUqehEOziOcfYAmfXdqBCOZI7UJMBaC/QU3fiaiAa','2026-06-12 11:21:55.965','2026-06-12 11:21:55.965'),(9,'SHARONNE','EDSON','edson.sharonne@usra-care.com','','operator',1,1,'SE',1,'$2b$10$q0TY.dJeHQ5plUg4eYamJO5L.W5FAU7xvhOVIW90NtMXRQr626JaK','2026-06-23 10:03:34.622','2026-06-23 10:03:34.622');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'usra_backoffice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-25  2:00:02
