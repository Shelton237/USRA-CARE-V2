-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: usra_backoffice
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Advance`
--

DROP TABLE IF EXISTS `Advance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Advance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `amount` double NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requestDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `approvedById` int DEFAULT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `payrollId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Advance_candidateId_fkey` (`candidateId`),
  KEY `Advance_approvedById_fkey` (`approvedById`),
  KEY `Advance_payrollId_fkey` (`payrollId`),
  CONSTRAINT `Advance_approvedById_fkey` FOREIGN KEY (`approvedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Advance_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Advance_payrollId_fkey` FOREIGN KEY (`payrollId`) REFERENCES `Payroll` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Advance`
--

LOCK TABLES `Advance` WRITE;
/*!40000 ALTER TABLE `Advance` DISABLE KEYS */;
INSERT INTO `Advance` VALUES (1,11,70000,'','mobile_money','rejected','2026-06-23 00:00:00.000',1,'2026-07-11 05:19:29.612',NULL,'2026-06-30 08:01:41.311'),(2,14,100000,'Frais d\'inscription de son enfant','cash','approved','2026-07-15 00:00:00.000',1,'2026-07-20 10:43:33.153',34,'2026-07-14 11:58:09.025');
/*!40000 ALTER TABLE `Advance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttendanceRecord`
--

DROP TABLE IF EXISTS `AttendanceRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AttendanceRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `absJustified` int NOT NULL DEFAULT '0',
  `absUnjustified` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `AttendanceRecord_missionId_period_key` (`missionId`,`period`),
  KEY `AttendanceRecord_countryId_fkey` (`countryId`),
  KEY `AttendanceRecord_candidateId_fkey` (`candidateId`),
  KEY `AttendanceRecord_createdById_fkey` (`createdById`),
  CONSTRAINT `AttendanceRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttendanceRecord`
--

LOCK TABLES `AttendanceRecord` WRITE;
/*!40000 ALTER TABLE `AttendanceRecord` DISABLE KEYS */;
INSERT INTO `AttendanceRecord` VALUES (1,2,9,3,'2026-06',30,30,'pending','',8,'2026-06-22 09:41:06.711','2026-06-22 09:41:06.711',0,0),(2,2,5,4,'2026-06',30,30,'pending','',8,'2026-06-26 08:56:26.130','2026-06-26 08:56:26.130',0,0),(3,2,1,2,'2026-06',24,30,'pending','',8,'2026-06-26 09:09:10.733','2026-06-26 09:09:10.733',0,0),(4,2,8,1,'2026-06',30,30,'pending','',8,'2026-06-27 10:42:00.491','2026-06-27 10:42:00.491',0,0),(5,1,12,11,'2026-06',30,30,'pending','',9,'2026-06-30 08:03:52.374','2026-06-30 08:03:52.374',0,0),(6,1,14,16,'2026-06',30,30,'pending','',9,'2026-06-30 08:04:02.629','2026-06-30 08:04:02.629',0,0),(7,1,10,9,'2026-06',30,30,'pending','',9,'2026-06-30 08:04:11.531','2026-06-30 08:04:11.531',0,0),(8,1,15,15,'2026-06',30,30,'pending','',9,'2026-06-30 08:04:18.720','2026-06-30 08:04:18.720',0,0),(9,1,11,10,'2026-06',30,30,'pending','',9,'2026-06-30 08:04:27.806','2026-06-30 08:04:27.806',0,0),(10,1,13,14,'2026-06',30,30,'pending','',9,'2026-06-30 08:04:33.497','2026-06-30 08:04:33.497',0,0),(11,2,3,6,'2026-07',30,30,'pending','',8,'2026-07-02 15:37:59.266','2026-07-02 15:38:00.940',0,0),(12,2,7,7,'2026-07',30,30,'pending','',8,'2026-07-06 15:45:42.682','2026-07-31 07:36:32.608',0,0),(13,2,9,3,'2026-07',30,30,'pending','',8,'2026-07-10 13:59:59.340','2026-07-10 13:59:59.340',0,0),(14,2,6,5,'2026-07',30,30,'pending','',8,'2026-07-18 11:01:06.249','2026-07-18 11:01:06.249',0,0),(15,2,4,8,'2026-07',30,30,'pending','',8,'2026-07-18 11:01:15.405','2026-07-18 11:01:15.405',0,0),(16,2,8,1,'2026-07',30,30,'pending','',8,'2026-07-31 07:36:14.312','2026-07-31 07:36:14.312',0,0),(17,2,5,4,'2026-07',30,30,'pending','',8,'2026-07-31 07:36:40.975','2026-07-31 07:36:40.975',0,0),(18,1,21,25,'2026-08',30,30,'pending','Maladie',9,'2026-08-17 05:37:54.423','2026-08-18 07:34:12.069',0,0);
/*!40000 ALTER TABLE `AttendanceRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` int DEFAULT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_userId_fkey` (`userId`),
  CONSTRAINT `AuditLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES (1,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-10 16:34:18.008'),(2,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-12 11:19:47.519'),(3,1,'Création','Utilisateurs',8,'Leonie Voukeng','2026-06-12 11:21:55.982'),(4,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-12 11:22:02.234'),(5,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:22:21.495'),(6,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:22:55.624'),(7,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:23:33.106'),(8,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-12 11:29:04.488'),(9,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-12 17:16:35.449'),(10,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:10.101'),(11,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:14.778'),(12,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:47:25.215'),(13,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:48:00.716'),(14,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 09:54:29.580'),(15,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 10:50:27.190'),(16,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-15 10:51:16.757'),(17,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 10:51:27.849'),(18,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 10:52:41.394'),(19,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 11:37:28.937'),(20,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 11:37:46.995'),(21,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-15 11:46:46.277'),(22,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 11:46:58.653'),(23,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 12:13:53.057'),(24,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:26:36.327'),(25,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:39:09.620'),(26,8,'Changement statut','Factures',NULL,'id:10 — mark-sent','2026-06-15 15:39:42.473'),(27,8,'Changement statut','Factures',NULL,'id:10 — mark-paid','2026-06-15 15:39:49.137'),(28,8,'Changement statut','Factures',NULL,'id:2 — mark-sent','2026-06-15 15:44:13.715'),(29,8,'Changement statut','Factures',NULL,'id:2 — mark-paid','2026-06-15 15:44:41.323'),(30,8,'Changement statut','Factures',NULL,'id:6 — mark-sent','2026-06-15 15:44:53.758'),(31,8,'Changement statut','Factures',NULL,'id:6 — mark-paid','2026-06-15 15:44:56.615'),(32,8,'Changement statut','Factures',NULL,'id:3 — mark-sent','2026-06-15 15:45:38.712'),(33,8,'Changement statut','Factures',NULL,'id:3 — mark-paid','2026-06-15 15:45:43.561'),(34,8,'Changement statut','Factures',NULL,'id:4 — mark-sent','2026-06-15 15:45:53.508'),(35,8,'Changement statut','Factures',NULL,'id:4 — mark-paid','2026-06-15 15:45:55.873'),(36,8,'Changement statut','Factures',NULL,'id:8 — mark-sent','2026-06-15 15:46:02.700'),(37,8,'Changement statut','Factures',NULL,'id:8 — mark-paid','2026-06-15 15:46:04.589'),(38,8,'Changement statut','Factures',NULL,'id:7 — mark-sent','2026-06-15 15:46:13.973'),(39,8,'Changement statut','Factures',NULL,'id:7 — mark-paid','2026-06-15 15:46:15.943'),(40,8,'Changement statut','Factures',NULL,'id:9 — mark-sent','2026-06-15 15:46:31.566'),(41,8,'Changement statut','Factures',NULL,'id:9 — mark-paid','2026-06-15 15:46:33.883'),(42,8,'Changement statut','Factures',NULL,'id:5 — mark-sent','2026-06-15 15:46:51.865'),(43,8,'Changement statut','Factures',NULL,'id:5 — mark-paid','2026-06-15 15:46:54.147'),(44,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 15:52:46.894'),(45,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 15:53:10.098'),(46,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-15 16:20:10.972'),(47,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-06-15 20:07:57.796'),(48,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-15 20:08:17.485'),(49,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-16 09:05:47.524'),(50,8,'Paiement','Bulletins',NULL,'id:2','2026-06-16 11:49:16.972'),(51,8,'Paiement','Bulletins',NULL,'id:1','2026-06-16 11:49:21.573'),(52,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:58:36.613'),(53,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:58:41.541'),(54,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-19 12:59:30.330'),(55,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-19 13:00:12.597'),(56,8,'Changement statut','Factures',NULL,'id:12 — mark-sent','2026-06-19 13:01:19.520'),(57,8,'Changement statut','Factures',NULL,'id:12 — mark-paid','2026-06-19 13:01:24.183'),(58,8,'Changement statut','Factures',NULL,'id:13 — mark-sent','2026-06-19 13:01:35.394'),(59,8,'Changement statut','Factures',NULL,'id:13 — mark-paid','2026-06-19 13:01:36.935'),(60,8,'Changement statut','Factures',NULL,'id:11 — mark-sent','2026-06-19 13:01:46.390'),(61,8,'Changement statut','Factures',NULL,'id:11 — mark-paid','2026-06-19 13:01:48.299'),(62,8,'Paiement','Bulletins',NULL,'id:3','2026-06-19 13:03:18.702'),(63,8,'Paiement','Bulletins',NULL,'id:4','2026-06-19 13:04:31.277'),(64,8,'Paiement','Bulletins',NULL,'id:5','2026-06-19 13:08:58.383'),(65,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:39:51.185'),(66,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:39:54.441'),(67,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-22 09:40:06.037'),(68,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-22 13:18:16.332'),(69,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 13:34:01.376'),(70,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-22 13:41:05.998'),(71,8,'Changement statut','Factures',NULL,'id:14 — mark-sent','2026-06-22 13:41:36.211'),(72,8,'Changement statut','Factures',NULL,'id:1 — mark-sent','2026-06-22 13:42:10.299'),(73,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-23 10:02:22.962'),(74,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-06-23 10:03:40.673'),(75,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-23 10:04:03.664'),(76,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-23 11:24:58.471'),(77,9,'Modification','Factures',NULL,'id:15','2026-06-24 14:04:51.087'),(78,9,'Changement statut','Factures',NULL,'id:15 — mark-sent','2026-06-24 14:05:18.539'),(79,9,'Changement statut','Factures',NULL,'id:16 — mark-sent','2026-06-24 14:08:38.619'),(80,9,'Changement statut','Factures',NULL,'id:16 — mark-paid','2026-06-24 14:08:41.541'),(81,9,'Changement statut','Factures',NULL,'id:17 — mark-sent','2026-06-24 14:10:45.294'),(82,9,'Changement statut','Factures',NULL,'id:17 — mark-paid','2026-06-24 14:10:48.472'),(83,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-24 14:14:12.098'),(84,9,'Changement statut','Factures',NULL,'id:18 — mark-sent','2026-06-24 14:14:40.170'),(85,9,'Changement statut','Factures',NULL,'id:18 — mark-paid','2026-06-24 14:14:48.267'),(86,9,'LOGOUT','auth',NULL,'Déconnexion — edson.sharonne@usra-care.com','2026-06-24 14:15:02.389'),(87,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-24 14:15:32.001'),(88,9,'Changement statut','Factures',NULL,'id:19 — mark-sent','2026-06-24 14:17:44.277'),(89,9,'Changement statut','Factures',NULL,'id:19 — mark-paid','2026-06-24 14:17:46.842'),(90,9,'Changement statut','Factures',NULL,'id:20 — mark-sent','2026-06-24 14:19:45.338'),(91,9,'Changement statut','Factures',NULL,'id:20 — mark-paid','2026-06-24 14:19:48.190'),(92,9,'Changement statut','Factures',NULL,'id:22 — mark-sent','2026-06-24 14:54:58.400'),(93,9,'Changement statut','Factures',NULL,'id:22 — mark-paid','2026-06-24 14:55:01.485'),(94,9,'Changement statut','Factures',NULL,'id:23 — mark-sent','2026-06-24 15:02:10.885'),(95,9,'Changement statut','Factures',NULL,'id:23 — mark-paid','2026-06-24 15:02:45.217'),(96,9,'Changement statut','Factures',NULL,'id:24 — mark-sent','2026-06-24 15:07:34.701'),(97,9,'Changement statut','Factures',NULL,'id:24 — mark-paid','2026-06-24 15:07:39.910'),(98,9,'Modification','Factures',NULL,'id:25','2026-06-25 11:51:16.384'),(99,9,'Changement statut','Factures',NULL,'id:25 — mark-sent','2026-06-25 11:51:24.430'),(100,9,'Changement statut','Factures',NULL,'id:25 — mark-paid','2026-06-25 11:58:50.757'),(101,9,'Modification','Factures',NULL,'id:26','2026-06-25 12:03:43.720'),(102,9,'Changement statut','Factures',NULL,'id:26 — mark-sent','2026-06-25 12:03:51.117'),(103,9,'Changement statut','Factures',NULL,'id:26 — mark-paid','2026-06-25 12:03:53.243'),(104,9,'Changement statut','Factures',NULL,'id:27 — mark-sent','2026-06-25 12:04:21.990'),(105,9,'Changement statut','Factures',NULL,'id:27 — mark-paid','2026-06-25 12:04:25.210'),(106,9,'Changement statut','Factures',NULL,'id:21 — mark-sent','2026-06-25 12:06:42.982'),(107,9,'Changement statut','Factures',NULL,'id:28 — mark-sent','2026-06-25 12:34:41.048'),(108,9,'Changement statut','Factures',NULL,'id:28 — mark-paid','2026-06-25 12:34:56.160'),(109,9,'Modification','Factures',NULL,'id:29','2026-06-25 12:36:31.765'),(110,9,'Changement statut','Factures',NULL,'id:29 — mark-sent','2026-06-25 12:40:25.031'),(111,9,'Changement statut','Factures',NULL,'id:29 — mark-paid','2026-06-25 12:40:28.319'),(112,9,'Changement statut','Factures',NULL,'id:30 — mark-sent','2026-06-25 12:41:41.667'),(113,9,'Changement statut','Factures',NULL,'id:30 — mark-paid','2026-06-25 12:41:52.505'),(114,9,'Changement statut','Factures',NULL,'id:31 — mark-sent','2026-06-25 12:45:22.636'),(115,9,'Changement statut','Factures',NULL,'id:31 — mark-paid','2026-06-25 12:45:25.353'),(116,9,'Changement statut','Factures',NULL,'id:21 — mark-paid','2026-06-25 13:40:13.689'),(117,9,'Changement statut','Factures',NULL,'id:32 — mark-sent','2026-06-25 13:44:52.292'),(118,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-25 14:39:13.297'),(119,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-26 03:33:18.098'),(120,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-26 04:32:07.722'),(121,1,'Envoi email','Factures',NULL,'id:16 — penlapsaturin@gmail.com','2026-06-26 05:01:13.944'),(122,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-26 08:40:43.670'),(123,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-26 08:41:00.642'),(124,8,'Changement statut','Factures',NULL,'id:33 — mark-sent','2026-06-26 08:43:40.759'),(125,8,'Changement statut','Factures',NULL,'id:34 — mark-sent','2026-06-26 08:49:10.258'),(126,8,'Changement statut','Factures',NULL,'id:34 — mark-paid','2026-06-26 08:49:11.794'),(127,8,'Changement statut','Factures',NULL,'id:35 — mark-sent','2026-06-26 08:53:26.865'),(128,8,'Changement statut','Factures',NULL,'id:36 — mark-sent','2026-06-26 08:55:30.124'),(129,8,'Paiement','Bulletins',NULL,'id:6','2026-06-26 08:59:12.235'),(130,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-27 10:39:22.522'),(131,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-06-27 10:39:40.590'),(132,8,'Changement statut','Factures',NULL,'id:33 — mark-paid','2026-06-27 10:40:05.175'),(133,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-06-27 10:40:31.012'),(134,8,'Paiement','Bulletins',NULL,'id:7','2026-06-27 10:41:41.455'),(135,8,'Changement statut','Factures',NULL,'id:1 — mark-paid','2026-06-27 10:50:43.506'),(136,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-06-29 07:10:09.876'),(137,9,'Changement statut','Factures',NULL,'id:15 — mark-paid','2026-06-29 07:10:51.956'),(138,9,'Envoi email','Factures',NULL,'id:32 — junior.chendjou@mbac.mg','2026-06-29 07:11:13.578'),(139,9,'Changement statut','Factures',NULL,'id:37 — mark-sent','2026-06-29 12:52:36.607'),(140,9,'Changement statut','Factures',NULL,'id:37 — mark-paid','2026-06-29 12:52:38.938'),(141,9,'Changement statut','Factures',NULL,'id:38 — mark-sent','2026-06-29 12:55:53.281'),(142,9,'Changement statut','Factures',NULL,'id:38 — mark-paid','2026-06-29 12:55:55.069'),(143,9,'Changement statut','Factures',NULL,'id:39 — mark-sent','2026-06-29 13:08:49.514'),(144,9,'Changement statut','Factures',NULL,'id:39 — mark-paid','2026-06-29 13:08:54.030'),(145,9,'Changement statut','Factures',NULL,'id:40 — mark-sent','2026-06-29 13:13:38.730'),(146,9,'Changement statut','Factures',NULL,'id:40 — mark-paid','2026-06-29 13:13:43.930'),(147,9,'Changement statut','Factures',NULL,'id:41 — mark-sent','2026-06-29 13:25:43.601'),(148,9,'Changement statut','Factures',NULL,'id:41 — mark-paid','2026-06-29 13:25:46.545'),(149,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-30 09:01:36.047'),(150,9,'Changement statut','Factures',NULL,'id:42 — mark-sent','2026-06-30 15:07:03.012'),(151,9,'Changement statut','Factures',NULL,'id:43 — mark-sent','2026-07-01 11:02:41.531'),(152,9,'Changement statut','Factures',NULL,'id:44 — mark-sent','2026-07-01 11:13:28.077'),(153,9,'Changement statut','Factures',NULL,'id:44 — mark-paid','2026-07-01 11:13:36.572'),(154,9,'Changement statut','Factures',NULL,'id:45 — mark-sent','2026-07-01 11:15:17.429'),(155,9,'Changement statut','Factures',NULL,'id:45 — mark-paid','2026-07-01 11:16:21.621'),(156,9,'Modification','Factures',NULL,'id:46','2026-07-01 11:45:26.923'),(157,9,'Changement statut','Factures',NULL,'id:46 — mark-sent','2026-07-01 11:57:35.211'),(158,9,'Changement statut','Factures',NULL,'id:46 — mark-paid','2026-07-01 11:58:10.960'),(159,9,'Changement statut','Factures',NULL,'id:47 — mark-sent','2026-07-01 12:02:28.557'),(160,9,'Changement statut','Factures',NULL,'id:47 — mark-paid','2026-07-01 12:02:33.313'),(161,9,'Changement statut','Factures',NULL,'id:49 — mark-sent','2026-07-01 12:12:30.795'),(162,9,'Changement statut','Factures',NULL,'id:49 — mark-paid','2026-07-01 12:12:32.818'),(163,9,'Changement statut','Factures',NULL,'id:50 — mark-sent','2026-07-01 12:12:46.370'),(164,9,'Changement statut','Factures',NULL,'id:50 — mark-paid','2026-07-01 12:12:49.191'),(165,9,'Changement statut','Factures',NULL,'id:48 — mark-sent','2026-07-01 12:13:00.709'),(166,9,'Changement statut','Factures',NULL,'id:48 — mark-paid','2026-07-01 12:13:14.115'),(167,9,'Changement statut','Factures',NULL,'id:32 — set-acompte','2026-07-01 13:48:31.170'),(168,9,'Changement statut','Factures',NULL,'id:42 — mark-paid','2026-07-01 14:47:45.518'),(169,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-02 15:35:54.530'),(170,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-02 15:36:09.023'),(171,8,'Changement statut','Factures',NULL,'id:14 — mark-paid','2026-07-02 15:36:34.509'),(172,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-02 15:36:40.757'),(173,8,'Changement statut','Factures',NULL,'id:35 — mark-paid','2026-07-02 15:36:53.317'),(174,8,'Paiement','Bulletins',NULL,'id:8','2026-07-02 15:40:49.704'),(175,8,'Paiement','Bulletins',NULL,'id:9','2026-07-02 15:41:33.877'),(176,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-06 11:24:05.061'),(177,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-06 15:00:15.997'),(178,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-06 15:38:49.768'),(179,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-06 15:39:02.490'),(180,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-06 15:39:18.367'),(181,8,'Changement statut','Factures',NULL,'id:36 — mark-paid','2026-07-06 15:40:16.455'),(182,8,'Paiement','Bulletins',NULL,'id:10','2026-07-06 15:45:13.583'),(183,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-07 05:41:49.377'),(184,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-09 09:40:15.434'),(185,9,'Changement statut','Factures',NULL,'id:43 — mark-paid','2026-07-10 06:26:45.878'),(186,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-10 10:25:37.870'),(187,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-10 12:44:58.866'),(188,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-10 13:46:01.403'),(189,8,'Changement statut','Factures',NULL,'id:52 — mark-sent','2026-07-10 13:49:56.375'),(190,8,'Changement statut','Factures',NULL,'id:52 — mark-paid','2026-07-10 13:49:58.780'),(191,8,'Paiement','Bulletins',NULL,'id:11','2026-07-10 14:00:43.498'),(192,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-13 21:58:34.780'),(193,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-14 10:51:24.664'),(194,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-14 11:51:44.009'),(195,9,'Changement statut','Factures',NULL,'id:51 — mark-sent','2026-07-15 06:23:58.542'),(196,9,'Changement statut','Factures',NULL,'id:51 — mark-paid','2026-07-15 06:24:01.651'),(197,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-15 10:10:15.025'),(198,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-15 10:10:34.306'),(199,8,'Changement statut','Factures',NULL,'id:53 — mark-sent','2026-07-15 10:13:24.865'),(200,8,'Changement statut','Factures',NULL,'id:54 — mark-sent','2026-07-15 10:15:34.389'),(201,9,'Changement statut','Factures',NULL,'id:55 — mark-sent','2026-07-15 13:57:57.641'),(202,9,'Changement statut','Factures',NULL,'id:57 — mark-sent','2026-07-15 14:27:20.949'),(203,9,'Changement statut','Factures',NULL,'id:57 — mark-paid','2026-07-15 14:27:23.303'),(204,9,'Changement statut','Factures',NULL,'id:58 — mark-sent','2026-07-15 14:27:45.830'),(205,9,'Changement statut','Factures',NULL,'id:58 — mark-paid','2026-07-15 14:27:53.376'),(206,9,'Changement statut','Factures',NULL,'id:56 — mark-sent','2026-07-15 14:28:01.891'),(207,9,'Changement statut','Factures',NULL,'id:56 — mark-paid','2026-07-15 14:28:03.753'),(208,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-18 10:48:52.130'),(209,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-18 10:49:08.282'),(210,8,'Changement statut','Factures',NULL,'id:53 — mark-paid','2026-07-18 10:50:26.809'),(211,8,'Changement statut','Factures',NULL,'id:54 — mark-paid','2026-07-18 10:50:38.427'),(212,8,'Paiement','Bulletins',NULL,'id:30','2026-07-18 10:57:52.898'),(213,8,'Paiement','Bulletins',NULL,'id:29','2026-07-18 10:57:54.538'),(214,8,'Paiement','Bulletins',NULL,'id:28','2026-07-18 10:57:55.822'),(215,8,'Paiement','Bulletins',NULL,'id:27','2026-07-18 10:57:56.860'),(216,8,'Paiement','Bulletins',NULL,'id:26','2026-07-18 10:57:58.523'),(217,8,'Paiement','Bulletins',NULL,'id:22','2026-07-18 10:58:04.895'),(218,8,'Paiement','Bulletins',NULL,'id:22','2026-07-18 10:58:05.605'),(219,8,'Paiement','Bulletins',NULL,'id:23','2026-07-18 10:58:06.566'),(220,8,'Paiement','Bulletins',NULL,'id:24','2026-07-18 10:58:07.647'),(221,8,'Paiement','Bulletins',NULL,'id:25','2026-07-18 10:58:08.808'),(222,8,'Paiement','Bulletins',NULL,'id:31','2026-07-18 10:59:14.480'),(223,8,'Paiement','Bulletins',NULL,'id:31','2026-07-18 10:59:15.201'),(224,8,'Paiement','Bulletins',NULL,'id:32','2026-07-18 11:00:00.351'),(225,8,'Paiement','Bulletins',NULL,'id:33','2026-07-18 11:00:35.034'),(226,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-20 10:11:37.205'),(227,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-20 10:30:12.993'),(228,9,'Paiement','Bulletins',NULL,'id:21','2026-07-20 10:41:22.357'),(229,9,'Paiement','Bulletins',NULL,'id:20','2026-07-20 10:41:28.420'),(230,9,'Paiement','Bulletins',NULL,'id:19','2026-07-20 10:41:38.477'),(231,9,'Paiement','Bulletins',NULL,'id:18','2026-07-20 10:41:40.574'),(232,9,'Paiement','Bulletins',NULL,'id:17','2026-07-20 10:41:42.646'),(233,9,'Paiement','Bulletins',NULL,'id:16','2026-07-20 10:41:44.911'),(234,9,'Paiement','Bulletins',NULL,'id:15','2026-07-20 10:42:02.151'),(235,9,'Paiement','Bulletins',NULL,'id:14','2026-07-20 10:42:04.189'),(236,9,'Paiement','Bulletins',NULL,'id:13','2026-07-20 10:42:06.880'),(237,9,'Paiement','Bulletins',NULL,'id:12','2026-07-20 10:42:08.931'),(238,9,'Changement statut','Factures',NULL,'id:59 — mark-sent','2026-07-21 06:58:07.849'),(239,9,'Changement statut','Factures',NULL,'id:60 — mark-sent','2026-07-21 13:19:17.776'),(240,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-22 16:27:56.870'),(241,1,'LOGOUT','auth',NULL,'Déconnexion — admin@usra-care.com','2026-07-22 16:29:13.550'),(242,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-22 16:36:13.672'),(243,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-22 16:58:40.871'),(244,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-22 17:28:31.941'),(245,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-22 17:38:21.342'),(246,9,'Changement statut','Factures',NULL,'id:60 — mark-paid','2026-07-23 14:32:59.040'),(247,9,'Changement statut','Factures',NULL,'id:61 — mark-sent','2026-07-23 15:07:01.872'),(248,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-23 20:57:21.204'),(249,8,'LOGOUT','auth',NULL,'Déconnexion — leonie.voukeng@carebusinessconsulting.com','2026-07-23 20:58:19.737'),(250,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-23 21:10:17.918'),(251,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-25 09:28:49.866'),(252,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-25 09:29:07.341'),(253,8,'Changement statut','Factures',NULL,'id:63 — mark-sent','2026-07-25 09:31:29.525'),(254,8,'Changement statut','Factures',NULL,'id:64 — mark-sent','2026-07-25 09:32:58.166'),(255,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-07-26 07:58:14.009'),(256,9,'Changement statut','Factures',NULL,'id:59 — mark-paid','2026-07-26 07:58:43.229'),(257,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-27 09:28:20.290'),(258,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-27 09:29:11.757'),(259,8,'Changement statut','Factures',NULL,'id:63 — mark-paid','2026-07-27 09:29:45.542'),(260,8,'Changement statut','Factures',NULL,'id:65 — mark-sent','2026-07-27 09:31:22.532'),(261,8,'Changement statut','Factures',NULL,'id:66 — mark-sent','2026-07-27 09:36:13.195'),(262,8,'LOGIN_FAILED','auth',NULL,'Mot de passe incorrect — leonie.voukeng@carebusinessconsulting.com','2026-07-27 09:40:14.163'),(263,9,'Changement statut','Factures',NULL,'id:62 — mark-sent','2026-07-27 14:23:01.626'),(264,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-28 21:33:48.714'),(265,9,'Paiement','Bulletins',NULL,'id:36','2026-07-29 13:59:14.353'),(266,9,'Paiement','Bulletins',NULL,'id:37','2026-07-29 13:59:31.016'),(267,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-07-31 07:32:01.063'),(268,8,'Changement statut','Factures',NULL,'id:64 — mark-paid','2026-07-31 07:32:41.368'),(269,8,'Changement statut','Factures',NULL,'id:66 — mark-paid','2026-07-31 07:32:52.522'),(270,8,'Paiement','Bulletins',NULL,'id:38','2026-07-31 07:34:59.459'),(271,8,'Paiement','Bulletins',NULL,'id:39','2026-07-31 07:35:19.485'),(272,8,'Paiement','Bulletins',NULL,'id:40','2026-07-31 07:35:55.079'),(273,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-07-31 09:14:21.279'),(274,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-08-01 10:52:12.202'),(275,8,'Changement statut','Factures',NULL,'id:65 — mark-paid','2026-08-01 10:52:52.980'),(276,8,'Paiement','Bulletins',NULL,'id:41','2026-08-01 10:55:14.594'),(277,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-08-07 16:03:35.661'),(278,8,'Changement statut','Factures',NULL,'id:67 — mark-sent','2026-08-07 16:08:34.347'),(279,8,'Changement statut','Factures',NULL,'id:68 — mark-sent','2026-08-07 16:10:34.015'),(280,8,'Changement statut','Factures',NULL,'id:69 — mark-sent','2026-08-07 16:12:13.571'),(281,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-08-10 15:04:38.144'),(282,8,'Changement statut','Factures',NULL,'id:70 — mark-sent','2026-08-10 15:07:58.119'),(283,8,'Changement statut','Factures',NULL,'id:70 — mark-paid','2026-08-10 15:08:00.964'),(284,8,'Changement statut','Factures',NULL,'id:71 — mark-sent','2026-08-10 15:23:51.755'),(285,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-08-11 15:31:59.894'),(286,8,'Paiement','Bulletins',NULL,'id:44','2026-08-11 15:37:40.619'),(287,8,'Changement statut','Factures',NULL,'id:67 — mark-paid','2026-08-11 15:39:18.041'),(288,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-08-12 08:52:30.269'),(289,1,'Changement statut','Factures',NULL,'id:62 — mark-paid','2026-08-12 08:54:22.866'),(290,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-08-13 06:47:11.081'),(291,9,'Changement statut','Factures',NULL,'id:61 — mark-paid','2026-08-13 06:50:16.823'),(292,8,'LOGIN','auth',NULL,'Connexion réussie — leonie.voukeng@carebusinessconsulting.com','2026-08-15 14:03:00.224'),(293,8,'Changement statut','Factures',NULL,'id:71 — mark-paid','2026-08-15 14:08:11.878'),(294,8,'Paiement','Bulletins',NULL,'id:43','2026-08-15 14:12:30.856'),(295,8,'Paiement','Bulletins',NULL,'id:45','2026-08-15 14:12:49.311'),(296,9,'LOGIN','auth',NULL,'Connexion réussie — edson.sharonne@usra-care.com','2026-08-17 05:35:03.445'),(297,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-08-18 07:46:22.577'),(298,9,'Changement statut','Factures',NULL,'id:55 — mark-paid','2026-08-18 13:16:16.886'),(299,9,'Changement statut','Factures',NULL,'id:72 — mark-sent','2026-08-18 13:18:43.376'),(300,9,'Changement statut','Factures',NULL,'id:72 — mark-paid','2026-08-18 13:18:46.194'),(301,9,'Changement statut','Factures',NULL,'id:73 — mark-sent','2026-08-18 13:22:23.268'),(302,9,'Changement statut','Factures',NULL,'id:73 — mark-paid','2026-08-18 13:22:35.954'),(303,9,'Paiement','Bulletins',NULL,'id:34','2026-08-18 13:28:04.994'),(304,9,'Paiement','Bulletins',NULL,'id:34','2026-08-18 13:28:07.915'),(305,9,'Paiement','Bulletins',NULL,'id:35','2026-08-18 13:28:10.915');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Candidate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'M',
  `birthDate` datetime(3) DEFAULT NULL,
  `nationalId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorJob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primarySpecialtyId` int DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'applied',
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'walk_in',
  `paymentMethodPref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mobile_money',
  `mobileMoneyAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recruitedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Candidate_countryId_fkey` (`countryId`),
  KEY `Candidate_officeId_fkey` (`officeId`),
  CONSTRAINT `Candidate_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Candidate_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
INSERT INTO `Candidate` VALUES (1,2,NULL,' NATHALIE','DJOUGUEP','F','1985-04-20 00:00:00.000','KIT 280','693236926','','','BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:04:17.457','2026-06-15 16:33:12.739'),(2,2,NULL,'ELIANE LESLINE','TCHUATCHU','F','1984-03-28 00:00:00.000','AA01984942','670067385','','','BEPANDA','DOUALA',NULL,'DJEUKOU RAIMOND','699113067','MARI','','','','DJEUKOU RAYMOND','699113067',NULL,NULL,NULL,1,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:15:31.141','2026-06-15 16:33:01.572'),(3,2,NULL,'ASTA FANTA','ANTASSAR','F','1988-07-17 00:00:00.000','KIT 159','656200331','','','NOUVELLE ROUTE NGANGUE','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:18:29.027','2026-06-15 16:32:46.204'),(4,2,NULL,'AGNES','SINGUI','F','1988-06-06 00:00:00.000','100410867','695126955','','','SABLE BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:20:03.778','2026-06-15 16:32:33.784'),(5,2,NULL,'SANTANA','YAMENI','F','2002-11-23 00:00:00.000','KIT 123','640025561','','','BONABERI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:26:44.818','2026-06-15 16:31:58.530'),(6,2,NULL,'PRUDENCE','AWA A ETONG','F','1989-12-24 00:00:00.000','KIT216','691 42 71 56','','','MAKEPE ROND POINT PETIT PAYS','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:29:53.310','2026-07-10 14:08:59.382'),(7,2,NULL,'ANNE DANIELLE MICHELLE','NGO HAGBE','F','2003-10-11 00:00:00.000','101924727','678665167','','','BEEDI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:32:55.219','2026-06-15 16:32:08.442'),(8,2,3,'AMELINE','GATUE','F','2004-04-19 00:00:00.000','000588102','698812623','','','BONAMOUSSADI','DOUALA',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'placed','walk_in','mobile_money','','','',NULL,'2026-06-15 14:35:53.918','2026-06-15 16:32:18.715'),(9,1,1,'Ianjasoa Nekena','LAINGO Harimalala ','F','1996-12-05 00:00:00.000','104072006754','0344334879','0342422921','Laingoharimalalaianjasoanekena@gmail.com','AB 55 TER Ankadidravola','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,1,'placed','walk_in','cash','','','',NULL,'2026-06-24 13:48:25.286','2026-07-16 13:24:33.610'),(10,1,1,'Marthe','RAVAOHARISOA','F','1979-07-05 00:00:00.000','102392001474','0343266389','0348073509','marthe@gmail.com','Mahavoky Sud','Mahajanga',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,1,'placed','referral','mobile_money','0348073509','','',NULL,'2026-06-24 14:31:16.255','2026-07-16 13:25:08.564'),(11,1,1,'Jean Marc','RAMANOELINA','M','1987-02-28 00:00:00.000','101251140272','0336671312','0348918820','jeanmarc@gmail.com','Ivato Andavandomby','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','referral','cash','','','',NULL,'2026-06-25 12:23:19.204','2026-07-16 13:25:48.471'),(12,1,1,'Rija Yvon','RAZAFIMANDIMBY','M','1984-04-01 00:00:00.000','415011003835','0320742670','','rijaymandimby@gmail.com','Lot II A4T ter CU Amboditsiry ','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'interviewed','social','mobile_money','','','',NULL,'2026-06-30 06:37:19.829','2026-06-30 07:17:18.952'),(13,1,1,'Fiavisoa ','MAMININDRIANA','F','1998-03-13 00:00:00.000','117122017677','0343074088','','','Lot 34 E Ter Imerinafivoany Antanifotsy','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'interviewed','online','cash','','','',NULL,'2026-06-30 06:41:17.197','2026-06-30 07:17:55.953'),(14,1,1,'Mamy Christian','RANDRIANARIVO','M','1969-05-11 00:00:00.000','101211111089','0343263445','','','Ambomiandra','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','social','cash','','','',NULL,'2026-06-30 06:45:22.240','2026-07-16 13:29:18.547'),(15,1,1,'Anjarivoniaina','RAMANAMAHEFA','M','1995-09-16 00:00:00.000','110251009178','0343304382','','rivoniainaanja@gmail.com','Ambatomainty','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','social','mobile_money','0343304382','','',NULL,'2026-06-30 07:25:31.887','2026-07-16 13:31:07.205'),(16,1,1,'Heridimbisoa','RAKOTOARIMANANA','M','1971-07-27 00:00:00.000','101981042418','0381956752','','','Lot NJ 84Ambohimiadana Nord Tana','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','social','cash','','','',NULL,'2026-06-30 07:30:16.940','2026-07-16 13:30:51.141'),(17,1,1,'Minoheriniaina','RAKOTONDRAFARA','M','1981-07-10 00:00:00.000','103071006355','0342319289','','rakotondrafaratanjona@gmail.com','Lot IA 52 Bis Ambohibao','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'suspended','walk_in','cash','','','',NULL,'2026-06-30 07:36:14.200','2026-07-16 13:30:36.993'),(18,1,1,'Marie Chantal Olga','RASOANIRINA','F','1988-07-17 00:00:00.000','202052008548','0382695809','','','Tanjondava Talatamaty','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,7,'suspended','walk_in','cash','','','',NULL,'2026-06-30 08:10:23.034','2026-07-16 13:30:15.355'),(19,1,1,'Joeline','RASOAMANANJARA','F','1979-11-03 00:00:00.000','206172001057','0345521360','','','Lot K7 à-& Mamory Ivato','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,1,'placed','referral','cash','','','',NULL,'2026-06-30 08:14:58.898','2026-07-16 13:30:00.167'),(20,1,1,'Fiacre','RAZAFINDRAROVA','M','1979-08-05 00:00:00.000','201601010117','0385469425','','','Ankadindravola','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'suspended','referral','cash','','','',NULL,'2026-06-30 08:21:04.879','2026-07-26 08:16:26.367'),(21,1,1,'Felana','RAKATONJATOVO','F','1985-03-03 00:00:00.000','103052008135','0344062239','','','Ambohidratrimo','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,1,'placed','referral','cash','','','',NULL,'2026-06-30 08:26:57.620','2026-07-11 05:24:01.018'),(22,1,1,'Heriniaina Maurice','RANDRIANANDRASANA','M','1974-10-17 00:00:00.000','201031008735','0344042169',NULL,NULL,'Lot IIIS 144DA Ouest Mananjary','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'applied','walk_in','mobile_money',NULL,NULL,NULL,NULL,'2026-06-30 10:37:53.618','2026-06-30 10:37:53.618'),(23,1,1,'Colette','BAKOLINIRINA','F','1973-08-29 00:00:00.000','201032007917','0346809723','0346056610',NULL,'Lot III S 144 DA Ouest Mananjara','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'applied','walk_in','mobile_money',NULL,NULL,NULL,NULL,'2026-06-30 10:42:20.586','2026-06-30 10:42:20.586'),(24,1,1,'Tinahinjanahary Sandra','TEMA','F','1997-02-28 00:00:00.000','516012032923','0387849560','0331187826','sandra@gmail.com','Lot 105 KS ter 10M Ivato','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,7,'placed','social','cash','','','',NULL,'2026-07-01 10:29:55.335','2026-07-16 13:47:34.247'),(25,1,1,'Koloina Fandresena','HERINIRINA','M','2003-12-02 00:00:00.000','404011017038','0388102952','0350510609','herinirinakoloinafandresena0@gmail.com','127A Antanetibe Ivato','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','walk_in','cash','','','',NULL,'2026-07-16 06:59:31.015','2026-07-22 12:21:50.010'),(26,1,1,'Donine','FANANTENANTSOA','F','2007-01-19 00:00:00.000','202012025468','0349069915','','','IIF34ERJKO Andavapananina Andraisoro','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,'applied','social','mobile_money','','','',NULL,'2026-07-16 08:14:06.009','2026-07-16 08:14:46.887'),(27,1,1,'Tojo Henintsoa Fabrice','RANDRIANANDRASANA','F','1998-03-21 00:00:00.000','1012511196494','0346951270','','randrianandrasanaTojohenintsoa@gmail.com','IIA105 VRL Bis B Nanisana','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'suspended','social','cash','','','',NULL,'2026-07-16 08:53:31.726','2026-07-16 13:46:46.052'),(28,1,NULL,'Sitrakiniaina Augustine','RAJANOMEZANTSOA','F','2007-08-05 00:00:00.000','202092012204','00000000',NULL,NULL,'III U 194 Ankazotoho Anosimahavelona','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'applied','walk_in','mobile_money',NULL,NULL,NULL,NULL,'2026-07-16 09:21:15.054','2026-07-16 09:21:15.054'),(29,1,1,'Cael Harrisson','ETSITABABO','M','1978-03-11 00:00:00.000','101231111419','0343150713',NULL,NULL,'II321 Bis Ambohidahy Ankadidramamy','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'applied','walk_in','mobile_money',NULL,NULL,NULL,NULL,'2026-07-16 12:32:41.711','2026-07-16 12:32:41.711'),(30,1,1,'Lovasoa Mamitiana','NOMENJANAHARY','F','2001-04-10 00:00:00.000','101251215352','0345838749','','','034TER A Andoarano Ivato','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'applied','social','mobile_money','','','',NULL,'2026-07-16 12:38:02.159','2026-07-16 13:23:15.501'),(31,1,1,'Fiavisoa','MAMININDRINA','F','1998-03-13 00:00:00.000','117122017677','0343074088','','','94E Ter Imerinafovoany Antanifotsy','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,7,'interviewed','social','mobile_money','','','',NULL,'2026-07-16 12:55:18.101','2026-07-16 13:17:02.746'),(32,1,1,'Rija Yvon','RAZAFIMANDIMBY','F','1984-04-01 00:00:00.000','415011056835','0320742670',NULL,'rijarzmandimby@gmail.com','IIA 4T TER CK Amboditsiry','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,'suspended','social','cash',NULL,NULL,NULL,NULL,'2026-07-16 13:11:11.149','2026-07-16 13:11:11.149'),(33,1,1,'Jet-Lee Dafort','RAZAFITSALAMA','M','1998-07-18 00:00:00.000','210011039105','0346680134','','danfortrazafitsalama@gmail.com','Lot 109 A TER Ambohibao','Antananarivo',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,4,'placed','social','cash','','','',NULL,'2026-07-22 08:30:41.405','2026-08-17 05:39:47.914'),(34,1,1,'Nicole','TSIARASO','F','1987-03-07 00:00:00.000','101232137788','0346668969',NULL,'Tsiarasonicole09@gmail.com','Lot 85 Ter Amboaroy Ambohijanahary Antehiroka','Antananarivo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'validated','social','cash',NULL,NULL,NULL,NULL,'2026-07-27 07:24:50.064','2026-07-27 07:24:50.064');
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateSpecialty`
--

DROP TABLE IF EXISTS `CandidateSpecialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateSpecialty` (
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `isPrimary` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`candidateId`,`serviceId`),
  KEY `CandidateSpecialty_serviceId_fkey` (`serviceId`),
  CONSTRAINT `CandidateSpecialty_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateSpecialty_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateSpecialty`
--

LOCK TABLES `CandidateSpecialty` WRITE;
/*!40000 ALTER TABLE `CandidateSpecialty` DISABLE KEYS */;
INSERT INTO `CandidateSpecialty` VALUES (2,1,1),(9,1,1),(10,1,1),(11,4,1),(14,4,1),(15,4,1),(16,4,1),(17,4,1),(18,7,1),(19,1,1),(20,4,1),(21,1,1),(24,7,1),(25,4,1),(27,4,1),(30,4,1),(31,7,1),(32,4,1),(33,4,1),(34,3,1);
/*!40000 ALTER TABLE `CandidateSpecialty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CashEntry`
--

DROP TABLE IF EXISTS `CashEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CashEntry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CashEntry_countryId_fkey` (`countryId`),
  CONSTRAINT `CashEntry_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CashEntry`
--

LOCK TABLES `CashEntry` WRITE;
/*!40000 ALTER TABLE `CashEntry` DISABLE KEYS */;
INSERT INTO `CashEntry` VALUES (2,2,'expense','charge','2026-06-19 00:00:00.000',7550,'Transport; Recharge eau; Achat papier hygiénique et Frais de retrait des salaires','','2026-06-19 13:17:13.027'),(5,2,'expense','charge','2026-06-25 00:00:00.000',10850,'frais de transport Accent Média, recharge prepayer cbc, recharge credit mensuel des appels et frais de retrait de 50K','','2026-06-26 09:19:04.008'),(8,2,'expense','charge','2026-06-27 00:00:00.000',1600,'Transport lycée de makepe , frais de retrait','','2026-06-27 10:47:49.651'),(10,1,'income','encaissement','2026-06-29 12:52:38.916',1500000,'Facture MG-2026-0018',NULL,'2026-06-29 14:03:09.000'),(11,1,'income','encaissement','2026-06-29 12:55:55.042',1500000,'Facture MG-2026-0019',NULL,'2026-06-29 14:03:09.000'),(12,2,'income','encaissement','2026-04-27 00:00:00.000',65000,'Facture CM-2026-0001',NULL,'2026-06-29 14:03:09.000'),(13,2,'income','encaissement','2026-04-27 00:00:00.000',80000,'Facture CM-2026-0002',NULL,'2026-06-29 14:03:09.000'),(14,2,'income','encaissement','2026-05-08 00:00:00.000',66000,'Facture CM-2026-0003',NULL,'2026-06-29 14:03:09.000'),(16,2,'income','encaissement','2026-05-25 00:00:00.000',80000,'Facture CM-2026-0005',NULL,'2026-06-29 14:03:09.000'),(17,2,'income','encaissement','2026-04-27 00:00:00.000',65000,'Facture CM-2026-0006',NULL,'2026-06-29 14:03:09.000'),(18,2,'income','encaissement','2026-05-25 00:00:00.000',60000,'Facture CM-2026-0007',NULL,'2026-06-29 14:03:09.000'),(19,2,'income','encaissement','2026-05-25 00:00:00.000',65000,'Facture CM-2026-0008',NULL,'2026-06-29 14:03:09.000'),(20,2,'income','encaissement','2026-06-01 00:00:00.000',85000,'Facture CM-2026-0009',NULL,'2026-06-29 14:03:09.000'),(21,2,'income','encaissement','2026-06-01 00:00:00.000',65000,'Facture CM-2026-0010',NULL,'2026-06-29 14:03:09.000'),(22,2,'income','encaissement','2026-06-08 00:00:00.000',66000,'Facture CM-2026-0011',NULL,'2026-06-29 14:03:09.000'),(23,2,'income','encaissement','2026-06-15 00:00:00.000',25000,'Facture CM-2026-0012',NULL,'2026-06-29 14:03:09.000'),(24,2,'income','encaissement','2026-06-15 00:00:00.000',55000,'Facture CM-2026-0013',NULL,'2026-06-29 14:03:09.000'),(25,1,'income','encaissement','2026-06-24 00:00:00.000',300000,'Facture MG-2026-0001',NULL,'2026-06-29 14:03:09.000'),(26,1,'income','encaissement','2026-01-22 00:00:00.000',300000,'Facture MG-2026-0002',NULL,'2026-06-29 14:03:09.000'),(27,1,'income','encaissement','2026-02-19 00:00:00.000',300000,'Facture MG-2026-0003',NULL,'2026-06-29 14:03:09.000'),(28,1,'income','encaissement','2026-03-30 00:00:00.000',300000,'Facture MG-2026-0004',NULL,'2026-06-29 14:03:09.000'),(29,1,'income','encaissement','2026-04-28 00:00:00.000',300000,'Facture MG-2026-0005',NULL,'2026-06-29 14:03:09.000'),(30,1,'income','encaissement','2026-05-28 00:00:00.000',300000,'Facture MG-2026-0006',NULL,'2026-06-29 14:03:09.000'),(31,1,'income','encaissement','2026-06-24 00:00:00.000',250000,'Facture MG-2026-0007',NULL,'2026-06-29 14:03:09.000'),(32,1,'income','encaissement','2026-05-28 00:00:00.000',250000,'Facture MG-2026-0008',NULL,'2026-06-29 14:03:09.000'),(33,1,'income','encaissement','2026-04-29 00:00:00.000',250000,'Facture MG-2026-0009',NULL,'2026-06-29 14:03:09.000'),(34,1,'income','encaissement','2026-03-30 00:00:00.000',250000,'Facture MG-2026-0010',NULL,'2026-06-29 14:03:09.000'),(35,1,'income','encaissement','2026-02-26 00:00:00.000',250000,'Facture MG-2026-0011',NULL,'2026-06-29 14:03:09.000'),(36,1,'income','encaissement','2026-01-29 00:00:00.000',250000,'Facture MG-2026-0012',NULL,'2026-06-29 14:03:09.000'),(37,1,'income','encaissement','2025-12-29 00:00:00.000',250000,'Facture MG-2025-0001',NULL,'2026-06-29 14:03:09.000'),(38,1,'income','encaissement','2026-06-09 00:00:00.000',300000,'Facture MG-2026-0013',NULL,'2026-06-29 14:03:09.000'),(39,1,'income','encaissement','2026-05-26 00:00:00.000',300000,'Facture MG-2026-0014',NULL,'2026-06-29 14:03:09.000'),(40,1,'income','encaissement','2026-04-30 00:00:00.000',300000,'Facture MG-2026-0015',NULL,'2026-06-29 14:03:09.000'),(41,1,'income','encaissement','2026-04-01 00:00:00.000',80000,'Facture MG-2026-0016',NULL,'2026-06-29 14:03:09.000'),(42,2,'income','encaissement','2026-06-26 00:00:00.000',80000,'Facture CM-2026-0015',NULL,'2026-06-29 14:03:09.000'),(43,2,'income','encaissement','2026-06-26 00:00:00.000',60000,'Facture CM-2026-0016',NULL,'2026-06-29 14:03:09.000'),(44,1,'income','encaissement','2026-06-29 13:08:54.004',1472000,'Facture MG-2026-0020',NULL,'2026-06-29 14:03:09.000'),(45,1,'income','encaissement','2026-06-29 13:13:43.905',1600000,'Facture MG-2026-0021',NULL,'2026-06-29 14:03:09.000'),(46,1,'income','encaissement','2026-06-29 13:25:46.523',1744000,'Facture MG-2026-0022',NULL,'2026-06-29 14:03:09.000'),(73,1,'expense','salaire','2026-06-25 00:00:00.000',200000,'Salaire mois de Juin ','','2026-06-30 07:58:54.797'),(74,1,'expense','salaire','2026-07-01 00:00:00.000',400000,'Salaire Mr Mamy Chauffeur Mr Junior mois de Juin','','2026-07-01 10:09:24.737'),(75,1,'expense','salaire','2026-06-02 00:00:00.000',187000,'Salaire Mr Mamy chauffeur Mr Junior Mois de Mai','','2026-07-01 10:13:00.096'),(76,1,'expense','salaire','2026-07-01 00:00:00.000',195000,'Salaire Mr Tanjona Chauffeur Mr Junior Mois de Juin','','2026-07-01 10:13:46.918'),(77,1,'income','encaissement','2026-07-01 11:13:36.549',250000,'Facture MG-2026-0025',NULL,'2026-07-01 11:13:36.550'),(78,1,'income','encaissement','2026-07-01 11:16:21.596',250000,'Facture MG-2026-0026',NULL,'2026-07-01 11:16:21.597'),(79,1,'income','encaissement','2026-07-01 11:58:10.933',250000,'Facture MG-2026-0027',NULL,'2026-07-01 11:58:10.934'),(80,1,'income','encaissement','2026-07-01 12:02:33.288',250000,'Facture MG-2026-0028',NULL,'2026-07-01 12:02:33.288'),(81,1,'income','encaissement','2026-07-01 12:12:32.796',250000,'Facture MG-2025-0002',NULL,'2026-07-01 12:12:32.797'),(82,1,'income','encaissement','2026-07-01 12:12:49.165',250000,'Facture MG-2025-0003',NULL,'2026-07-01 12:12:49.166'),(83,1,'income','encaissement','2026-07-01 12:13:14.091',250000,'Facture MG-2026-0029',NULL,'2026-07-01 12:13:14.092'),(84,1,'expense','salaire','2026-07-01 00:00:00.000',300000,'Salaire Mr Fiacre mois de Juin','','2026-07-01 12:16:27.805'),(85,1,'income','encaissement','2026-06-17 00:00:00.000',340000,'Acompte Facture MG-2026-0017',NULL,'2026-07-01 13:40:34.377'),(86,1,'income','encaissement','2026-06-17 00:00:00.000',340000,'Acompte Facture MG-2026-0017',NULL,'2026-07-01 13:43:48.757'),(87,1,'income','encaissement','2026-06-17 00:00:00.000',340000,'Acompte Facture MG-2026-0017',NULL,'2026-07-01 13:43:59.821'),(88,1,'income','encaissement','2026-06-17 00:00:00.000',340000,'Acompte Facture MG-2026-0017',NULL,'2026-07-01 13:48:31.142'),(89,1,'income','encaissement','2026-07-01 14:47:45.494',1175000,'Facture MG-2026-0023',NULL,'2026-07-01 14:47:45.496'),(94,2,'income','encaissement','2026-07-02 00:00:00.000',85000,'MONTANT VERSE PAR LE CLIENT','','2026-07-02 15:47:38.734'),(95,2,'income','encaissement','2026-07-02 00:00:00.000',65000,'MONTANT VERSE PAR LE CLIENT','','2026-07-02 15:48:13.380'),(96,2,'expense','salaire','2026-07-02 00:00:00.000',60000,'SALAIRE PERSONNEL NDOGBONG','','2026-07-02 15:49:06.007'),(97,2,'expense','encaissement','2026-07-02 00:00:00.000',80000,'SALAIRE PERSONNEL KOTT BADEN BADEN','','2026-07-02 15:49:59.013'),(98,2,'expense','salaire','2026-06-26 00:00:00.000',75000,'SALAIRE PERSONNEL TRADEX DENVER','','2026-07-02 15:52:27.026'),(100,2,'expense','salaire','2026-06-26 00:00:00.000',55000,'SALAIRE PERSONNEL VALLEE COMMISSARIAT','','2026-07-02 15:54:49.573'),(101,2,'expense','salaire','2026-06-15 00:00:00.000',20000,'SALAIRE PERSONNEL LOGBESSOU','','2026-07-02 15:56:35.047'),(102,2,'expense','salaire','2026-06-15 00:00:00.000',50000,'SALAIRE PERSONNEL BONABERI','','2026-07-02 15:59:45.505'),(104,2,'expense','salaire','2026-06-01 00:00:00.000',60000,'salaire employe','','2026-07-02 16:05:00.724'),(105,2,'expense','salaire','2026-06-08 00:00:00.000',61000,'Salaire employe','','2026-07-02 16:05:57.935'),(106,2,'income','salaire','2026-06-01 00:00:00.000',80000,'salaire employe','','2026-07-02 16:06:27.018'),(107,2,'expense','salaire','2026-05-25 00:00:00.000',55000,'SALAIRE EMPLOYE','','2026-07-02 16:06:58.261'),(108,2,'expense','salaire','2026-05-13 00:00:00.000',50000,'SALAIRE EMPLOYE','','2026-07-02 16:07:24.411'),(109,2,'expense','salaire','2026-05-08 00:00:00.000',61000,'SALAIRE EMPLOYE','','2026-07-02 16:07:57.351'),(110,2,'expense','salaire','2026-04-27 00:00:00.000',60000,'SALAIRE EMPLOYE','','2026-07-02 16:08:26.706'),(111,2,'expense','salaire','2026-04-27 00:00:00.000',75000,'SALAIRE EMPLOYE','','2026-07-02 16:09:09.638'),(112,2,'expense','salaire','2026-04-27 00:00:00.000',60000,'SALAIRE EMPLOYE','','2026-07-02 16:09:42.452'),(113,2,'expense','salaire','2026-05-25 00:00:00.000',60000,'SALAIRE EMPLOYE','','2026-07-02 16:13:43.760'),(114,2,'expense','salaire','2026-05-25 00:00:00.000',75000,'SALAIRE EMPLOYE','','2026-07-02 16:14:12.021'),(115,2,'expense','salaire','2026-06-01 00:00:00.000',80000,'SALAIRE EMPLOYE','','2026-07-02 16:17:30.371'),(116,2,'expense','salaire','2026-06-01 00:00:00.000',75000,'SALAIRE EMPLOYE','','2026-07-02 16:18:02.458'),(117,2,'expense','charge','2026-07-02 00:00:00.000',11000,'transport ; recharge credit internet; frais de retrait; recharge prepayer lulan','','2026-07-02 16:28:19.786'),(118,1,'expense','salaire','2026-07-02 00:00:00.000',400000,'Salaire Chauffeur Mr Anja chauffeur de Mr Junior','','2026-07-06 13:34:27.501'),(119,1,'expense','salaire','2026-07-02 00:00:00.000',250000,'Salaire Mme Joeline Femme de ménage de Mme Alexandra ','','2026-07-06 13:37:57.843'),(120,1,'expense','salaire','2026-07-02 00:00:00.000',250000,'Salaire Mme Isabelle Nounou de Mme Alexandra ','','2026-07-06 13:39:38.898'),(121,1,'expense','charge','2026-07-04 00:00:00.000',12000,'Frais de transport de Mr Koloina chauffeur en Alternance 4j','','2026-07-06 13:45:06.195'),(122,1,'income','encaissement','2026-07-03 00:00:00.000',1377000,'Facture MG-2026-0017','00010244301','2026-07-06 15:09:19.793'),(123,2,'income','encaissement','2026-07-06 15:40:16.425',65000,'Facture CM-2026-0018',NULL,'2026-07-06 15:40:16.426'),(124,2,'expense','salaire','2026-07-06 00:00:00.000',60000,'SALAIRE MENSUEL','','2026-07-06 15:41:00.617'),(125,2,'expense','charge','2026-07-06 00:00:00.000',2900,'transport uba, transport lycée de makepe, recharge credit internet iphone et frais de retrait de 60k','','2026-07-06 15:44:21.296'),(126,1,'expense','charge','2026-07-06 00:00:00.000',6000,'Frais de déplacement 2j pour chauffeur Alternance Mr Koloina ','','2026-07-07 07:30:47.923'),(127,1,'income','encaissement','2026-07-10 06:26:45.853',250000,'Facture MG-2026-0024',NULL,'2026-07-10 06:26:45.854'),(128,2,'income','encaissement','2026-07-10 13:49:58.747',66000,'Facture CM-2026-0019',NULL,'2026-07-10 13:49:58.749'),(129,2,'expense','salaire','2026-07-10 00:00:00.000',61000,'SALAIRE DU PERSONNEL','','2026-07-10 13:54:39.195'),(130,2,'expense','charge','2026-07-07 00:00:00.000',2800,'TRANSPORT ','','2026-07-10 13:57:06.303'),(131,2,'expense','charge','2026-07-09 00:00:00.000',3600,'recharge eau plus achat papier hygiénique','','2026-07-10 13:58:05.924'),(132,2,'expense','charge','2026-07-09 00:00:00.000',4100,'recharge prepayer lulan','','2026-07-10 13:59:05.700'),(133,1,'income','encaissement','2026-07-15 06:24:01.629',200000,'Facture MG-2026-0030',NULL,'2026-07-15 06:24:01.631'),(134,1,'expense','salaire','2025-12-08 00:00:00.000',200000,'Salaire Mme Chantal mois de Novembre','','2026-07-15 06:26:44.181'),(135,1,'expense','salaire','2026-01-08 00:00:00.000',200000,'Salaire Mme Chantal mois de Décembre','','2026-07-15 06:28:22.939'),(136,1,'expense','salaire','2026-02-09 00:00:00.000',200000,'Salaire Mme Chantal Mois de Janvier','','2026-07-15 06:29:14.529'),(137,1,'expense','salaire','2026-03-09 00:00:00.000',200000,'Salaire Mme Chantal mois de Février','','2026-07-15 06:30:33.236'),(138,1,'expense','salaire','2026-04-08 00:00:00.000',200000,'Salaire Mme Chantal mois de Mars','','2026-07-15 06:33:09.225'),(139,1,'expense','salaire','2026-05-08 00:00:00.000',200000,'Salaire Mme Chantal mois d\'Avril','','2026-07-15 06:35:04.067'),(140,1,'expense','salaire','2026-06-08 00:00:00.000',200000,'Salaire Mme Chantal mois de Mai','','2026-07-15 06:35:45.600'),(141,1,'expense','salaire','2026-07-14 00:00:00.000',50000,'Salaire Mme Chantal mois de Juin','','2026-07-15 06:37:58.551'),(142,1,'expense','salaire','2026-07-09 00:00:00.000',147000,'Salaire Mme Sandra Mois de Juin','','2026-07-15 06:41:27.857'),(143,1,'expense','salaire','2026-01-26 00:00:00.000',450000,'Salaire Mr Hery mois de Janvier','','2026-07-15 13:16:14.506'),(144,1,'expense','salaire','2026-02-24 00:00:00.000',450000,'Salaire Mr Hery mois de Février','','2026-07-15 13:18:50.943'),(145,1,'expense','salaire','2026-03-24 00:00:00.000',450000,'Salaire Mr Hery mois de Mars','','2026-07-15 13:22:19.025'),(146,1,'expense','salaire','2026-04-24 00:00:00.000',450000,'Salaire Mr Hery mois d\'Avril ','','2026-07-15 13:24:07.953'),(147,1,'expense','salaire','2026-05-25 00:00:00.000',450000,'Salaire Mr Hery mois de Mai','','2026-07-15 13:25:30.937'),(148,1,'expense','salaire','2026-06-24 00:00:00.000',450000,'Salaire Mr Hery mois de Juin','','2026-07-15 13:28:20.878'),(149,1,'expense','salaire','2025-12-29 00:00:00.000',200000,'Salaire Mme Marthe mois de Décembre','','2026-07-15 14:01:56.378'),(150,1,'expense','salaire','2026-01-30 00:00:00.000',200000,'Salaire Mme Marthe mois de Janvier','','2026-07-15 14:02:51.893'),(151,1,'expense','salaire','2026-02-27 00:00:00.000',200000,'Salaire Mme Marthe mois de Février','','2026-07-15 14:03:40.018'),(152,1,'expense','salaire','2026-03-30 00:00:00.000',200000,'Salaire Mme Marthe mois de Mars','','2026-07-15 14:04:31.779'),(153,1,'expense','salaire','2026-04-30 00:00:00.000',200000,'Salaire Mme Marthe mois d\'Avril','','2026-07-15 14:05:32.673'),(154,1,'expense','salaire','2026-05-29 00:00:00.000',200000,'Salaire Mme Marthe mois de Mai','','2026-07-15 14:07:05.837'),(155,1,'income','encaissement','2026-07-15 14:27:23.280',300000,'Facture MG-2026-0033',NULL,'2026-07-15 14:27:23.281'),(156,1,'income','encaissement','2026-07-15 14:27:53.341',150000,'Facture MG-2026-0034',NULL,'2026-07-15 14:27:53.343'),(157,1,'income','encaissement','2026-07-15 14:28:03.727',300000,'Facture MG-2026-0032',NULL,'2026-07-15 14:28:03.728'),(158,1,'expense','salaire','2026-03-30 00:00:00.000',250000,'Salaire Mr Samuel mois de Mars','','2026-07-15 14:29:34.685'),(159,1,'expense','salaire','2026-04-30 00:00:00.000',250000,'Salaire Mr Samuel mois d\'Avril','','2026-07-15 14:30:31.490'),(160,1,'expense','salaire','2026-05-29 00:00:00.000',100000,'Salaire Mr Samuel mois de Mai','','2026-07-15 14:57:05.365'),(161,2,'income','encaissement','2026-07-18 10:50:26.787',55000,'Facture CM-2026-0020',NULL,'2026-07-18 10:50:26.788'),(162,2,'income','encaissement','2026-07-18 10:50:38.407',25000,'Facture CM-2026-0021',NULL,'2026-07-18 10:50:38.408'),(163,2,'expense','salaire','2026-07-17 00:00:00.000',20000,'SALAIRE DU PERSOONNEL','','2026-07-18 10:51:26.484'),(164,2,'expense','salaire','2026-07-17 00:00:00.000',50000,'SALAIRE DU PERSONNEL','','2026-07-18 10:52:06.823'),(165,2,'expense','charge','2026-07-17 00:00:00.000',5100,'RECHARGE PREPAYER CBC','','2026-07-18 10:55:10.455'),(166,2,'expense','charge','2026-07-13 00:00:00.000',4100,'RECHARGE PREPAYER','','2026-07-18 10:56:46.824'),(167,2,'expense','charge','2026-07-17 00:00:00.000',800,'FRAIS DE TAXI','','2026-07-18 10:57:33.731'),(168,1,'income','encaissement','2026-07-23 14:32:59.011',300000,'Facture MG-2026-0036',NULL,'2026-07-23 14:32:59.012'),(169,1,'income','encaissement','2026-07-26 07:58:43.198',250000,'Facture MG-2026-0035',NULL,'2026-07-26 07:58:43.199'),(170,2,'income','encaissement','2026-07-27 09:29:45.497',60000,'Facture CM-2026-0022',NULL,'2026-07-27 09:29:45.498'),(171,2,'expense','salaire','2026-07-27 00:00:00.000',55000,'salaire mensuel du personnel','','2026-07-27 09:37:55.248'),(172,2,'expense','charge','2026-07-27 00:00:00.000',750,'frais de retrait de 55000 FCFA','','2026-07-27 09:39:14.418'),(173,2,'expense','charge','2026-07-27 00:00:00.000',750,'frais de retrait de 55000 FCFA','','2026-07-27 09:39:19.352'),(174,2,'income','encaissement','2026-07-31 07:32:41.313',80000,'Facture CM-2026-0023',NULL,'2026-07-31 07:32:41.314'),(175,2,'income','encaissement','2026-07-31 07:32:52.472',65000,'Facture CM-2026-0025',NULL,'2026-07-31 07:32:52.473'),(177,2,'expense','salaire','2026-07-31 00:00:00.000',75000,'salaire mensuel du personnel','','2026-07-31 07:38:49.263'),(178,2,'expense','salaire','2026-07-31 00:00:00.000',60000,'salaire mensuel du personnel','','2026-07-31 07:40:32.830'),(181,2,'expense','charge','2026-07-31 00:00:00.000',1000,'frais de retrait','','2026-07-31 07:47:28.356'),(182,2,'expense','charge','2026-07-31 00:00:00.000',3100,'impression DSF 2024 et 2025','','2026-07-31 07:48:09.562'),(183,2,'income','encaissement','2026-08-01 10:52:52.955',85000,'Facture CM-2026-0024',NULL,'2026-08-01 10:52:52.956'),(184,2,'expense','salaire','2026-08-01 00:00:00.000',80000,'salaire mensuel du personnel','','2026-08-01 10:54:28.079'),(185,2,'expense','charge','2026-08-01 00:00:00.000',15000,'avance paiement du personnel en alternance à Kotto Baden Baden pour ses une semaine de congéss','','2026-08-01 10:57:42.895'),(186,2,'income','encaissement','2026-08-10 15:08:00.938',65000,'Facture CM-2026-0029',NULL,'2026-08-10 15:08:00.939'),(187,2,'expense','salaire','2026-08-10 00:00:00.000',60000,'salaire mensuel du personnel','','2026-08-10 15:10:36.807'),(188,2,'expense','charge','2026-08-10 00:00:00.000',3000,'reste de la paie du personnel en alternance à kotto pour le congés du personnel permanent','','2026-08-10 15:11:39.481'),(189,2,'income','salaire','2026-08-11 00:00:00.000',66000,'salaire mensuel du personnel plus frais d\'agence','','2026-08-11 15:33:23.174'),(190,2,'expense','salaire','2026-08-11 00:00:00.000',61000,'salaire mensuel du personnel','','2026-08-11 15:33:56.719'),(191,2,'expense','charge','2026-08-11 00:00:00.000',750,'frais de retrait de 60K','','2026-08-11 15:34:58.659'),(192,2,'expense','charge','2026-08-10 00:00:00.000',750,'frais de retrait de 60K','','2026-08-11 15:35:50.382'),(193,2,'expense','charge','2026-08-11 00:00:00.000',1000,'transport Acces Bank et Lycée de Makepe','','2026-08-11 15:36:46.696'),(195,1,'income','encaissement','2026-08-12 08:54:22.838',1522500,'Facture MG-2026-0038',NULL,'2026-08-12 08:54:22.839'),(196,1,'income','encaissement','2026-08-13 06:50:16.793',295000,'Facture MG-2026-0037',NULL,'2026-08-13 06:50:16.794'),(198,2,'income','encaissement','2026-08-15 14:08:11.847',25000,'Facture CM-2026-0030',NULL,'2026-08-15 14:08:11.848'),(199,2,'expense','salaire','2026-08-15 00:00:00.000',20000,'Salaire mensuel du personnel','','2026-08-15 14:09:10.004'),(200,2,'expense','charge','2026-08-15 00:00:00.000',5100,'recharge prepayer cbc','','2026-08-15 14:10:30.187'),(201,2,'expense','charge','2026-08-15 00:00:00.000',400,'transport carrefour lycee de makepe','','2026-08-15 14:11:23.432'),(202,2,'expense','charge','2026-08-15 00:00:00.000',1000,'achat d\'un balaie','','2026-08-15 14:11:54.839'),(203,1,'income','encaissement','2026-08-18 13:16:16.861',300000,'Facture MG-2026-0031',NULL,'2026-08-18 13:16:16.862'),(204,1,'income','encaissement','2026-08-18 13:18:46.165',990000,'Facture MG-2026-0039',NULL,'2026-08-18 13:18:46.166'),(205,1,'income','encaissement','2026-08-18 13:22:35.928',250000,'Facture MG-2026-0040',NULL,'2026-08-18 13:22:35.929');
/*!40000 ALTER TABLE `CashEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'individual',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `nif` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commissionRate` double NOT NULL DEFAULT '12',
  `paymentTermsDays` int NOT NULL DEFAULT '5',
  `overtimeRate` double NOT NULL DEFAULT '0',
  `billingFreq` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `agencyFee` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Client_countryId_fkey` (`countryId`),
  KEY `Client_officeId_fkey` (`officeId`),
  CONSTRAINT `Client_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Client_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` VALUES (1,2,NULL,'individual','MBALIDAM ESTHER','','','679526191','','BONAMOUSSADI','','',0,5,1000,'monthly',1,'','2026-06-15 13:07:57.339','2026-06-15 13:07:57.339'),(2,2,NULL,'individual','NGOLWA JEAN PIERRE','','','672740080','','MAKEPE COURS SUPREME','','',0,5,1000,'monthly',1,'','2026-06-15 13:10:58.109','2026-06-15 13:10:58.109'),(3,2,NULL,'individual','YOUWO PAULE GENIE','','','698716820','','BONABERI','','',0,5,1000,'monthly',1,'','2026-06-15 13:12:59.456','2026-06-15 13:12:59.456'),(4,2,NULL,'individual','NGONGANG WILFRIED','','','655629267','','BONAMOUSSADI','','',0,5,1000,'monthly',1,'','2026-06-15 13:13:57.328','2026-06-15 13:13:57.328'),(5,2,NULL,'individual','KOUAYEP PATERNE','','','655711431','','','','',0,5,1000,'monthly',1,'','2026-06-15 13:14:57.810','2026-06-15 13:14:57.810'),(6,2,NULL,'individual','FOUDA MADELEINE','','','653032588','','','','',0,5,1000,'monthly',1,'','2026-06-15 13:16:46.091','2026-06-15 13:16:46.091'),(7,2,NULL,'company','LONDO TECHNOLOGY','','','233 43 89 60','','','M031812705109H','',0,5,1000,'monthly',1,'','2026-06-15 13:21:52.889','2026-06-15 13:21:52.889'),(8,2,NULL,'individual','FOSSO DEFFO RUDY DERLIN','','','693 59 25 99','','KOTTO BADEN BADEN','','',0,5,1000,'monthly',1,'','2026-06-15 13:24:37.422','2026-08-10 15:13:52.111'),(9,1,1,'individual','Alliance Nouboussi','','','0381032053','alliance@gmail.com','Ambohinjanahary Antehiroka','','',15,5,5000,'monthly',1,'','2026-06-24 13:03:08.587','2026-06-24 13:05:12.263'),(10,1,1,'individual','ANDRIAMANOA Revokiniaina','','','0321347762','revekoniaina@gmail.com','','','',15,5,5000,'monthly',1,'','2026-06-24 14:26:04.582','2026-06-24 14:26:04.582'),(11,1,1,'individual','Paole PARIANOS','','','0341463836','paole@gmail.com','Ivato','','',15,5,5000,'monthly',1,'','2026-06-25 12:17:55.367','2026-06-25 12:17:55.367'),(12,1,1,'company','MBAC','SARLU','TENE CHENDJOU Junior','0349852558','junior.chendjou@mbac.mg','village des jeux Ankorondrano','5018465821','70209112024001900',15,10,5000,'monthly',1,'','2026-06-25 13:08:25.210','2026-06-25 13:36:20.822'),(13,1,1,'individual','MEBE Alexanxdra Bibiane ','','','0387529259','alexandra.kouomou@thara-services.mg','Ilaivola Ambohinjanahary Ivato','','',15,5,5000,'monthly',1,'','2026-06-30 09:34:28.547','2026-06-30 09:34:28.547'),(14,1,1,'company','THARA Services','SARL','KOUOMOU MOUAFO Fabrice Ludonic','0327233643','contact@thara-services.mg','26A Antanetibe Ivato ','2018100907','62011112023010935',15,5,5000,'monthly',1,'','2026-07-01 10:53:36.200','2026-07-01 10:53:36.200'),(15,1,1,'individual','MBITSI Olivia','','','0377162400','olivia@gmail.com','Lot IIN 69 Analamahitsy','','',15,5,5000,'monthly',1,'','2026-07-07 07:12:55.596','2026-07-07 07:12:55.596');
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Complaint`
--

DROP TABLE IF EXISTS `Complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Complaint` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `receivedVia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phone',
  `receivedById` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'moderate',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `decision` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decisionDetail` text COLLATE utf8mb4_unicode_ci,
  `resolvedAt` datetime(3) DEFAULT NULL,
  `resolvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Complaint_countryId_fkey` (`countryId`),
  KEY `Complaint_clientId_fkey` (`clientId`),
  KEY `Complaint_receivedById_fkey` (`receivedById`),
  CONSTRAINT `Complaint_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_receivedById_fkey` FOREIGN KEY (`receivedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Complaint`
--

LOCK TABLES `Complaint` WRITE;
/*!40000 ALTER TABLE `Complaint` DISABLE KEYS */;
/*!40000 ALTER TABLE `Complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComplaintCandidate`
--

DROP TABLE IF EXISTS `ComplaintCandidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ComplaintCandidate` (
  `complaintId` int NOT NULL,
  `candidateId` int NOT NULL,
  PRIMARY KEY (`complaintId`,`candidateId`),
  KEY `ComplaintCandidate_candidateId_fkey` (`candidateId`),
  CONSTRAINT `ComplaintCandidate_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ComplaintCandidate_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `Complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComplaintCandidate`
--

LOCK TABLES `ComplaintCandidate` WRITE;
/*!40000 ALTER TABLE `ComplaintCandidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ComplaintCandidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contribution`
--

DROP TABLE IF EXISTS `Contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Contribution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` double NOT NULL,
  `base` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gross',
  `part` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Contribution_countryId_fkey` (`countryId`),
  CONSTRAINT `Contribution_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contribution`
--

LOCK TABLES `Contribution` WRITE;
/*!40000 ALTER TABLE `Contribution` DISABLE KEYS */;
/*!40000 ALTER TABLE `Contribution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currencyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchangeToEur` double NOT NULL DEFAULT '1',
  `phonePrefix` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoicePrefix` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `entityName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legalMention` text COLLATE utf8mb4_unicode_ci,
  `vatRate` double NOT NULL DEFAULT '20',
  `syntheticTaxEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `syntheticTaxRate` double NOT NULL DEFAULT '0',
  `prorataBase` int NOT NULL DEFAULT '30',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `mobileMoneyProviders` text COLLATE utf8mb4_unicode_ci,
  `agencyCode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankCode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bic` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileMoneyAccount` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ribKey` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Country_code_key` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'Madagascar','MG','MGA','Ariary','Ar',0.0002,'+261','MG',1,'USRA CARE SARLU','NIF : 5018370696','STAT : 81211 11 2023 0 11485','LOT IIP 154 JC Météo Avaradoha','Antananarivo 101','+261 38 262 02 50','contact@usra-care.com','AFG Bank Madagascar','00013559801','SARL unipersonnelle au capital de 1 000 000 Ar',20,1,5,30,'2026-06-05 09:52:57.884','2026-06-05 09:52:57.884','Mvola, Orange Money','AFGB MADA ANDRANOMENA','00017','AFGMMGMG','MG4600017010050001355980168',NULL,'68'),(2,'Cameroun','CM','XAF','Franc CFA','FCFA',0.00152,'+237','CM',1,'USRA CARE Cameroun SARL','NIU : M022014404117U','RCCM : RC/YAE/2020/B/860','Makepe Bloc L','Douala','','','','10005 00012 12345678901 23','SARL au capital de 1 000 000 FCFA',19.25,0,0,30,'2026-06-05 09:52:57.910','2026-07-10 10:38:26.981','Orange Money, MTN Mobile Money','','','','','699073975',''),(3,'Côte d\'Ivoire','CI','XOF','Franc CFA Ouest','FCFA',0.00152,'+225','CI',1,'USRA CARE Côte d\'Ivoire SARL',NULL,NULL,NULL,'Abidjan',NULL,NULL,NULL,NULL,NULL,18,0,0,30,'2026-06-05 09:52:57.924','2026-06-05 09:52:57.924','Wave, Orange Money',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EquipmentRecord`
--

DROP TABLE IF EXISTS `EquipmentRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EquipmentRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `countryId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `items` json NOT NULL,
  `totalValue` double NOT NULL DEFAULT '0',
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `returnedAt` datetime(3) DEFAULT NULL,
  `returnedItems` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `EquipmentRecord_candidateId_fkey` (`candidateId`),
  KEY `EquipmentRecord_countryId_fkey` (`countryId`),
  KEY `EquipmentRecord_missionId_fkey` (`missionId`),
  CONSTRAINT `EquipmentRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EquipmentRecord`
--

LOCK TABLES `EquipmentRecord` WRITE;
/*!40000 ALTER TABLE `EquipmentRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `EquipmentRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Evaluation`
--

DROP TABLE IF EXISTS `Evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Evaluation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `clientId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `overallRating` double NOT NULL,
  `punctuality` int NOT NULL DEFAULT '0',
  `quality` int NOT NULL DEFAULT '0',
  `behavior` int NOT NULL DEFAULT '0',
  `appearance` int NOT NULL DEFAULT '0',
  `instructions` int NOT NULL DEFAULT '0',
  `discretion` int NOT NULL DEFAULT '0',
  `honesty` int NOT NULL DEFAULT '0',
  `initiative` int NOT NULL DEFAULT '0',
  `hygiene` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `recommend` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Evaluation_candidateId_fkey` (`candidateId`),
  KEY `Evaluation_clientId_fkey` (`clientId`),
  CONSTRAINT `Evaluation_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Evaluation_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Evaluation`
--

LOCK TABLES `Evaluation` WRITE;
/*!40000 ALTER TABLE `Evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Interview`
--

DROP TABLE IF EXISTS `Interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Interview` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answers` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Interview_candidateId_key` (`candidateId`),
  CONSTRAINT `Interview_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Interview`
--

LOCK TABLES `Interview` WRITE;
/*!40000 ALTER TABLE `Interview` DISABLE KEYS */;
INSERT INTO `Interview` VALUES (1,2,'menage','{\"0_0\": 5, \"0_1\": \"MAISON\", \"1_0\": true, \"1_1\": true, \"1_2\": true, \"2_0\": 4, \"2_1\": 4, \"2_2\": 3, \"2_3\": 75000}','2026-06-15 14:15:31.141','2026-06-15 16:33:01.583'),(2,32,'chauffeur','{\"0_0\": 12, \"0_2\": \"B\", \"1_3\": \"Français\", \"2_0\": 16, \"2_3\": 600000}','2026-07-16 13:11:11.149','2026-07-16 13:11:11.149'),(3,31,'menage','{\"0_0\": 1, \"0_1\": \"Bureau\", \"0_3\": \"BADASS Andranobevava\", \"2_2\": 2, \"2_3\": 200000}','2026-07-16 13:17:02.759','2026-07-16 13:17:02.759'),(4,30,'chauffeur','{\"0_0\": 5, \"0_3\": \"China Iiangrei International\", \"1_0\": 3, \"1_3\": \"Français, Anglais\", \"2_0\": 16, \"2_1\": 10, \"2_2\": 1, \"2_3\": 500000}','2026-07-16 13:23:15.516','2026-07-16 13:23:15.516'),(5,33,'chauffeur','{\"0_0\": 10, \"0_2\": \"B\", \"1_0\": 5, \"1_3\": \"Français\", \"2_0\": 18, \"2_1\": 20, \"2_2\": 4, \"2_3\": 400000}','2026-07-22 08:33:11.644','2026-08-17 05:39:47.930');
/*!40000 ALTER TABLE `Interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InterviewTemplate`
--

DROP TABLE IF EXISTS `InterviewTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InterviewTemplate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sections` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InterviewTemplate_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InterviewTemplate`
--

LOCK TABLES `InterviewTemplate` WRITE;
/*!40000 ALTER TABLE `InterviewTemplate` DISABLE KEYS */;
INSERT INTO `InterviewTemplate` VALUES (1,'menage','Ménage / Entretien','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de logements\"}, {\"type\": \"multiselect\", \"label\": \"Produits maîtrisés\"}, {\"type\": \"textarea\", \"label\": \"Références clients\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Repassage\"}, {\"type\": \"boolean\", \"label\": \"Cuisine simple\"}, {\"type\": \"boolean\", \"label\": \"Garde enfants\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Test dépoussiérage\"}, {\"type\": \"rating5\", \"label\": \"Test vitres\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(2,'cuisine','Cuisine / Chef','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types d\'établissements\"}, {\"type\": \"multiselect\", \"label\": \"Spécialités culinaires\"}, {\"type\": \"textarea\", \"label\": \"Plats phares\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Sait planifier des menus\"}, {\"type\": \"boolean\", \"label\": \"Gestion budget courses\"}, {\"type\": \"boolean\", \"label\": \"Formation hygiène (HACCP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test cuisine\"}, {\"type\": \"text\", \"label\": \"Plat préparé\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(3,'securite','Agent de sécurité','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Secteurs gardés\"}, {\"type\": \"textarea\", \"label\": \"Diplômes / certifications\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Permis de conduire\"}, {\"type\": \"boolean\", \"label\": \"Maîtrise outil radio\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours (SSIAP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Aptitude physique\"}, {\"type\": \"rating5\", \"label\": \"Gestion stress\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:09:52.906'),(4,'chauffeur','Chauffeur','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de véhicules\"}, {\"type\": \"multiselect\", \"label\": \"Catégorie de permis\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Connaissance de la ville\"}, {\"type\": \"boolean\", \"label\": \"Mécanique de base\"}, {\"type\": \"boolean\", \"label\": \"Conduite défensive\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test de conduite\"}, {\"type\": \"rating20\", \"label\": \"Code de la route\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(5,'garde_enfants','Garde d\'enfants','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Tranches d\'âge\"}, {\"type\": \"multiselect\", \"label\": \"Activités proposées\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Formation petite enfance\"}, {\"type\": \"boolean\", \"label\": \"Aide aux devoirs\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours nourrissons\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Interaction enfant\"}, {\"type\": \"rating5\", \"label\": \"Patience / empathie\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(6,'general','Questionnaire général','[{\"title\": \"Profil\", \"questions\": [{\"type\": \"text\", \"label\": \"Niveau d\'études\"}, {\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Compétences clés\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Aptitudes\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Ponctualité\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156');
/*!40000 ALTER TABLE `InterviewTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `subtotalHT` double NOT NULL DEFAULT '0',
  `vatRate` double NOT NULL DEFAULT '20',
  `vatAmount` double NOT NULL DEFAULT '0',
  `syntheticTax` double NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `period` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `acompteAmount` double DEFAULT NULL,
  `acompteDate` datetime(3) DEFAULT NULL,
  `acompteMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Invoice_reference_key` (`reference`),
  KEY `Invoice_countryId_fkey` (`countryId`),
  KEY `Invoice_clientId_fkey` (`clientId`),
  CONSTRAINT `Invoice_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Invoice_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
INSERT INTO `Invoice` VALUES (1,2,2,'CM-2026-0001','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-04','2026-06-15 15:02:17.490','2026-06-27 10:50:43.490',NULL,NULL,NULL),(2,2,1,'CM-2026-0002','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-04','2026-06-15 15:05:14.997','2026-06-15 15:44:41.308',NULL,NULL,NULL),(3,2,7,'CM-2026-0003','placement','2026-05-08 00:00:00.000','2026-05-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-04','2026-06-15 15:06:56.619','2026-06-15 15:45:43.545',NULL,NULL,NULL),(4,2,3,'CM-2026-0004','placement','2026-05-13 00:00:00.000','2026-05-18 00:00:00.000','paid',55000,0,0,0,55000,NULL,NULL,0,'2026-04','2026-06-15 15:08:12.033','2026-06-15 15:45:55.861',NULL,NULL,NULL),(5,2,1,'CM-2026-0005','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-05','2026-06-15 15:09:58.761','2026-06-15 15:46:54.134',NULL,NULL,NULL),(6,2,2,'CM-2026-0006','placement','2026-04-27 00:00:00.000','2026-05-02 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-04','2026-06-15 15:17:16.939','2026-06-15 15:44:56.600',NULL,NULL,NULL),(7,2,4,'CM-2026-0007','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',60000,0,0,0,60000,NULL,NULL,0,'2026-05','2026-06-15 15:21:15.057','2026-06-15 15:46:15.931',NULL,NULL,NULL),(8,2,6,'CM-2026-0008','placement','2026-05-25 00:00:00.000','2026-05-30 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-05','2026-06-15 15:22:48.599','2026-06-15 15:46:04.579',NULL,NULL,NULL),(9,2,8,'CM-2026-0009','placement','2026-06-01 00:00:00.000','2026-06-06 00:00:00.000','paid',85000,0,0,0,85000,NULL,NULL,0,'2026-05','2026-06-15 15:25:13.141','2026-06-15 15:46:33.872',NULL,NULL,NULL),(10,2,2,'CM-2026-0010','placement','2026-06-01 00:00:00.000','2026-06-06 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-05','2026-06-15 15:27:14.668','2026-06-15 15:39:49.123',NULL,NULL,NULL),(11,2,7,'CM-2026-0011','placement','2026-06-08 00:00:00.000','2026-06-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-05','2026-06-15 15:29:36.434','2026-06-19 13:01:48.287',NULL,NULL,NULL),(12,2,5,'CM-2026-0012','placement','2026-06-15 00:00:00.000','2026-06-21 00:00:00.000','paid',25000,0,0,0,25000,NULL,NULL,0,'2026-06','2026-06-15 15:32:19.509','2026-06-19 13:01:24.168',NULL,NULL,NULL),(13,2,3,'CM-2026-0013','placement','2026-06-15 00:00:00.000','2026-06-20 00:00:00.000','paid',55000,0,0,0,55000,NULL,NULL,0,'2026-06','2026-06-15 15:34:04.581','2026-06-19 13:01:36.924',NULL,NULL,NULL),(14,2,6,'CM-2026-0014','placement','2026-06-22 00:00:00.000','2026-06-27 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-06','2026-06-22 09:44:50.468','2026-07-02 15:36:34.495',NULL,NULL,NULL),(15,1,9,'MG-2026-0001','placement','2026-06-24 00:00:00.000','2026-06-29 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-06','2026-06-24 14:04:22.694','2026-06-29 07:10:51.939',NULL,NULL,NULL),(16,1,9,'MG-2026-0002','placement','2026-01-22 00:00:00.000','2026-01-27 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-01','2026-06-24 14:08:32.916','2026-06-24 14:08:41.529',NULL,NULL,NULL),(17,1,9,'MG-2026-0003','placement','2026-02-19 00:00:00.000','2026-02-24 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-02','2026-06-24 14:10:23.946','2026-06-24 14:10:48.459',NULL,NULL,NULL),(18,1,9,'MG-2026-0004','placement','2026-03-30 00:00:00.000','2026-04-04 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-03','2026-06-24 14:14:32.423','2026-06-24 14:14:48.255',NULL,NULL,NULL),(19,1,9,'MG-2026-0005','placement','2026-04-28 00:00:00.000','2026-05-03 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-04','2026-06-24 14:17:18.067','2026-06-24 14:17:46.829',NULL,NULL,NULL),(20,1,9,'MG-2026-0006','placement','2026-05-28 00:00:00.000','2026-06-02 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-05','2026-06-24 14:19:11.326','2026-06-24 14:19:48.178',NULL,NULL,NULL),(21,1,10,'MG-2026-0007','placement','2026-06-24 00:00:00.000','2026-06-29 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-06','2026-06-24 14:47:26.738','2026-06-25 13:40:13.676',NULL,NULL,NULL),(22,1,10,'MG-2026-0008','placement','2026-05-28 00:00:00.000','2026-06-02 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-05','2026-06-24 14:50:41.975','2026-06-24 14:55:01.474',NULL,NULL,NULL),(23,1,10,'MG-2026-0009','placement','2026-04-29 00:00:00.000','2026-05-04 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-04','2026-06-24 14:59:54.741','2026-06-24 15:02:45.199',NULL,NULL,NULL),(24,1,10,'MG-2026-0010','placement','2026-03-30 00:00:00.000','2026-04-04 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-03','2026-06-24 15:07:20.500','2026-06-24 15:07:39.896',NULL,NULL,NULL),(25,1,10,'MG-2026-0011','placement','2026-02-26 00:00:00.000','2026-03-03 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-02','2026-06-25 11:50:56.532','2026-06-25 11:58:50.737',NULL,NULL,NULL),(26,1,10,'MG-2026-0012','placement','2026-01-29 00:00:00.000','2026-02-03 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-01','2026-06-25 12:00:45.531','2026-06-25 12:03:53.231',NULL,NULL,NULL),(27,1,10,'MG-2025-0001','placement','2025-12-29 00:00:00.000','2026-01-03 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2025-12','2026-06-25 12:03:25.302','2026-06-25 12:04:25.197',NULL,NULL,NULL),(28,1,11,'MG-2026-0013','placement','2026-06-09 00:00:00.000','2026-06-14 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-06','2026-06-25 12:34:32.232','2026-06-25 12:34:56.141',NULL,NULL,NULL),(29,1,11,'MG-2026-0014','placement','2026-05-26 00:00:00.000','2026-05-31 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-05','2026-06-25 12:36:13.923','2026-06-25 12:40:28.305',NULL,NULL,NULL),(30,1,11,'MG-2026-0015','placement','2026-04-30 00:00:00.000','2026-05-05 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-04','2026-06-25 12:41:28.085','2026-06-25 12:41:52.491',NULL,NULL,NULL),(31,1,11,'MG-2026-0016','placement','2026-04-01 00:00:00.000','2026-04-06 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-03','2026-06-25 12:45:12.885','2026-06-25 12:45:25.342',NULL,NULL,NULL),(32,1,12,'MG-2026-0017','placement','2026-06-25 00:00:00.000','2026-07-05 00:00:00.000','paid',1717000,0,0,0,1717000,NULL,NULL,0,'2026-06','2026-06-25 13:40:04.078','2026-07-06 15:09:19.808',340000,'2026-06-17 00:00:00.000','cash'),(33,2,1,'CM-2026-0015','placement','2026-06-26 00:00:00.000','2026-07-30 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-06','2026-06-26 08:43:27.986','2026-06-27 10:40:05.161',NULL,NULL,NULL),(34,2,4,'CM-2026-0016','placement','2026-06-26 00:00:00.000','2026-07-30 00:00:00.000','paid',60000,0,0,0,60000,NULL,NULL,0,'2026-06','2026-06-26 08:49:01.951','2026-06-26 08:49:11.780',NULL,NULL,NULL),(35,2,8,'CM-2026-0017','placement','2026-06-26 00:00:00.000','2026-07-04 00:00:00.000','paid',85000,0,0,0,85000,NULL,NULL,0,'2026-06','2026-06-26 08:53:20.517','2026-07-02 15:36:53.301',NULL,NULL,NULL),(36,2,2,'CM-2026-0018','placement','2026-06-26 00:00:00.000','2026-07-02 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-06','2026-06-26 08:55:25.820','2026-07-06 15:40:16.439',NULL,NULL,NULL),(37,1,12,'MG-2026-0018','placement','2026-01-26 00:00:00.000','2026-02-05 00:00:00.000','paid',1500000,0,0,0,1500000,NULL,NULL,0,'2026-01','2026-06-29 12:51:33.988','2026-06-29 12:52:38.927',NULL,NULL,NULL),(38,1,12,'MG-2026-0019','placement','2026-02-26 00:00:00.000','2026-03-08 00:00:00.000','paid',1500000,0,0,0,1500000,NULL,NULL,0,'2026-02','2026-06-29 12:55:37.959','2026-06-29 12:55:55.054',NULL,NULL,NULL),(39,1,12,'MG-2026-0020','placement','2026-03-31 00:00:00.000','2026-04-10 00:00:00.000','paid',1472000,0,0,0,1472000,NULL,NULL,0,'2026-03','2026-06-29 13:08:12.132','2026-06-29 13:08:54.017',NULL,NULL,NULL),(40,1,12,'MG-2026-0021','placement','2026-04-27 00:00:00.000','2026-05-07 00:00:00.000','paid',1600000,0,0,0,1600000,NULL,NULL,0,'2026-04','2026-06-29 13:13:10.704','2026-06-29 13:13:43.916',NULL,NULL,NULL),(41,1,12,'MG-2026-0022','placement','2026-06-01 00:00:00.000','2026-06-11 00:00:00.000','paid',1744000,0,0,0,1744000,NULL,NULL,0,'2026-05','2026-06-29 13:25:23.302','2026-06-29 13:25:46.534',NULL,NULL,NULL),(42,1,13,'MG-2026-0023','placement','2026-06-30 00:00:00.000','2026-07-05 00:00:00.000','paid',1175000,0,0,0,1175000,NULL,NULL,0,'2026-06','2026-06-30 11:19:52.881','2026-07-01 14:47:45.506',NULL,NULL,NULL),(43,1,14,'MG-2026-0024','placement','2026-07-01 00:00:00.000','2026-07-06 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-06','2026-07-01 11:02:20.788','2026-07-10 06:26:45.865',NULL,NULL,NULL),(44,1,14,'MG-2026-0025','placement','2026-06-01 00:00:00.000','2026-06-06 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-05','2026-07-01 11:13:19.179','2026-07-01 11:13:36.560',NULL,NULL,NULL),(45,1,14,'MG-2026-0026','placement','2026-04-30 00:00:00.000','2026-05-05 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-04','2026-07-01 11:14:48.659','2026-07-01 11:16:21.607',NULL,NULL,NULL),(46,1,14,'MG-2026-0027','placement','2026-04-01 00:00:00.000','2026-04-06 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-03','2026-07-01 11:44:49.007','2026-07-01 11:58:10.947',NULL,NULL,NULL),(47,1,14,'MG-2026-0028','placement','2026-03-02 00:00:00.000','2026-03-07 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-02','2026-07-01 11:56:57.240','2026-07-01 12:02:33.300',NULL,NULL,NULL),(48,1,14,'MG-2026-0029','placement','2026-01-29 00:00:00.000','2026-02-03 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-01','2026-07-01 12:04:24.994','2026-07-01 12:13:14.101',NULL,NULL,NULL),(49,1,14,'MG-2025-0002','placement','2025-12-29 00:00:00.000','2026-01-03 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2025-12','2026-07-01 12:06:46.055','2026-07-01 12:12:32.807',NULL,NULL,NULL),(50,1,14,'MG-2025-0003','placement','2025-12-01 00:00:00.000','2025-12-06 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2025-11','2026-07-01 12:07:47.016','2026-07-01 12:12:49.179',NULL,NULL,NULL),(51,1,15,'MG-2026-0030','placement','2026-07-07 00:00:00.000','2026-07-12 00:00:00.000','paid',200000,0,0,0,200000,NULL,NULL,0,'2026-06','2026-07-07 07:14:59.101','2026-07-15 06:24:01.640',NULL,NULL,NULL),(52,2,7,'CM-2026-0019','placement','2026-07-10 00:00:00.000','2026-07-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-06','2026-07-10 13:49:34.765','2026-07-10 13:49:58.764',NULL,NULL,NULL),(53,2,3,'CM-2026-0020','placement','2026-07-15 00:00:00.000','2026-07-18 00:00:00.000','paid',55000,0,0,0,55000,NULL,NULL,0,'2026-06','2026-07-15 10:13:18.626','2026-07-18 10:50:26.797',NULL,NULL,NULL),(54,2,5,'CM-2026-0021','placement','2026-07-15 00:00:00.000','2026-07-20 00:00:00.000','paid',25000,0,0,0,25000,NULL,NULL,0,'2026-07','2026-07-15 10:15:29.865','2026-07-18 10:50:38.417',NULL,NULL,NULL),(55,1,11,'MG-2026-0031','placement','2026-07-15 00:00:00.000','2026-07-20 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-07','2026-07-15 13:32:31.017','2026-08-18 13:16:16.874',NULL,NULL,NULL),(56,1,15,'MG-2026-0032','placement','2026-03-30 00:00:00.000','2026-04-04 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-03','2026-07-15 14:23:40.613','2026-07-15 14:28:03.739',NULL,NULL,NULL),(57,1,15,'MG-2026-0033','placement','2026-04-28 00:00:00.000','2026-05-03 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-04','2026-07-15 14:25:06.987','2026-07-15 14:27:23.292',NULL,NULL,NULL),(58,1,15,'MG-2026-0034','placement','2026-05-28 00:00:00.000','2026-06-02 00:00:00.000','paid',150000,0,0,0,150000,NULL,NULL,0,'2026-05','2026-07-15 14:26:54.759','2026-07-15 14:27:53.357',NULL,NULL,NULL),(59,1,10,'MG-2026-0035','placement','2026-07-21 00:00:00.000','2026-07-26 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-07','2026-07-21 06:12:11.246','2026-07-26 07:58:43.214',NULL,NULL,NULL),(60,1,9,'MG-2026-0036','placement','2026-07-21 00:00:00.000','2026-07-26 00:00:00.000','paid',300000,0,0,0,300000,NULL,NULL,0,'2026-07','2026-07-21 06:58:58.354','2026-07-23 14:32:59.024',NULL,NULL,NULL),(61,1,15,'MG-2026-0037','placement','2026-07-23 00:00:00.000','2026-07-28 00:00:00.000','paid',295000,0,0,0,295000,NULL,NULL,0,'2026-07','2026-07-23 14:21:30.894','2026-08-13 06:50:16.805',NULL,NULL,NULL),(62,1,12,'MG-2026-0038','placement','2026-07-23 00:00:00.000','2026-08-02 00:00:00.000','paid',1522500,0,0,0,1522500,NULL,NULL,0,'2026-07','2026-07-23 15:29:35.726','2026-08-12 08:54:22.849',NULL,NULL,NULL),(63,2,4,'CM-2026-0022','placement','2026-07-25 00:00:00.000','2026-07-30 00:00:00.000','paid',60000,0,0,0,60000,NULL,NULL,0,'2026-07','2026-07-25 09:31:22.701','2026-07-27 09:29:45.520',NULL,NULL,NULL),(64,2,1,'CM-2026-0023','placement','2026-07-25 00:00:00.000','2026-07-30 00:00:00.000','paid',80000,0,0,0,80000,NULL,NULL,0,'2026-07','2026-07-25 09:32:49.527','2026-07-31 07:32:41.337',NULL,NULL,NULL),(65,2,8,'CM-2026-0024','placement','2026-07-27 00:00:00.000','2026-08-02 00:00:00.000','paid',85000,0,0,0,85000,NULL,NULL,0,'2026-07','2026-07-27 09:31:18.483','2026-08-01 10:52:52.968',NULL,NULL,NULL),(66,2,2,'CM-2026-0025','placement','2026-07-27 00:00:00.000','2026-08-02 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-07','2026-07-27 09:35:54.492','2026-07-31 07:32:52.499',NULL,NULL,NULL),(67,2,7,'CM-2026-0026','placement','2026-08-07 00:00:00.000','2026-08-13 00:00:00.000','paid',66000,0,0,0,66000,NULL,NULL,0,'2026-08','2026-08-07 16:08:29.384','2026-08-11 15:39:18.026',NULL,NULL,NULL),(68,2,3,'CM-2026-0027','placement','2026-08-07 00:00:00.000','2026-08-18 00:00:00.000','sent',55000,0,0,0,55000,NULL,NULL,0,'2026-08','2026-08-07 16:10:29.786','2026-08-07 16:10:33.999',NULL,NULL,NULL),(69,2,5,'CM-2026-0028','placement','2026-08-07 00:00:00.000','2026-08-21 00:00:00.000','sent',25000,0,0,0,25000,NULL,NULL,0,'2026-08','2026-08-07 16:12:03.141','2026-08-07 16:12:13.553',NULL,NULL,NULL),(70,2,6,'CM-2026-0029','placement','2026-08-10 00:00:00.000','2026-08-10 00:00:00.000','paid',65000,0,0,0,65000,NULL,NULL,0,'2026-08','2026-08-10 15:07:49.283','2026-08-10 15:08:00.951',NULL,NULL,NULL),(71,2,8,'CM-2026-0030','placement','2026-08-10 00:00:00.000','2026-08-30 00:00:00.000','paid',25000,0,0,0,25000,NULL,NULL,0,'2026-08','2026-08-10 15:23:46.217','2026-08-15 14:08:11.861',NULL,NULL,NULL),(72,1,13,'MG-2026-0039','placement','2026-07-27 00:00:00.000','2026-08-01 00:00:00.000','paid',825000,20,165000,0,990000,NULL,NULL,0,'2026-07','2026-08-18 13:18:36.335','2026-08-18 13:18:46.178',NULL,NULL,NULL),(73,1,14,'MG-2026-0040','placement','2026-08-01 00:00:00.000','2026-08-06 00:00:00.000','paid',250000,0,0,0,250000,NULL,NULL,0,'2026-07','2026-08-18 13:22:17.312','2026-08-18 13:22:35.940',NULL,NULL,NULL);
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvoiceLine`
--

DROP TABLE IF EXISTS `InvoiceLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoiceLine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `candidateId` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `unitPrice` double NOT NULL,
  `totalHT` double NOT NULL,
  `daysWorked` int DEFAULT NULL,
  `prorataCoef` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InvoiceLine_invoiceId_fkey` (`invoiceId`),
  KEY `InvoiceLine_missionId_fkey` (`missionId`),
  CONSTRAINT `InvoiceLine_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InvoiceLine_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceLine`
--

LOCK TABLES `InvoiceLine` WRITE;
/*!40000 ALTER TABLE `InvoiceLine` DISABLE KEYS */;
INSERT INTO `InvoiceLine` VALUES (1,1,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(2,2,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,80000,80000,NULL,NULL),(3,3,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,66000,66000,NULL,NULL),(4,4,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,55000,55000,NULL,NULL),(5,5,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,80000,80000,NULL,NULL),(6,6,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(7,7,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,60000,60000,NULL,NULL),(8,8,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(9,9,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,85000,85000,NULL,NULL),(10,10,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,65000,65000,NULL,NULL),(11,11,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,66000,66000,NULL,NULL),(12,12,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,25000,25000,NULL,NULL),(13,13,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,55000,55000,NULL,NULL),(14,14,NULL,NULL,'Salaire mensuel du personnel plus marge sur salaire',1,65000,65000,NULL,NULL),(16,15,NULL,NULL,'Placement de prestation ménagère',1,300000,300000,NULL,NULL),(17,16,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(18,17,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(19,18,NULL,NULL,'Placement de prestation de ménagère ',1,300000,300000,NULL,NULL),(20,19,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(21,20,NULL,NULL,'Placement de prestation de ménagère',1,300000,300000,NULL,NULL),(22,21,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(23,22,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(24,23,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(25,24,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(27,25,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(29,27,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(30,26,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(31,28,NULL,NULL,'Placement de prestation chauffeur',1,300000,300000,NULL,NULL),(33,29,NULL,NULL,'Placement de prestation chauffeur',1,300000,300000,NULL,NULL),(34,30,NULL,NULL,'Placement de prestation chauffeur',1,300000,300000,NULL,NULL),(35,31,NULL,NULL,'Placement de prestation chauffeur, prorata de 6j',1,50000,50000,NULL,NULL),(36,31,NULL,NULL,'Frais d\'inscription à l\'agence',1,30000,30000,NULL,NULL),(37,32,NULL,NULL,'Placement de prestation Chauffeur 1 (Mr Hery)',1,500000,500000,NULL,NULL),(38,32,NULL,NULL,'Placement de prestation Chauffeur 2 (Mr Anja)',1,500000,500000,NULL,NULL),(39,32,NULL,NULL,'Placement de prestation Chauffeur 3 (Mr Tanjona 13J)',1,217000,217000,NULL,NULL),(41,33,NULL,NULL,'salaire mensuel plus marge sur salaire',80000,1,80000,NULL,NULL),(42,34,NULL,NULL,'salaire mensuel plus marge sur salaire',1,60000,60000,NULL,NULL),(43,35,NULL,NULL,'salaire mensuel plus marge sur salaire',1,85000,85000,NULL,NULL),(44,36,NULL,NULL,'salaire mensuel plus marge sur salaire',1,65000,65000,NULL,NULL),(45,37,NULL,NULL,'Placement de prestation de chauffeur 1',1,500000,500000,NULL,NULL),(46,37,NULL,NULL,'Placement de prestation de chauffeur 2',1,500000,500000,NULL,NULL),(47,37,NULL,NULL,'Placement de prestation de chauffeur 3',1,500000,500000,NULL,NULL),(48,38,NULL,NULL,'Placement de prestation de chauffeur 1',1,500000,500000,NULL,NULL),(49,38,NULL,NULL,'Placement de prestation de chauffeur 2',1,500000,500000,NULL,NULL),(50,38,NULL,NULL,'Placement de prestation de chauffeur 3',1,500000,500000,NULL,NULL),(51,39,NULL,NULL,'Placement de prestation de chauffeur Mr Hery',1,500000,500000,NULL,NULL),(52,39,NULL,NULL,'Placement de prestation de chauffeur Mr Tahina 18j',1,300000,300000,NULL,NULL),(53,39,NULL,NULL,'Placement de prestation de chauffeur Mr Anja 24j',1,400000,400000,NULL,NULL),(54,39,NULL,NULL,'Placement de prestation de chauffeur Mr Franck 17j',1,272000,272000,NULL,NULL),(55,40,NULL,NULL,'Placement de prestation de chauffeur Mr Fiacre 4j',4,30000,120000,NULL,NULL),(56,40,NULL,NULL,'Placement de prestation de chauffeur Mr Franck',1,480000,480000,NULL,NULL),(57,40,NULL,NULL,'Placement de prestation de chauffeur Mr Hery',1,500000,500000,NULL,NULL),(58,40,NULL,NULL,'Placement de prestation de chauffeur Mr Anja',1,500000,500000,NULL,NULL),(59,41,NULL,NULL,'Placement de prestation de chauffeur Mr Hery',1,500000,500000,NULL,NULL),(60,41,NULL,NULL,'Placement de prestation de chauffeur Mr Anja',1,500000,500000,NULL,NULL),(61,41,NULL,NULL,'Placement de prestation de chauffeur Mr Tanjona 18j',1,300000,300000,NULL,NULL),(62,41,NULL,NULL,'Placement de prestation de chauffeur Mr Franck 9j',1,144000,144000,NULL,NULL),(63,41,NULL,NULL,'Placement de prestation de chauffeur Mr Mamy 14j',1,240000,240000,NULL,NULL),(64,41,NULL,NULL,'Heure supp Mr Tanjona',30,2000,60000,NULL,NULL),(65,32,NULL,NULL,'Placement de prestation de chauffeur Mr Mamy',1,500000,500000,NULL,NULL),(66,42,NULL,NULL,'Placement de prestation de Ménagère Mme Joeline',1,275000,275000,NULL,NULL),(67,42,NULL,NULL,'Placement de prestation de Ménagère Mme Felana',1,275000,275000,NULL,NULL),(68,42,NULL,NULL,'Placement de prestation de Nounou',1,275000,275000,NULL,NULL),(69,42,NULL,NULL,'Placement de prestation de Chauffeur',1,350000,350000,NULL,NULL),(70,43,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(71,44,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(72,45,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(74,46,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(75,47,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(76,48,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(77,49,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(78,50,NULL,NULL,'Placement de prestation de ménagère',1,250000,250000,NULL,NULL),(79,51,NULL,NULL,'Placement de prestation de chauffeur 20j',1,200000,200000,NULL,NULL),(80,52,NULL,NULL,'SALAIRE MENSUEL PLUS MARGE SUR SALAIRE',1,66000,66000,NULL,NULL),(81,53,NULL,NULL,'SALAIRE MENSUEL DU PERSONNEL PLUS FRAIS D\'AGENCE',1,55000,55000,NULL,NULL),(82,54,NULL,NULL,'SALAIRE MENSUEL DU PERSNNEL PLUS FRAIS D\'AGENCE',1,25000,25000,NULL,NULL),(83,55,NULL,NULL,'Placement de prestation de chauffeur ',1,300000,300000,NULL,NULL),(84,56,NULL,NULL,'Placement de prestation de chauffeur',1,300000,300000,NULL,NULL),(85,57,NULL,NULL,'Placement de prestation de chauffeur',1,300000,300000,NULL,NULL),(86,58,NULL,NULL,'Placement de prestation de chauffeur',1,150000,150000,NULL,NULL),(87,59,NULL,NULL,'Placement de prestation de Ménagère Résidente ',1,250000,250000,NULL,NULL),(88,60,NULL,NULL,'Placement de prestation de Ménagère',1,300000,300000,NULL,NULL),(89,61,NULL,NULL,'Placement de prestation de chauffeur 25j',1,250000,250000,NULL,NULL),(90,61,NULL,NULL,'Heure supp Mr Koloina',1.5,5000,7500,NULL,NULL),(91,61,NULL,NULL,'Heure supp Mr Dafront',7.5,5000,37500,NULL,NULL),(92,62,NULL,NULL,'Placement de prestation de chauffeur Mr Hery',1,500000,500000,NULL,NULL),(93,62,NULL,NULL,'Placement de prestation de chauffeur Mr Anja',1,500000,500000,NULL,NULL),(94,62,NULL,NULL,'Placement de prestation de chauffeur Mr Mamy ',1,500000,500000,NULL,NULL),(95,62,NULL,NULL,'Heure supp Mr Mamy',4.5,5000,22500,NULL,NULL),(96,63,NULL,NULL,'SALAIRE MENSUEL DU PERSONNEL PLUS FRAIS D\'AGENCE',60000,1,60000,NULL,NULL),(97,64,NULL,NULL,'SALAIRE MENSUEL DU PERSONNEL PLUS FRAIS D\'AGENCE',80000,1,80000,NULL,NULL),(98,65,NULL,NULL,'salaire mensuel du personnel plus frais d\'agence',85000,1,85000,NULL,NULL),(99,66,NULL,NULL,'salaire mensuel du personnel plus frais d\'agence',65000,1,65000,NULL,NULL),(100,67,NULL,NULL,'salaire mensuel du personnel plus frais D\'agence',66000,1,66000,NULL,NULL),(101,68,NULL,NULL,'salaire mensuel du personnel plus frais d\'agence',55000,1,55000,NULL,NULL),(102,69,NULL,NULL,'salaire mensuel du personnel plus frais d\'agence',25000,1,25000,NULL,NULL),(103,70,NULL,NULL,'salaire mensuel plus frais d\'agence',65000,1,65000,NULL,NULL),(104,71,NULL,NULL,'salaire mensuel du personnel plus frais d\'agence',25000,1,25000,NULL,NULL),(105,72,NULL,NULL,'Placement de personnel femme de ménage 1',1,275000,275000,NULL,NULL),(106,72,NULL,NULL,'Placement de personnel femme de ménage 2',1,275000,275000,NULL,NULL),(107,72,NULL,NULL,'Placement de personnel nounou ',1,275000,275000,NULL,NULL),(108,73,NULL,NULL,'Placement de personnel ménagère',1,250000,250000,NULL,NULL);
/*!40000 ALTER TABLE `InvoiceLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvoiceRelance`
--

DROP TABLE IF EXISTS `InvoiceRelance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoiceRelance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sentAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InvoiceRelance_invoiceId_fkey` (`invoiceId`),
  CONSTRAINT `InvoiceRelance_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceRelance`
--

LOCK TABLES `InvoiceRelance` WRITE;
/*!40000 ALTER TABLE `InvoiceRelance` DISABLE KEYS */;
/*!40000 ALTER TABLE `InvoiceRelance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IrsaBracket`
--

DROP TABLE IF EXISTS `IrsaBracket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IrsaBracket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `fromAmount` double NOT NULL,
  `toAmount` double DEFAULT NULL,
  `rate` double NOT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IrsaBracket_countryId_fkey` (`countryId`),
  CONSTRAINT `IrsaBracket_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IrsaBracket`
--

LOCK TABLES `IrsaBracket` WRITE;
/*!40000 ALTER TABLE `IrsaBracket` DISABLE KEYS */;
INSERT INTO `IrsaBracket` VALUES (1,1,0,350000,0,1),(2,1,350000,400000,5,2),(3,1,400000,500000,10,3),(4,1,500000,600000,15,4),(5,1,600000,NULL,20,5),(9,3,0,75000,0,1),(10,3,75000,240000,16,2),(11,3,240000,NULL,21,3),(33,2,0,62000,0,1),(34,2,62000,310000,10,2),(35,2,310000,NULL,15,3);
/*!40000 ALTER TABLE `IrsaBracket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mission`
--

DROP TABLE IF EXISTS `Mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Mission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `clientRate` double NOT NULL DEFAULT '0',
  `employeeRate` double NOT NULL DEFAULT '0',
  `agencyFee` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL DEFAULT '0',
  `commissionRate` double NOT NULL DEFAULT '12',
  `prorataBase` int NOT NULL DEFAULT '30',
  `trialPeriodEnd` datetime(3) DEFAULT NULL,
  `trialConfirmed` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdById` int DEFAULT NULL,
  `approvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Mission_countryId_fkey` (`countryId`),
  KEY `Mission_clientId_fkey` (`clientId`),
  KEY `Mission_candidateId_fkey` (`candidateId`),
  KEY `Mission_serviceId_fkey` (`serviceId`),
  CONSTRAINT `Mission_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mission`
--

LOCK TABLES `Mission` WRITE;
/*!40000 ALTER TABLE `Mission` DISABLE KEYS */;
INSERT INTO `Mission` VALUES (1,2,8,2,1,'placement','2026-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',90000,85000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 09:08:57.987','2026-06-16 09:08:57.987'),(2,2,2,7,1,'placement','2026-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:46:20.816','2026-06-16 11:46:20.816'),(3,2,6,6,1,'placement','2026-06-21 00:00:00.000','2026-12-21 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-21 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:53:38.153','2026-06-16 11:53:38.153'),(4,2,5,8,2,'placement','2024-06-07 00:00:00.000','2026-12-07 00:00:00.000','active',25000,20000,5000,0,12,30,'2026-12-07 00:00:00.000',0,NULL,8,NULL,'2026-06-16 11:59:56.359','2026-06-16 11:59:56.359'),(5,2,4,4,2,'placement','2024-04-30 00:00:00.000','2026-12-30 00:00:00.000','active',60000,55000,5000,0,12,30,'2026-12-30 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:02:40.038','2026-06-16 12:02:40.038'),(6,2,3,5,3,'placement','2025-04-18 00:00:00.000','2025-12-18 00:00:00.000','active',55000,50000,5000,0,12,30,'2026-12-18 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:04:11.364','2026-06-16 12:04:11.364'),(7,2,2,7,1,'placement','2025-06-04 00:00:00.000','2026-12-04 00:00:00.000','active',65000,60000,5000,0,12,30,'2026-12-04 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:05:33.183','2026-06-16 12:05:33.183'),(8,2,1,1,1,'placement','2026-01-30 00:00:00.000','2026-12-30 00:00:00.000','active',80000,75000,5000,0,12,30,'2026-07-16 00:00:00.000',0,NULL,8,NULL,'2026-06-16 12:07:13.160','2026-06-16 12:07:13.160'),(9,2,7,3,7,'placement','2024-04-13 00:00:00.000','2026-12-13 00:00:00.000','active',66000,61000,5000,0,12,30,'2026-12-13 00:00:00.000',0,NULL,8,NULL,'2026-06-19 13:08:14.461','2026-06-19 13:08:14.461'),(10,1,9,9,1,'placement','2025-12-23 00:00:00.000',NULL,'active',300000,250000,50000,0,12,30,'2025-12-30 00:00:00.000',0,NULL,9,NULL,'2026-06-24 14:00:36.112','2026-06-24 14:00:36.112'),(11,1,10,10,1,'placement','2025-11-05 00:00:00.000',NULL,'active',250000,200000,50000,0,12,30,'2025-11-12 00:00:00.000',0,NULL,9,NULL,'2026-06-24 14:44:42.662','2026-06-25 11:25:41.820'),(12,1,11,11,4,'placement','2026-03-26 00:00:00.000',NULL,'active',300000,250000,50000,0,12,30,'2026-04-02 00:00:00.000',0,NULL,9,NULL,'2026-06-25 12:25:58.001','2026-06-25 12:25:58.001'),(13,1,12,14,4,'placement','2026-05-18 00:00:00.000',NULL,'active',480000,400000,80000,0,12,30,'2026-05-23 00:00:00.000',0,NULL,9,NULL,'2026-06-30 07:16:10.087','2026-06-30 07:16:10.087'),(14,1,12,16,4,'placement','2025-09-23 00:00:00.000',NULL,'active',500000,450000,50000,0,12,30,'2025-09-30 00:00:00.000',0,NULL,9,NULL,'2026-06-30 07:52:36.415','2026-06-30 07:52:36.415'),(15,1,12,15,4,'placement','2026-03-09 00:00:00.000',NULL,'active',500000,400000,100000,0,12,30,'2026-03-16 00:00:00.000',0,NULL,9,NULL,'2026-06-30 07:53:30.149','2026-06-30 07:53:30.149'),(16,1,13,21,1,'placement','2025-12-18 00:00:00.000',NULL,'active',275000,250000,25000,0,12,30,'2025-12-25 00:00:00.000',0,NULL,9,NULL,'2026-06-30 09:37:10.852','2026-07-11 05:24:54.942'),(17,1,13,19,1,'placement','2025-10-09 00:00:00.000',NULL,'active',275000,250000,25000,0,12,30,'2025-10-16 00:00:00.000',0,NULL,9,NULL,'2026-06-30 09:38:23.423','2026-06-30 09:38:23.423'),(18,1,13,20,4,'placement','2026-05-04 00:00:00.000',NULL,'active',350000,300000,50000,0,12,30,'2026-05-11 00:00:00.000',0,NULL,9,NULL,'2026-06-30 09:39:41.417','2026-08-17 06:03:25.407'),(19,1,14,24,1,'placement','2026-06-15 00:00:00.000',NULL,'active',250000,200000,50000,0,12,30,'2026-06-22 00:00:00.000',0,NULL,9,NULL,'2026-07-01 10:58:09.557','2026-07-01 10:58:09.557'),(20,1,15,33,4,'placement','2026-07-10 00:00:00.000','2026-07-25 00:00:00.000','active',200000,180000,20000,0,12,30,'2026-07-10 00:00:00.000',0,'Chauffeur pour 2semaine, après le chauffeur est à la disposition de la cliente sans intervention de l\'agence',9,NULL,'2026-07-22 08:58:31.219','2026-07-22 12:21:03.371'),(21,1,13,25,4,'placement','2026-08-01 00:00:00.000',NULL,'active',350000,300000,50000,0,12,30,'2026-06-19 00:00:00.000',0,NULL,9,NULL,'2026-07-22 12:10:25.382','2026-08-17 05:37:09.575');
/*!40000 ALTER TABLE `Mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotifSetting`
--

DROP TABLE IF EXISTS `NotifSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NotifSetting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `threshold` int NOT NULL DEFAULT '7',
  PRIMARY KEY (`id`),
  UNIQUE KEY `NotifSetting_type_key` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotifSetting`
--

LOCK TABLES `NotifSetting` WRITE;
/*!40000 ALTER TABLE `NotifSetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotifSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Office`
--

DROP TABLE IF EXISTS `Office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Office` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Office_countryId_fkey` (`countryId`),
  CONSTRAINT `Office_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Office`
--

LOCK TABLES `Office` WRITE;
/*!40000 ALTER TABLE `Office` DISABLE KEYS */;
INSERT INTO `Office` VALUES (1,1,'Siège Antananarivo','LOT IIP 154 JC Météo Avaradoha','Antananarivo','+261 38 262 02 50','tana@usra-care.com',1,'2026-06-05 09:52:57.938'),(2,1,'Agence Antsirabe',NULL,'Antsirabe',NULL,'antsirabe@usra-care.com',1,'2026-06-05 09:52:57.951'),(3,2,'Bureau Douala','Makepe Bloc L','Douala',NULL,'douala@usra-care.com',1,'2026-06-05 09:52:57.965'),(4,3,'Bureau Abidjan',NULL,'Abidjan',NULL,'abidjan@usra-care.com',1,'2026-06-05 09:52:57.977');
/*!40000 ALTER TABLE `Office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OvertimeRecord`
--

DROP TABLE IF EXISTS `OvertimeRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OvertimeRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `hours` double NOT NULL,
  `hourlyRate` double NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdById` int DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `invoiceLineId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `OvertimeRecord_countryId_fkey` (`countryId`),
  KEY `OvertimeRecord_missionId_fkey` (`missionId`),
  KEY `OvertimeRecord_candidateId_fkey` (`candidateId`),
  KEY `OvertimeRecord_createdById_fkey` (`createdById`),
  KEY `OvertimeRecord_validatedById_fkey` (`validatedById`),
  KEY `OvertimeRecord_invoiceLineId_fkey` (`invoiceLineId`),
  CONSTRAINT `OvertimeRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_invoiceLineId_fkey` FOREIGN KEY (`invoiceLineId`) REFERENCES `InvoiceLine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OvertimeRecord`
--

LOCK TABLES `OvertimeRecord` WRITE;
/*!40000 ALTER TABLE `OvertimeRecord` DISABLE KEYS */;
INSERT INTO `OvertimeRecord` VALUES (1,1,13,14,'2026-07-12 00:00:00.000',3.5,5000,17500,'Renfort Chauffeur au Carlton','validated',9,1,'2026-07-22 17:00:05.810','2026-07-21 14:42:27.560',NULL),(2,1,13,14,'2026-07-14 00:00:00.000',1,5000,5000,'Récupérer un client à Ankadilalana ','validated',9,1,'2026-07-22 16:59:43.105','2026-07-21 14:46:02.828',NULL),(3,1,20,33,'2026-07-11 00:00:00.000',3.5,5000,17500,'','validated',9,1,'2026-07-22 17:00:08.360','2026-07-22 11:33:12.526',NULL),(4,1,20,33,'2026-07-13 00:00:00.000',2,5000,10000,'','validated',9,1,'2026-07-22 16:59:55.176','2026-07-22 11:33:59.470',NULL),(5,1,20,33,'2026-07-15 00:00:00.000',1,5000,5000,'','validated',9,1,'2026-07-22 16:59:38.124','2026-07-22 11:34:53.421',NULL),(6,1,20,33,'2026-07-17 00:00:00.000',1,5000,5000,'','validated',9,1,'2026-07-22 16:59:18.518','2026-07-22 11:35:45.638',NULL),(7,1,21,25,'2026-07-02 00:00:00.000',0.5,5000,2500,'','validated',9,1,'2026-07-22 17:00:22.485','2026-07-22 12:13:53.993',NULL),(8,1,21,25,'2026-07-07 00:00:00.000',0.5,5000,2500,'','validated',9,1,'2026-07-22 17:00:19.886','2026-07-22 12:15:07.944',NULL),(9,1,21,25,'2026-07-09 00:00:00.000',0.5,5000,2500,'','validated',9,1,'2026-07-22 17:00:15.641','2026-07-22 12:17:01.046',NULL);
/*!40000 ALTER TABLE `OvertimeRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Payment_invoiceId_fkey` (`invoiceId`),
  CONSTRAINT `Payment_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payment`
--

LOCK TABLES `Payment` WRITE;
/*!40000 ALTER TABLE `Payment` DISABLE KEYS */;
INSERT INTO `Payment` VALUES (1,37,1,'2026-06-29 12:52:38.916',1500000,'cash',NULL,NULL,'2026-06-29 12:52:38.917'),(2,38,1,'2026-06-29 12:55:55.042',1500000,'cash',NULL,NULL,'2026-06-29 12:55:55.043'),(3,1,2,'2026-04-27 00:00:00.000',65000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(4,2,2,'2026-04-27 00:00:00.000',80000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(5,3,2,'2026-05-08 00:00:00.000',66000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(6,4,2,'2026-05-13 00:00:00.000',55000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(7,5,2,'2026-05-25 00:00:00.000',80000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(8,6,2,'2026-04-27 00:00:00.000',65000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(9,7,2,'2026-05-25 00:00:00.000',60000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(10,8,2,'2026-05-25 00:00:00.000',65000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(11,9,2,'2026-06-01 00:00:00.000',85000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(12,10,2,'2026-06-01 00:00:00.000',65000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(13,11,2,'2026-06-08 00:00:00.000',66000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(14,12,2,'2026-06-15 00:00:00.000',25000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(15,13,2,'2026-06-15 00:00:00.000',55000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(16,15,1,'2026-06-24 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(17,16,1,'2026-01-22 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(18,17,1,'2026-02-19 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(19,18,1,'2026-03-30 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(20,19,1,'2026-04-28 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(21,20,1,'2026-05-28 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(22,21,1,'2026-06-24 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(23,22,1,'2026-05-28 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(24,23,1,'2026-04-29 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(25,24,1,'2026-03-30 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(26,25,1,'2026-02-26 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(27,26,1,'2026-01-29 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(28,27,1,'2025-12-29 00:00:00.000',250000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(29,28,1,'2026-06-09 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(30,29,1,'2026-05-26 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(31,30,1,'2026-04-30 00:00:00.000',300000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(32,31,1,'2026-04-01 00:00:00.000',80000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(33,33,2,'2026-06-26 00:00:00.000',80000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(34,34,2,'2026-06-26 00:00:00.000',60000,'cash',NULL,NULL,'2026-06-29 13:01:18.000'),(66,39,1,'2026-06-29 13:08:54.004',1472000,'cash',NULL,NULL,'2026-06-29 13:08:54.005'),(67,40,1,'2026-06-29 13:13:43.905',1600000,'cash',NULL,NULL,'2026-06-29 13:13:43.906'),(68,41,1,'2026-06-29 13:25:46.523',1744000,'cash',NULL,NULL,'2026-06-29 13:25:46.524'),(69,44,1,'2026-07-01 11:13:36.535',250000,'cash',NULL,NULL,'2026-07-01 11:13:36.536'),(70,45,1,'2026-07-01 11:16:21.578',250000,'cash',NULL,NULL,'2026-07-01 11:16:21.579'),(71,46,1,'2026-07-01 11:58:10.916',250000,'cash',NULL,NULL,'2026-07-01 11:58:10.917'),(72,47,1,'2026-07-01 12:02:33.277',250000,'cash',NULL,NULL,'2026-07-01 12:02:33.278'),(73,49,1,'2026-07-01 12:12:32.784',250000,'cash',NULL,NULL,'2026-07-01 12:12:32.786'),(74,50,1,'2026-07-01 12:12:49.152',250000,'cash',NULL,NULL,'2026-07-01 12:12:49.154'),(75,48,1,'2026-07-01 12:13:14.076',250000,'cash',NULL,NULL,'2026-07-01 12:13:14.077'),(76,32,1,'2026-06-17 00:00:00.000',340000,'cash',NULL,'acompte','2026-07-01 13:40:34.364'),(77,32,1,'2026-06-17 00:00:00.000',340000,'cash',NULL,'acompte','2026-07-01 13:43:48.740'),(78,32,1,'2026-06-17 00:00:00.000',340000,'cash',NULL,'acompte','2026-07-01 13:43:59.806'),(79,32,1,'2026-06-17 00:00:00.000',340000,'cash',NULL,'acompte','2026-07-01 13:48:31.130'),(80,42,1,'2026-07-01 14:47:45.477',1175000,'cash',NULL,NULL,'2026-07-01 14:47:45.478'),(81,14,2,'2026-07-02 15:36:34.467',65000,'cash',NULL,NULL,'2026-07-02 15:36:34.468'),(82,35,2,'2026-07-02 15:36:53.277',85000,'cash',NULL,NULL,'2026-07-02 15:36:53.278'),(83,32,1,'2026-07-03 00:00:00.000',1377000,'bank_transfer','00010244301','Reste de paiement de facture mois de Juin','2026-07-06 15:09:19.777'),(84,36,2,'2026-07-06 15:40:16.412',65000,'cash',NULL,NULL,'2026-07-06 15:40:16.413'),(85,43,1,'2026-07-10 06:26:45.836',250000,'cash',NULL,NULL,'2026-07-10 06:26:45.837'),(86,52,2,'2026-07-10 13:49:58.736',66000,'cash',NULL,NULL,'2026-07-10 13:49:58.737'),(87,51,1,'2026-07-15 06:24:01.618',200000,'cash',NULL,NULL,'2026-07-15 06:24:01.619'),(88,57,1,'2026-07-15 14:27:23.270',300000,'cash',NULL,NULL,'2026-07-15 14:27:23.271'),(89,58,1,'2026-07-15 14:27:53.322',150000,'cash',NULL,NULL,'2026-07-15 14:27:53.323'),(90,56,1,'2026-07-15 14:28:03.715',300000,'cash',NULL,NULL,'2026-07-15 14:28:03.716'),(91,53,2,'2026-07-18 10:50:26.712',55000,'cash',NULL,NULL,'2026-07-18 10:50:26.713'),(92,54,2,'2026-07-18 10:50:38.381',25000,'cash',NULL,NULL,'2026-07-18 10:50:38.382'),(93,60,1,'2026-07-23 14:32:58.999',300000,'cash',NULL,NULL,'2026-07-23 14:32:59.000'),(94,59,1,'2026-07-26 07:58:43.183',250000,'cash',NULL,NULL,'2026-07-26 07:58:43.184'),(95,63,2,'2026-07-27 09:29:45.482',60000,'cash',NULL,NULL,'2026-07-27 09:29:45.483'),(96,64,2,'2026-07-31 07:32:41.294',80000,'cash',NULL,NULL,'2026-07-31 07:32:41.295'),(97,66,2,'2026-07-31 07:32:52.456',65000,'cash',NULL,NULL,'2026-07-31 07:32:52.457'),(98,65,2,'2026-08-01 10:52:52.941',85000,'cash',NULL,NULL,'2026-08-01 10:52:52.942'),(99,70,2,'2026-08-10 15:08:00.927',65000,'cash',NULL,NULL,'2026-08-10 15:08:00.928'),(100,67,2,'2026-08-11 15:39:17.996',66000,'cash',NULL,NULL,'2026-08-11 15:39:17.997'),(101,62,1,'2026-08-12 08:54:22.824',1522500,'cash',NULL,NULL,'2026-08-12 08:54:22.825'),(102,61,1,'2026-08-13 06:50:16.782',295000,'cash',NULL,NULL,'2026-08-13 06:50:16.783'),(103,71,2,'2026-08-15 14:08:11.836',25000,'cash',NULL,NULL,'2026-08-15 14:08:11.837'),(104,55,1,'2026-08-18 13:16:16.849',300000,'cash',NULL,NULL,'2026-08-18 13:16:16.850'),(105,72,1,'2026-08-18 13:18:46.152',990000,'cash',NULL,NULL,'2026-08-18 13:18:46.153'),(106,73,1,'2026-08-18 13:22:35.911',250000,'cash',NULL,NULL,'2026-08-18 13:22:35.912');
/*!40000 ALTER TABLE `Payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payroll`
--

DROP TABLE IF EXISTS `Payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payroll` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `candidateId` int NOT NULL,
  `missionId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `prorataCoef` double NOT NULL DEFAULT '1',
  `netTarget` double NOT NULL,
  `gross` double NOT NULL,
  `totalEmpCotis` double NOT NULL DEFAULT '0',
  `totalEmprCotis` double NOT NULL DEFAULT '0',
  `irsa` double NOT NULL DEFAULT '0',
  `netBase` double NOT NULL,
  `overtimeAmount` double NOT NULL DEFAULT '0',
  `bonuses` double NOT NULL DEFAULT '0',
  `deductions` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL,
  `massSalariale` double NOT NULL DEFAULT '0',
  `cotisationsJson` json DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_validation',
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentRef` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentDate` datetime(3) DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Payroll_countryId_fkey` (`countryId`),
  KEY `Payroll_candidateId_fkey` (`candidateId`),
  KEY `Payroll_missionId_fkey` (`missionId`),
  KEY `Payroll_validatedById_fkey` (`validatedById`),
  CONSTRAINT `Payroll_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payroll`
--

LOCK TABLES `Payroll` WRITE;
/*!40000 ALTER TABLE `Payroll` DISABLE KEYS */;
INSERT INTO `Payroll` VALUES (1,2,2,1,'2026-06','placement',30,30,1,85000,87556,0,0,2556,85000,0,0,0,85000,87556,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-16 11:49:21.557',8,'2026-06-16 11:49:21.557','2026-06-16 10:11:02.424','2026-06-16 11:49:21.558'),(2,2,7,2,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-16 11:49:16.948',8,'2026-06-16 11:49:16.948','2026-06-16 11:46:51.774','2026-06-16 11:49:16.950'),(3,2,8,4,'2026-06','placement',30,30,1,20000,20001,0,0,0,20001,0,0,0,20001,20001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:03:18.686',8,'2026-06-19 13:03:18.686','2026-06-19 13:03:13.922','2026-06-19 13:03:18.687'),(4,2,5,6,'2026-06','placement',30,30,1,50000,50001,0,0,0,50001,0,0,0,50001,50001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:04:31.256',8,'2026-06-19 13:04:31.256','2026-06-19 13:04:28.392','2026-06-19 13:04:31.258'),(5,2,3,9,'2026-06','placement',30,30,1,61000,61001,0,0,0,61001,0,0,0,61001,61001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-19 13:08:58.355',8,'2026-06-19 13:08:58.355','2026-06-19 13:08:55.523','2026-06-19 13:08:58.357'),(6,2,4,5,'2026-06','placement',30,30,1,55000,55001,0,0,0,55001,0,0,0,55001,55001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-26 08:59:12.219',8,'2026-06-26 08:59:12.219','2026-06-26 08:59:08.786','2026-06-26 08:59:12.220'),(7,2,1,8,'2026-06','placement',30,30,1,75000,76445,0,0,1445,75000,0,0,0,75000,76445,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-06-27 10:41:41.433',8,'2026-06-27 10:41:41.433','2026-06-27 10:41:33.065','2026-06-27 10:41:41.434'),(8,2,6,3,'2026-07','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-02 15:40:49.677',8,'2026-07-02 15:40:49.677','2026-07-02 15:40:46.055','2026-07-02 15:40:49.678'),(9,2,2,1,'2026-07','placement',30,30,1,85000,87556,0,0,2556,85000,0,0,0,85000,87556,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-02 15:41:33.859',8,'2026-07-02 15:41:33.859','2026-07-02 15:41:31.827','2026-07-02 15:41:33.861'),(10,2,7,7,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-06 15:45:13.561',8,'2026-07-06 15:45:13.561','2026-07-06 15:45:04.965','2026-07-06 15:45:13.563'),(11,2,3,9,'2026-06','placement',30,30,1,61000,61001,0,0,0,61001,0,0,0,61001,61001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-10 14:00:43.481',8,'2026-07-10 14:00:43.481','2026-07-10 14:00:38.759','2026-07-10 14:00:43.482'),(12,1,24,19,'2026-06','placement',30,30,1,200000,200001,0,0,0,200001,0,0,0,200001,200001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:42:08.917',9,'2026-07-20 10:42:08.917','2026-07-11 05:27:52.711','2026-07-20 10:42:08.918'),(13,1,20,18,'2026-06','placement',30,30,1,300000,300001,0,0,0,300001,0,0,0,300001,300001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:42:06.867',9,'2026-07-20 10:42:06.867','2026-07-11 05:27:53.124','2026-07-20 10:42:06.868'),(14,1,19,17,'2026-06','placement',30,30,1,250000,250001,0,0,0,250001,0,0,0,250001,250001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:42:04.177',9,'2026-07-20 10:42:04.177','2026-07-11 05:27:53.499','2026-07-20 10:42:04.178'),(15,1,21,16,'2026-06','placement',30,30,1,250000,250001,0,0,0,250001,0,0,0,250001,250001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:42:02.139',9,'2026-07-20 10:42:02.139','2026-07-11 05:27:53.899','2026-07-20 10:42:02.140'),(16,1,15,15,'2026-06','placement',30,30,1,400000,402779,0,0,2778,400001,0,0,0,400001,402779,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:44.890',9,'2026-07-20 10:41:44.890','2026-07-11 05:27:54.248','2026-07-20 10:41:44.891'),(17,1,16,14,'2026-06','placement',30,30,1,450000,458332,0,0,8333,449999,0,0,0,449999,458332,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:42.624',9,'2026-07-20 10:41:42.624','2026-07-11 05:27:54.593','2026-07-20 10:41:42.626'),(18,1,14,13,'2026-06','placement',30,30,1,400000,402779,0,0,2778,400001,0,0,0,400001,402779,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:40.559',9,'2026-07-20 10:41:40.559','2026-07-11 05:27:55.067','2026-07-20 10:41:40.560'),(19,1,11,12,'2026-06','placement',30,30,1,250000,250001,0,0,0,250001,0,0,0,250001,250001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:38.461',9,'2026-07-20 10:41:38.461','2026-07-11 05:27:55.463','2026-07-20 10:41:38.462'),(20,1,10,11,'2026-06','placement',30,30,1,200000,200001,0,0,0,200001,0,0,0,200001,200001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:28.395',9,'2026-07-20 10:41:28.395','2026-07-11 05:27:55.849','2026-07-20 10:41:28.396'),(21,1,9,10,'2026-06','placement',30,30,1,250000,250001,0,0,0,250001,0,0,0,250001,250001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-20 10:41:22.338',9,'2026-07-20 10:41:22.338','2026-07-11 05:27:56.236','2026-07-20 10:41:22.339'),(22,2,3,9,'2026-06','placement',30,30,1,61000,61001,0,0,0,61001,0,0,0,61001,61001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:58:05.592',8,'2026-07-18 10:58:05.592','2026-07-11 05:27:56.657','2026-07-18 10:58:05.593'),(23,2,1,8,'2026-06','placement',30,30,1,75000,76445,0,0,1445,75000,0,0,0,75000,76445,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:58:06.552',8,'2026-07-18 10:58:06.552','2026-07-11 05:27:57.039','2026-07-18 10:58:06.553'),(24,2,7,7,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:58:07.635',8,'2026-07-18 10:58:07.635','2026-07-11 05:27:57.399','2026-07-18 10:58:07.636'),(25,2,5,6,'2026-06','placement',30,30,1,50000,50001,0,0,0,50001,0,0,0,50001,50001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:58:08.796',8,'2026-07-18 10:58:08.796','2026-07-11 05:27:57.845','2026-07-18 10:58:08.797'),(26,2,4,5,'2026-06','placement',30,30,1,55000,55001,0,0,0,55001,0,0,0,55001,55001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:57:58.505',8,'2026-07-18 10:57:58.505','2026-07-11 05:27:58.202','2026-07-18 10:57:58.507'),(27,2,8,4,'2026-06','placement',30,30,1,20000,20001,0,0,0,20001,0,0,0,20001,20001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:57:56.845',8,'2026-07-18 10:57:56.845','2026-07-11 05:27:58.614','2026-07-18 10:57:56.846'),(28,2,6,3,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:57:55.809',8,'2026-07-18 10:57:55.809','2026-07-11 05:27:58.979','2026-07-18 10:57:55.810'),(29,2,7,2,'2026-06','placement',30,30,1,60000,60001,0,0,0,60001,0,0,0,60001,60001,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:57:54.521',8,'2026-07-18 10:57:54.521','2026-07-11 05:27:59.941','2026-07-18 10:57:54.523'),(30,2,2,1,'2026-06','placement',30,30,1,85000,87556,0,0,2556,85000,0,0,0,85000,87556,'{\"employee\": [], \"employer\": []}','paid',1,NULL,NULL,'2026-07-18 10:57:52.876',8,'2026-07-18 10:57:52.876','2026-07-11 05:28:00.546','2026-07-18 10:57:52.877'),(31,2,3,9,'2026-07','placement',30,30,1,61000,61001,0,0,0,61001,0,0,0,61001,61001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-18 10:59:15.188',8,'2026-07-18 10:59:15.188','2026-07-18 10:59:07.096','2026-07-18 10:59:15.190'),(32,2,8,4,'2026-07','placement',30,30,1,20000,20001,0,0,0,20001,0,0,0,20001,20001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-18 11:00:00.330',8,'2026-07-18 11:00:00.330','2026-07-18 10:59:57.631','2026-07-18 11:00:00.331'),(33,2,5,6,'2026-07','placement',30,30,1,50000,50001,0,0,0,50001,0,0,0,50001,50001,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-18 11:00:35.018',8,'2026-07-18 11:00:35.018','2026-07-18 11:00:31.047','2026-07-18 11:00:35.019'),(34,1,14,13,'2026-07','placement',30,30,1,400000,402778,0,0,2778,400000,22500,0,100000,322500,402778,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-18 13:28:07.904',9,'2026-08-18 13:28:07.904','2026-07-23 10:18:59.860','2026-08-18 13:28:07.905'),(35,1,15,15,'2026-07','placement',30,30,1,400000,402778,0,0,2778,400000,0,0,0,400000,402778,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-18 13:28:10.900',9,'2026-08-18 13:28:10.900','2026-07-29 13:49:04.939','2026-08-18 13:28:10.901'),(36,1,9,10,'2026-07','placement',30,30,1,250000,250000,0,0,0,250000,0,0,0,250000,250000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-29 13:59:14.338',9,'2026-07-29 13:59:14.338','2026-07-29 13:59:07.333','2026-07-29 13:59:14.340'),(37,1,10,11,'2026-07','placement',30,30,1,200000,200000,0,0,0,200000,0,0,0,200000,200000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-29 13:59:30.999',9,'2026-07-29 13:59:30.999','2026-07-29 13:59:27.502','2026-07-29 13:59:31.000'),(38,2,1,8,'2026-07','placement',30,30,1,75000,76445,0,0,1445,75000,0,0,0,75000,76445,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-31 07:34:59.420',8,'2026-07-31 07:34:59.420','2026-07-31 07:34:56.501','2026-07-31 07:34:59.421'),(39,2,7,2,'2026-07','placement',30,30,1,60000,60000,0,0,0,60000,0,0,0,60000,60000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-31 07:35:19.464',8,'2026-07-31 07:35:19.464','2026-07-31 07:35:16.074','2026-07-31 07:35:19.466'),(40,2,4,5,'2026-07','placement',30,30,1,55000,55000,0,0,0,55000,0,0,0,55000,55000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-07-31 07:35:55.048',8,'2026-07-31 07:35:55.048','2026-07-31 07:35:52.365','2026-07-31 07:35:55.049'),(41,2,2,1,'2026-08','placement',30,30,1,85000,87556,0,0,2556,85000,0,0,0,85000,87556,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-01 10:55:14.581',8,'2026-08-01 10:55:14.581','2026-08-01 10:55:10.652','2026-08-01 10:55:14.582'),(42,2,6,3,'2026-07','placement',30,30,1,60000,60000,0,0,0,60000,0,0,0,60000,60000,'{\"employee\": [], \"employer\": []}','pending_validation',0,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:08:43.058','2026-08-10 15:08:43.058'),(43,2,3,9,'2026-08','placement',30,30,1,61000,61000,0,0,0,61000,0,0,0,61000,61000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-15 14:12:30.837',8,'2026-08-15 14:12:30.837','2026-08-11 15:37:22.422','2026-08-15 14:12:30.839'),(44,2,3,9,'2026-08','placement',30,30,1,61000,61000,0,0,0,61000,0,0,0,61000,61000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-11 15:37:40.595',8,'2026-08-11 15:37:40.595','2026-08-11 15:37:28.742','2026-08-11 15:37:40.596'),(45,2,8,4,'2026-08','placement',30,30,1,20000,20000,0,0,0,20000,0,0,0,20000,20000,'{\"employee\": [], \"employer\": []}','paid',0,NULL,NULL,'2026-08-15 14:12:49.297',8,'2026-08-15 14:12:49.297','2026-08-15 14:12:46.466','2026-08-15 14:12:49.298');
/*!40000 ALTER TABLE `Payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Service`
--

DROP TABLE IF EXISTS `Service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interviewTemplate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service`
--

LOCK TABLES `Service` WRITE;
/*!40000 ALTER TABLE `Service` DISABLE KEYS */;
INSERT INTO `Service` VALUES (1,'Ménage','long_term','🏠','menage',1,'2026-06-05 09:52:58.728',NULL,NULL),(2,'Cuisine','long_term','🍳','cuisine',1,'2026-06-05 09:52:58.743',NULL,NULL),(3,'Garde d\'enfants','long_term','👶','nounou',1,'2026-06-05 09:52:58.752',NULL,NULL),(4,'Chauffeur','long_term','🚗','chauffeur',1,'2026-06-05 09:52:58.762',NULL,NULL),(5,'Gardiennage','long_term','🛡️','gardien',1,'2026-06-05 09:52:58.774',NULL,NULL),(6,'Jardinage','long_term','🌿','jardinier',1,'2026-06-05 09:52:58.788',NULL,NULL),(7,'Nettoyage entreprise','long_term','🏢','menage',1,'2026-06-05 09:52:58.797',NULL,NULL),(8,'Agent de sécurité','long_term','lock','securite',1,'2026-06-05 09:52:58.806','personnel_maison',NULL),(9,'Aide personne âgée','long_term','🤝','aide_senior',1,'2026-06-05 09:52:58.816',NULL,NULL),(10,'Plomberie','short_term','🔧','technique',1,'2026-06-05 09:52:58.825',NULL,NULL),(11,'Électricité','short_term','⚡','technique',1,'2026-06-05 09:52:58.836',NULL,NULL),(12,'Peinture','short_term','🎨','technique',1,'2026-06-05 09:52:58.847',NULL,NULL),(13,'Ingénieur Logiciel','long_term','💻','qualifie',1,'2026-06-05 09:52:58.861',NULL,NULL),(14,'Comptable','long_term','📊','qualifie',1,'2026-06-05 09:52:58.874',NULL,NULL),(15,'Réceptionniste','long_term','briefcase','reception',1,'2026-06-05 09:52:58.886','personnel_maison',NULL);
/*!40000 ALTER TABLE `Service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceRate`
--

DROP TABLE IF EXISTS `ServiceRate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceRate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serviceId` int NOT NULL,
  `countryId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minRate` double NOT NULL,
  `maxRate` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ServiceRate_serviceId_fkey` (`serviceId`),
  CONSTRAINT `ServiceRate_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceRate`
--

LOCK TABLES `ServiceRate` WRITE;
/*!40000 ALTER TABLE `ServiceRate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceRate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Target`
--

DROP TABLE IF EXISTS `Target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Target` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetValue` double NOT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Target_userId_fkey` (`userId`),
  KEY `Target_countryId_fkey` (`countryId`),
  CONSTRAINT `Target_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Target_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Target`
--

LOCK TABLES `Target` WRITE;
/*!40000 ALTER TABLE `Target` DISABLE KEYS */;
/*!40000 ALTER TABLE `Target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countryId` int DEFAULT NULL,
  `officeId` int DEFAULT NULL,
  `avatar` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  KEY `User_countryId_fkey` (`countryId`),
  KEY `User_officeId_fkey` (`officeId`),
  CONSTRAINT `User_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'Admin','Global','admin@usra-care.com','','admin',NULL,NULL,'AG',1,'$2b$10$0lu6Rpt3/Hdi/cqbGMSOZ.Aq7LQSchgligAt.RwWs0nbtvWYMBiM.','2026-06-05 09:52:58.156','2026-07-14 10:01:56.461'),(8,'Leonie','Voukeng','leonie.voukeng@carebusinessconsulting.com','','operator',2,3,'LV',1,'$2b$10$Qis5Yu80D1sSoUqehEOziOcfYAmfXdqBCOZI7UJMBaC/QU3fiaiAa','2026-06-12 11:21:55.965','2026-06-12 11:21:55.965'),(9,'SHARONNE','EDSON','edson.sharonne@usra-care.com','','operator',1,1,'SE',1,'$2b$10$q0TY.dJeHQ5plUg4eYamJO5L.W5FAU7xvhOVIW90NtMXRQr626JaK','2026-06-23 10:03:34.622','2026-06-23 10:03:34.622'),(10,'Alexandra','Mebe','alexandra.mebe@usra-care.com',NULL,'dg',NULL,NULL,'👩',1,'$2b$10$C3N2uLXNS8K2QQK0IVmKSurDQWjWEEE2.RSDIwgC2uTQzuacJR7kG','2026-07-22 16:33:58.000','2026-07-22 16:33:58.000');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'usra_backoffice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-19  2:00:02
