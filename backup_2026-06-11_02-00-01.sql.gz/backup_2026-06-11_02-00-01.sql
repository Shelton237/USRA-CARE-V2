-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: usra_backoffice
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Advance`
--

DROP TABLE IF EXISTS `Advance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Advance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `amount` double NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requestDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `approvedById` int DEFAULT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `payrollId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `mobileProvider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Advance_candidateId_fkey` (`candidateId`),
  KEY `Advance_approvedById_fkey` (`approvedById`),
  KEY `Advance_payrollId_fkey` (`payrollId`),
  CONSTRAINT `Advance_approvedById_fkey` FOREIGN KEY (`approvedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Advance_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Advance_payrollId_fkey` FOREIGN KEY (`payrollId`) REFERENCES `Payroll` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Advance`
--

LOCK TABLES `Advance` WRITE;
/*!40000 ALTER TABLE `Advance` DISABLE KEYS */;
/*!40000 ALTER TABLE `Advance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttendanceRecord`
--

DROP TABLE IF EXISTS `AttendanceRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AttendanceRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `absJustified` int NOT NULL DEFAULT '0',
  `absUnjustified` int NOT NULL DEFAULT '0',
  `paidLeave` int NOT NULL DEFAULT '0',
  `holidays` int NOT NULL DEFAULT '0',
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `AttendanceRecord_missionId_period_key` (`missionId`,`period`),
  KEY `AttendanceRecord_countryId_fkey` (`countryId`),
  KEY `AttendanceRecord_candidateId_fkey` (`candidateId`),
  KEY `AttendanceRecord_createdById_fkey` (`createdById`),
  CONSTRAINT `AttendanceRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AttendanceRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttendanceRecord`
--

LOCK TABLES `AttendanceRecord` WRITE;
/*!40000 ALTER TABLE `AttendanceRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `AttendanceRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` int DEFAULT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_userId_fkey` (`userId`),
  CONSTRAINT `AuditLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES (1,1,'LOGIN','auth',NULL,'Connexion réussie — admin@usra-care.com','2026-06-10 16:34:18.008');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Candidate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'M',
  `birthDate` datetime(3) DEFAULT NULL,
  `nationalId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyName2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyPhone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyRelation2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantorJob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primarySpecialtyId` int DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'applied',
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'walk_in',
  `paymentMethodPref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mobile_money',
  `mobileMoneyAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recruitedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Candidate_countryId_fkey` (`countryId`),
  KEY `Candidate_officeId_fkey` (`officeId`),
  CONSTRAINT `Candidate_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Candidate_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateSpecialty`
--

DROP TABLE IF EXISTS `CandidateSpecialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateSpecialty` (
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `isPrimary` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`candidateId`,`serviceId`),
  KEY `CandidateSpecialty_serviceId_fkey` (`serviceId`),
  CONSTRAINT `CandidateSpecialty_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateSpecialty_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateSpecialty`
--

LOCK TABLES `CandidateSpecialty` WRITE;
/*!40000 ALTER TABLE `CandidateSpecialty` DISABLE KEYS */;
/*!40000 ALTER TABLE `CandidateSpecialty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CashEntry`
--

DROP TABLE IF EXISTS `CashEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CashEntry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CashEntry_countryId_fkey` (`countryId`),
  CONSTRAINT `CashEntry_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CashEntry`
--

LOCK TABLES `CashEntry` WRITE;
/*!40000 ALTER TABLE `CashEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `CashEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `officeId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'individual',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `nif` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commissionRate` double NOT NULL DEFAULT '12',
  `paymentTermsDays` int NOT NULL DEFAULT '5',
  `overtimeRate` double NOT NULL DEFAULT '0',
  `billingFreq` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `agencyFee` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Client_countryId_fkey` (`countryId`),
  KEY `Client_officeId_fkey` (`officeId`),
  CONSTRAINT `Client_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Client_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Complaint`
--

DROP TABLE IF EXISTS `Complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Complaint` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `receivedVia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phone',
  `receivedById` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'moderate',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `decision` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decisionDetail` text COLLATE utf8mb4_unicode_ci,
  `resolvedAt` datetime(3) DEFAULT NULL,
  `resolvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Complaint_countryId_fkey` (`countryId`),
  KEY `Complaint_clientId_fkey` (`clientId`),
  KEY `Complaint_receivedById_fkey` (`receivedById`),
  CONSTRAINT `Complaint_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Complaint_receivedById_fkey` FOREIGN KEY (`receivedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Complaint`
--

LOCK TABLES `Complaint` WRITE;
/*!40000 ALTER TABLE `Complaint` DISABLE KEYS */;
/*!40000 ALTER TABLE `Complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComplaintCandidate`
--

DROP TABLE IF EXISTS `ComplaintCandidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ComplaintCandidate` (
  `complaintId` int NOT NULL,
  `candidateId` int NOT NULL,
  PRIMARY KEY (`complaintId`,`candidateId`),
  KEY `ComplaintCandidate_candidateId_fkey` (`candidateId`),
  CONSTRAINT `ComplaintCandidate_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ComplaintCandidate_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `Complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComplaintCandidate`
--

LOCK TABLES `ComplaintCandidate` WRITE;
/*!40000 ALTER TABLE `ComplaintCandidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ComplaintCandidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contribution`
--

DROP TABLE IF EXISTS `Contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Contribution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` double NOT NULL,
  `base` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gross',
  `part` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Contribution_countryId_fkey` (`countryId`),
  CONSTRAINT `Contribution_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contribution`
--

LOCK TABLES `Contribution` WRITE;
/*!40000 ALTER TABLE `Contribution` DISABLE KEYS */;
/*!40000 ALTER TABLE `Contribution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currencyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchangeToEur` double NOT NULL DEFAULT '1',
  `phonePrefix` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoicePrefix` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `entityName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legalMention` text COLLATE utf8mb4_unicode_ci,
  `vatRate` double NOT NULL DEFAULT '20',
  `syntheticTaxEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `syntheticTaxRate` double NOT NULL DEFAULT '0',
  `prorataBase` int NOT NULL DEFAULT '30',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `mobileMoneyProviders` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Country_code_key` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'Madagascar','MG','MGA','Ariary','Ar',0.0002,'+261','MG',1,'USRA CARE SARLU','NIF : 5018370696','STAT : 81211 11 2023 0 11485','LOT IIP 154 JC Météo Avaradoha','Antananarivo 101','+261 38 262 02 50','contact@usra-care.com','BNI Madagascar','00001 23456 78901234567 89','SARL unipersonnelle au capital de 1 000 000 Ar',20,1,5,30,'2026-06-05 09:52:57.884','2026-06-05 09:52:57.884','Mvola, Orange Money'),(2,'Cameroun','CM','XAF','Franc CFA','FCFA',0.00152,'+237','CM',1,'USRA CARE Cameroun SARL','NIU : M021912345678X','RCCM : RC/DLA/2024/B/1234','Rue Bonapriso, BP 12345','Douala','','','','10005 00012 12345678901 23','SARL au capital de 1 000 000 FCFA',19.25,0,0,30,'2026-06-05 09:52:57.910','2026-06-06 19:42:10.238','Orange Money, MTN Mobile Money'),(3,'Côte d\'Ivoire','CI','XOF','Franc CFA Ouest','FCFA',0.00152,'+225','CI',1,'USRA CARE Côte d\'Ivoire SARL',NULL,NULL,NULL,'Abidjan',NULL,NULL,NULL,NULL,NULL,18,0,0,30,'2026-06-05 09:52:57.924','2026-06-05 09:52:57.924','Wave, Orange Money');
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EquipmentRecord`
--

DROP TABLE IF EXISTS `EquipmentRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EquipmentRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `countryId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `items` json NOT NULL,
  `totalValue` double NOT NULL DEFAULT '0',
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `returnedAt` datetime(3) DEFAULT NULL,
  `returnedItems` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `EquipmentRecord_candidateId_fkey` (`candidateId`),
  KEY `EquipmentRecord_countryId_fkey` (`countryId`),
  KEY `EquipmentRecord_missionId_fkey` (`missionId`),
  CONSTRAINT `EquipmentRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `EquipmentRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EquipmentRecord`
--

LOCK TABLES `EquipmentRecord` WRITE;
/*!40000 ALTER TABLE `EquipmentRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `EquipmentRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Evaluation`
--

DROP TABLE IF EXISTS `Evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Evaluation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `clientId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `overallRating` double NOT NULL,
  `punctuality` int NOT NULL DEFAULT '0',
  `quality` int NOT NULL DEFAULT '0',
  `behavior` int NOT NULL DEFAULT '0',
  `appearance` int NOT NULL DEFAULT '0',
  `instructions` int NOT NULL DEFAULT '0',
  `discretion` int NOT NULL DEFAULT '0',
  `honesty` int NOT NULL DEFAULT '0',
  `initiative` int NOT NULL DEFAULT '0',
  `hygiene` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `recommend` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Evaluation_candidateId_fkey` (`candidateId`),
  KEY `Evaluation_clientId_fkey` (`clientId`),
  CONSTRAINT `Evaluation_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Evaluation_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Evaluation`
--

LOCK TABLES `Evaluation` WRITE;
/*!40000 ALTER TABLE `Evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Interview`
--

DROP TABLE IF EXISTS `Interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Interview` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateId` int NOT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answers` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Interview_candidateId_key` (`candidateId`),
  CONSTRAINT `Interview_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Interview`
--

LOCK TABLES `Interview` WRITE;
/*!40000 ALTER TABLE `Interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `Interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InterviewTemplate`
--

DROP TABLE IF EXISTS `InterviewTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InterviewTemplate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sections` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InterviewTemplate_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InterviewTemplate`
--

LOCK TABLES `InterviewTemplate` WRITE;
/*!40000 ALTER TABLE `InterviewTemplate` DISABLE KEYS */;
INSERT INTO `InterviewTemplate` VALUES (1,'menage','Ménage / Entretien','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de logements\"}, {\"type\": \"multiselect\", \"label\": \"Produits maîtrisés\"}, {\"type\": \"textarea\", \"label\": \"Références clients\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Repassage\"}, {\"type\": \"boolean\", \"label\": \"Cuisine simple\"}, {\"type\": \"boolean\", \"label\": \"Garde enfants\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Test dépoussiérage\"}, {\"type\": \"rating5\", \"label\": \"Test vitres\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(2,'cuisine','Cuisine / Chef','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types d\'établissements\"}, {\"type\": \"multiselect\", \"label\": \"Spécialités culinaires\"}, {\"type\": \"textarea\", \"label\": \"Plats phares\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Sait planifier des menus\"}, {\"type\": \"boolean\", \"label\": \"Gestion budget courses\"}, {\"type\": \"boolean\", \"label\": \"Formation hygiène (HACCP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test cuisine\"}, {\"type\": \"text\", \"label\": \"Plat préparé\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(3,'securite','Agent de sécurité','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Secteurs gardés\"}, {\"type\": \"textarea\", \"label\": \"Diplômes / certifications\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Permis de conduire\"}, {\"type\": \"boolean\", \"label\": \"Maîtrise outil radio\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours (SSIAP)\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Aptitude physique\"}, {\"type\": \"rating5\", \"label\": \"Gestion stress\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:09:52.906'),(4,'chauffeur','Chauffeur','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Types de véhicules\"}, {\"type\": \"multiselect\", \"label\": \"Catégorie de permis\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Connaissance de la ville\"}, {\"type\": \"boolean\", \"label\": \"Mécanique de base\"}, {\"type\": \"boolean\", \"label\": \"Conduite défensive\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating20\", \"label\": \"Test de conduite\"}, {\"type\": \"rating20\", \"label\": \"Code de la route\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(5,'garde_enfants','Garde d\'enfants','[{\"title\": \"Expérience\", \"questions\": [{\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Tranches d\'âge\"}, {\"type\": \"multiselect\", \"label\": \"Activités proposées\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Compétences\", \"questions\": [{\"type\": \"boolean\", \"label\": \"Formation petite enfance\"}, {\"type\": \"boolean\", \"label\": \"Aide aux devoirs\"}, {\"type\": \"boolean\", \"label\": \"Premiers secours nourrissons\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}]}, {\"title\": \"Tests\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Interaction enfant\"}, {\"type\": \"rating5\", \"label\": \"Patience / empathie\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156'),(6,'general','Questionnaire général','[{\"title\": \"Profil\", \"questions\": [{\"type\": \"text\", \"label\": \"Niveau d\'études\"}, {\"type\": \"number\", \"label\": \"Années d\'expérience\"}, {\"type\": \"multiselect\", \"label\": \"Compétences clés\"}, {\"type\": \"textarea\", \"label\": \"Références\"}]}, {\"title\": \"Aptitudes\", \"questions\": [{\"type\": \"rating5\", \"label\": \"Ponctualité\"}, {\"type\": \"rating5\", \"label\": \"Présentation\"}, {\"type\": \"textarea\", \"label\": \"Langues\"}, {\"type\": \"number\", \"label\": \"Prétention salariale\"}]}]','2026-06-06 08:08:08.156','2026-06-06 08:08:08.156');
/*!40000 ALTER TABLE `InterviewTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `subtotalHT` double NOT NULL DEFAULT '0',
  `vatRate` double NOT NULL DEFAULT '20',
  `vatAmount` double NOT NULL DEFAULT '0',
  `syntheticTax` double NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `period` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `mobileProvider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Invoice_reference_key` (`reference`),
  KEY `Invoice_countryId_fkey` (`countryId`),
  KEY `Invoice_clientId_fkey` (`clientId`),
  CONSTRAINT `Invoice_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Invoice_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvoiceLine`
--

DROP TABLE IF EXISTS `InvoiceLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoiceLine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `missionId` int DEFAULT NULL,
  `candidateId` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `unitPrice` double NOT NULL,
  `totalHT` double NOT NULL,
  `daysWorked` int DEFAULT NULL,
  `prorataCoef` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InvoiceLine_invoiceId_fkey` (`invoiceId`),
  KEY `InvoiceLine_missionId_fkey` (`missionId`),
  CONSTRAINT `InvoiceLine_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InvoiceLine_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceLine`
--

LOCK TABLES `InvoiceLine` WRITE;
/*!40000 ALTER TABLE `InvoiceLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `InvoiceLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IrsaBracket`
--

DROP TABLE IF EXISTS `IrsaBracket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IrsaBracket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `fromAmount` double NOT NULL,
  `toAmount` double DEFAULT NULL,
  `rate` double NOT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IrsaBracket_countryId_fkey` (`countryId`),
  CONSTRAINT `IrsaBracket_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IrsaBracket`
--

LOCK TABLES `IrsaBracket` WRITE;
/*!40000 ALTER TABLE `IrsaBracket` DISABLE KEYS */;
INSERT INTO `IrsaBracket` VALUES (1,1,0,350000,0,1),(2,1,350000,400000,5,2),(3,1,400000,500000,10,3),(4,1,500000,600000,15,4),(5,1,600000,NULL,20,5),(9,3,0,75000,0,1),(10,3,75000,240000,16,2),(11,3,240000,NULL,21,3),(27,2,0,62000,0,1),(28,2,62000,310000,10,2),(29,2,310000,NULL,15,3);
/*!40000 ALTER TABLE `IrsaBracket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mission`
--

DROP TABLE IF EXISTS `Mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Mission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `clientId` int NOT NULL,
  `candidateId` int NOT NULL,
  `serviceId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `clientRate` double NOT NULL DEFAULT '0',
  `employeeRate` double NOT NULL DEFAULT '0',
  `agencyFee` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL DEFAULT '0',
  `commissionRate` double NOT NULL DEFAULT '12',
  `prorataBase` int NOT NULL DEFAULT '30',
  `trialPeriodEnd` datetime(3) DEFAULT NULL,
  `trialConfirmed` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdById` int DEFAULT NULL,
  `approvedById` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Mission_countryId_fkey` (`countryId`),
  KEY `Mission_clientId_fkey` (`clientId`),
  KEY `Mission_candidateId_fkey` (`candidateId`),
  KEY `Mission_serviceId_fkey` (`serviceId`),
  CONSTRAINT `Mission_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Mission_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mission`
--

LOCK TABLES `Mission` WRITE;
/*!40000 ALTER TABLE `Mission` DISABLE KEYS */;
/*!40000 ALTER TABLE `Mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotifSetting`
--

DROP TABLE IF EXISTS `NotifSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NotifSetting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `threshold` int NOT NULL DEFAULT '7',
  PRIMARY KEY (`id`),
  UNIQUE KEY `NotifSetting_type_key` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotifSetting`
--

LOCK TABLES `NotifSetting` WRITE;
/*!40000 ALTER TABLE `NotifSetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotifSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Office`
--

DROP TABLE IF EXISTS `Office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Office` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Office_countryId_fkey` (`countryId`),
  CONSTRAINT `Office_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Office`
--

LOCK TABLES `Office` WRITE;
/*!40000 ALTER TABLE `Office` DISABLE KEYS */;
INSERT INTO `Office` VALUES (1,1,'Siège Antananarivo','LOT IIP 154 JC Météo Avaradoha','Antananarivo','+261 38 262 02 50','tana@usra-care.com',1,'2026-06-05 09:52:57.938'),(2,1,'Agence Antsirabe',NULL,'Antsirabe',NULL,'antsirabe@usra-care.com',1,'2026-06-05 09:52:57.951'),(3,2,'Bureau Douala',NULL,'Douala',NULL,'douala@usra-care.com',1,'2026-06-05 09:52:57.965'),(4,3,'Bureau Abidjan',NULL,'Abidjan',NULL,'abidjan@usra-care.com',1,'2026-06-05 09:52:57.977');
/*!40000 ALTER TABLE `Office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OvertimeRecord`
--

DROP TABLE IF EXISTS `OvertimeRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OvertimeRecord` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `missionId` int NOT NULL,
  `candidateId` int NOT NULL,
  `date` datetime(3) NOT NULL,
  `hours` double NOT NULL,
  `hourlyRate` double NOT NULL,
  `amount` double NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdById` int DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `OvertimeRecord_countryId_fkey` (`countryId`),
  KEY `OvertimeRecord_missionId_fkey` (`missionId`),
  KEY `OvertimeRecord_candidateId_fkey` (`candidateId`),
  KEY `OvertimeRecord_createdById_fkey` (`createdById`),
  KEY `OvertimeRecord_validatedById_fkey` (`validatedById`),
  CONSTRAINT `OvertimeRecord_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OvertimeRecord_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OvertimeRecord`
--

LOCK TABLES `OvertimeRecord` WRITE;
/*!40000 ALTER TABLE `OvertimeRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `OvertimeRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileProvider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Payment_invoiceId_fkey` (`invoiceId`),
  CONSTRAINT `Payment_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payment`
--

LOCK TABLES `Payment` WRITE;
/*!40000 ALTER TABLE `Payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payroll`
--

DROP TABLE IF EXISTS `Payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payroll` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countryId` int NOT NULL,
  `candidateId` int NOT NULL,
  `missionId` int NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysWorked` int NOT NULL,
  `prorataBase` int NOT NULL DEFAULT '30',
  `prorataCoef` double NOT NULL DEFAULT '1',
  `netTarget` double NOT NULL,
  `gross` double NOT NULL,
  `totalEmpCotis` double NOT NULL DEFAULT '0',
  `totalEmprCotis` double NOT NULL DEFAULT '0',
  `irsa` double NOT NULL DEFAULT '0',
  `netBase` double NOT NULL,
  `overtimeAmount` double NOT NULL DEFAULT '0',
  `bonuses` double NOT NULL DEFAULT '0',
  `deductions` double NOT NULL DEFAULT '0',
  `netSalary` double NOT NULL,
  `massSalariale` double NOT NULL DEFAULT '0',
  `cotisationsJson` json DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_validation',
  `autoGenerated` tinyint(1) NOT NULL DEFAULT '0',
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentRef` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentDate` datetime(3) DEFAULT NULL,
  `validatedById` int DEFAULT NULL,
  `validatedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `mobileProvider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Payroll_countryId_fkey` (`countryId`),
  KEY `Payroll_candidateId_fkey` (`candidateId`),
  KEY `Payroll_missionId_fkey` (`missionId`),
  KEY `Payroll_validatedById_fkey` (`validatedById`),
  CONSTRAINT `Payroll_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_missionId_fkey` FOREIGN KEY (`missionId`) REFERENCES `Mission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Payroll_validatedById_fkey` FOREIGN KEY (`validatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payroll`
--

LOCK TABLES `Payroll` WRITE;
/*!40000 ALTER TABLE `Payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Service`
--

DROP TABLE IF EXISTS `Service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interviewTemplate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service`
--

LOCK TABLES `Service` WRITE;
/*!40000 ALTER TABLE `Service` DISABLE KEYS */;
INSERT INTO `Service` VALUES (1,'Ménage','long_term','🏠','menage',1,'2026-06-05 09:52:58.728',NULL,NULL),(2,'Cuisine','long_term','🍳','cuisine',1,'2026-06-05 09:52:58.743',NULL,NULL),(3,'Garde d\'enfants','long_term','👶','nounou',1,'2026-06-05 09:52:58.752',NULL,NULL),(4,'Chauffeur','long_term','🚗','chauffeur',1,'2026-06-05 09:52:58.762',NULL,NULL),(5,'Gardiennage','long_term','🛡️','gardien',1,'2026-06-05 09:52:58.774',NULL,NULL),(6,'Jardinage','long_term','🌿','jardinier',1,'2026-06-05 09:52:58.788',NULL,NULL),(7,'Nettoyage entreprise','long_term','🏢','menage',1,'2026-06-05 09:52:58.797',NULL,NULL),(8,'Agent de sécurité','long_term','lock','securite',1,'2026-06-05 09:52:58.806','personnel_maison',NULL),(9,'Aide personne âgée','long_term','🤝','aide_senior',1,'2026-06-05 09:52:58.816',NULL,NULL),(10,'Plomberie','short_term','🔧','technique',1,'2026-06-05 09:52:58.825',NULL,NULL),(11,'Électricité','short_term','⚡','technique',1,'2026-06-05 09:52:58.836',NULL,NULL),(12,'Peinture','short_term','🎨','technique',1,'2026-06-05 09:52:58.847',NULL,NULL),(13,'Ingénieur Logiciel','long_term','💻','qualifie',1,'2026-06-05 09:52:58.861',NULL,NULL),(14,'Comptable','long_term','📊','qualifie',1,'2026-06-05 09:52:58.874',NULL,NULL),(15,'Réceptionniste','long_term','briefcase','reception',1,'2026-06-05 09:52:58.886','personnel_maison',NULL);
/*!40000 ALTER TABLE `Service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceRate`
--

DROP TABLE IF EXISTS `ServiceRate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceRate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serviceId` int NOT NULL,
  `countryId` int NOT NULL,
  `contractType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minRate` double NOT NULL,
  `maxRate` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ServiceRate_serviceId_fkey` (`serviceId`),
  CONSTRAINT `ServiceRate_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceRate`
--

LOCK TABLES `ServiceRate` WRITE;
/*!40000 ALTER TABLE `ServiceRate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceRate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Target`
--

DROP TABLE IF EXISTS `Target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Target` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `countryId` int DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetValue` double NOT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Target_userId_fkey` (`userId`),
  KEY `Target_countryId_fkey` (`countryId`),
  CONSTRAINT `Target_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Target_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Target`
--

LOCK TABLES `Target` WRITE;
/*!40000 ALTER TABLE `Target` DISABLE KEYS */;
/*!40000 ALTER TABLE `Target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countryId` int DEFAULT NULL,
  `officeId` int DEFAULT NULL,
  `avatar` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  KEY `User_countryId_fkey` (`countryId`),
  KEY `User_officeId_fkey` (`officeId`),
  CONSTRAINT `User_countryId_fkey` FOREIGN KEY (`countryId`) REFERENCES `Country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_officeId_fkey` FOREIGN KEY (`officeId`) REFERENCES `Office` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'Admin','Global','admin@usra-care.com','','admin',NULL,NULL,'AG',1,'$2b$10$xtETxUkEjmFi.DuYO6lkmePtiKpIpHnwXw9XuafCf5cJAvNNt5B5G','2026-06-05 09:52:58.156','2026-06-05 21:49:58.291');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'usra_backoffice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-11  2:00:02
